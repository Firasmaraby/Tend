"""Build the match work queue from matching/candidates.csv.
  rule matches  : NDB links are handled by the pipeline itself; pairs with identical full word sets, identical numbers and no
                  sensitive words are written as equivalent/0.90 (method rule_identical_name)
  haiku tasks   : everything else with score >= 0.65 (chunks of ~700 pairs -> SCRATCH/mt_N.jsonl)
Sensitive words (fortification, organ meat, mixed dish, ...) never go through the rule path."""
import re, sys, json
from pathlib import Path
import pandas as pd
sys.path.insert(0, str(Path(__file__).parent))
ROOT = Path(__file__).resolve().parent.parent
SCR = Path(sys.argv[1])
SENS = set("""enriched fortified fortification added supplemented vitamin iron calcium folic folate liver kidney heart tripe offal giblets
 tongue brain spleen lung gizzard sweetbread pate haggis blood mixed recipe dish stew casserole soup sauce pizza lasagna curry salad
 sandwich burger pie pudding cake cookie biscuit pastry gravy dressing""".split())
WORD = lambda n: re.findall(r"[a-z]+", re.sub(r"s\b", "", n.lower()))
NUM = lambda n: sorted(re.findall(r"\d+(?:[.,]\d+)?", n))
c = pd.read_csv(ROOT / "matching/candidates.csv")
f = pd.read_csv(ROOT / "out/unified/foods.csv", dtype=str, keep_default_na=False).set_index("food_id")
w = pd.read_csv(ROOT / "out/foods_wide.csv", low_memory=False, usecols=["food_uid", "ENERC_KCAL", "PROCNT", "FAT"]).set_index("food_uid")
L = pd.read_csv(ROOT / "out/links/cnf_usda_derivation.csv", dtype=str)
L = L[L.usda_uid.notna() & (L.usda_food_in_build == "True")]
ndb = set(zip(L.cnf_uid, L.usda_uid)) | set(zip(L.usda_uid, L.cnf_uid))
seed = set()
for p in (ROOT / "matches").glob("*.csv"):
    s = pd.read_csv(p); seed |= set(zip(s.target_uid, s.donor_uid)) | set(zip(s.donor_uid, s.target_uid))
nm = lambda u: (f.at[u, "name_en"] or f.at[u, "name_original"])
c = c[[ (a, b) not in ndb and (a, b) not in seed for a, b in zip(c.a_uid, c.b_uid)]].copy()
c["na"] = c.a_uid.map(nm); c["nb"] = c.b_uid.map(nm)
def rule(r):
    wa, wb = WORD(r.na), WORD(r.nb)
    if sorted(wa) != sorted(wb) or NUM(r.na) != NUM(r.nb): return False
    if set(wa) & SENS: return False
    return True
c["rule"] = [rule(r) for r in c.itertuples()]
R = c[c.rule]
out = {}
for r in R.itertuples():
    key = "__".join(sorted([r.a_source, r.b_source]))
    out.setdefault(key, []).append(dict(target_uid=r.a_uid, donor_uid=r.b_uid, match_type="equivalent", confidence=0.90,
                                        method="rule_identical_name", notes=f"identical names after normalisation: {r.na}"))
for k, rows in out.items():
    p = ROOT / "matches" / f"{k}.csv"
    d = pd.DataFrame(rows)
    if p.exists(): d = pd.concat([pd.read_csv(p), d], ignore_index=True).drop_duplicates(["target_uid", "donor_uid"], keep="first")
    d.to_csv(p, index=False)
print("rule matches written:", len(R))
H = c[~c.rule & (c.score >= 0.65)].sample(frac=1, random_state=7).reset_index(drop=True)
H["id"] = range(len(H))
def desc(u):
    r = f.loc[u]; x = w.loc[u] if u in w.index else None
    n = lambda v: "" if x is None or pd.isna(x[v]) else round(float(x[v]), 1)
    return dict(name=nm(u), src=r.source_id, grp=r.food_group, state=r.state, kcal=n("ENERC_KCAL"), prot=n("PROCNT"), fat=n("FAT"))
n_chunks = 14
H.to_csv(SCR / "haiku_pairs.csv", index=False)
for i in range(n_chunks):
    part = H.iloc[i::n_chunks]
    with open(SCR / f"mt_{i+1}.jsonl", "w") as fh:
        for r in part.itertuples():
            fh.write(json.dumps(dict(id=r.id, A=desc(r.a_uid), B=desc(r.b_uid)), ensure_ascii=False) + "\n")
print("haiku pairs:", len(H), "in", n_chunks, "chunks")
