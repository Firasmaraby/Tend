"""Ingest verdict files (id<TAB>verdict<TAB>confidence<TAB>note) into matches/<a>__<b>.csv.
usage: ingest_verdicts.py SCRATCH_DIR PREFIX METHOD    (reads SCRATCH/haiku_pairs.csv and SCRATCH/PREFIX_*.tsv)
Verdict codes: E exact, Q equivalent, S similar, N none (N rows are not stored). Rows already present in matches/ are replaced when
the new METHOD is 'sonnet-review' (Sonnet's verdict is final), otherwise kept."""
import sys, glob
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
scr, prefix, method = Path(sys.argv[1]), sys.argv[2], sys.argv[3]
P = pd.read_csv(scr / "haiku_pairs.csv").set_index("id")
rows, bad, seen = [], 0, set()
for p in sorted(glob.glob(str(scr / f"{prefix}_*.tsv"))):
    for ln in open(p, encoding="utf-8"):
        t = ln.rstrip("\n").split("\t")
        if len(t) < 3: bad += 1; continue
        try: i = int(t[0]); v = t[1].strip().upper(); c = float(t[2])
        except ValueError: bad += 1; continue
        if i not in P.index or v not in "EQSN" or len(v) != 1: bad += 1; continue
        r = P.loc[i]
        seen.add((r.a_uid, r.b_uid))
        if v == "N": continue
        rows.append(dict(target_uid=r.a_uid, donor_uid=r.b_uid, match_type={"E": "exact", "Q": "equivalent", "S": "similar"}[v],
                         confidence=c, method=method, notes=(t[3] if len(t) > 3 else "")[:120], _k="__".join(sorted([r.a_source, r.b_source]))))
D = pd.DataFrame(rows)
print("verdict rows:", len(D), "unparseable lines:", bad)
if method == "sonnet-review":   # pairs Sonnet judged N must also lose their old Haiku row
    for p in (ROOT / "matches").glob("*.csv"):
        old = pd.read_csv(p); keys = seen | {(b, a) for a, b in seen}
        keep = [(a, b) not in keys or m == "sonnet-review" for a, b, m in zip(old.target_uid, old.donor_uid, old.method)]
        old[keep].to_csv(p, index=False)
for k, g in D.groupby("_k"):
    path = ROOT / "matches" / f"{k}.csv"
    g = g.drop(columns="_k")
    if path.exists():
        old = pd.read_csv(path)
        keys = {x for x in seen} | {(b, a) for a, b in seen}
        if method == "sonnet-review":
            old = old[[ (a, b) not in keys for a, b in zip(old.target_uid, old.donor_uid)]]
            g = pd.concat([old, g])
        else:
            g = pd.concat([old, g]).drop_duplicates(["target_uid", "donor_uid"], keep="first")
    g.to_csv(path, index=False)
print(D.groupby(["match_type"]).size().to_string())
