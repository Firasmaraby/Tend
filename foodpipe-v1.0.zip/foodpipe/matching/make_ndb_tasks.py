"""v1.0 fix M1: the CNF foods that carry an NDB code but are NOT derived from USDA (CNF Food_Source 20/23/24/26/28/35/37) are not linked
automatically. Their (CNF food, nearest USDA food) pairs are judged like any other candidate: Haiku first, then Sonnet on every pair Haiku accepts.
usage: make_ndb_tasks.py SCRATCH N_CHUNKS      -> SCRATCH/haiku_pairs.csv and SCRATCH/mt_N.jsonl (prompt: prompt.txt in the match scratch dir)"""
import json, sys
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
SCR = Path(sys.argv[1]); N = int(sys.argv[2])
L = pd.read_csv(ROOT / "out/links/cnf_usda_derivation.csv", dtype=str)
L = L[L.usda_uid.notna() & (L.usda_food_in_build == "True") & (L.derived_from_usda == "False")]
f = pd.read_csv(ROOT / "out/unified/foods.csv", dtype=str, keep_default_na=False).set_index("food_id")
w = pd.read_csv(ROOT / "out/foods_wide.csv", low_memory=False, usecols=["food_uid", "ENERC_KCAL", "PROCNT", "FAT"]).set_index("food_uid")
nm = lambda u: (f.at[u, "name_en"] or f.at[u, "name_original"])
def desc(u):
    r = f.loc[u]; x = w.loc[u] if u in w.index else None
    n = lambda v: "" if x is None or pd.isna(x[v]) else round(float(x[v]), 1)
    return dict(name=nm(u), src=r.source_id, grp=r.food_group, state=r.state, kcal=n("ENERC_KCAL"), prot=n("PROCNT"), fat=n("FAT"))
P = pd.DataFrame({"a_uid": L.cnf_uid.values, "b_uid": L.usda_uid.values, "cnf_food_source": L.cnf_food_source_code.values})
P["a_source"] = "cnf"; P["b_source"] = P.b_uid.map(f.source_id); P["id"] = range(len(P))
P.to_csv(SCR / "haiku_pairs.csv", index=False)
for i in range(N):
    with open(SCR / f"mt_{i+1}.jsonl", "w") as fh:
        for r in P.iloc[i::N].itertuples():
            fh.write(json.dumps(dict(id=r.id, A=desc(r.a_uid), B=desc(r.b_uid)), ensure_ascii=False) + "\n")
print(len(P), "pairs")
