"""Candidate generation for cross-source matching (no model involved). For every pair of sources, each food gets its top-K
most similar foods in the other source by TF-IDF cosine on name_en, inside the same standard food group, after hard filters:
  * explicit state conflict (raw vs cooked/fried/canned/dried/frozen ... from name tokens),
  * both foods on a per-100 g basis,
  * nutrient gate: where both foods report them, energy / protein / fat must be within 25% (or 15 kcal, 2 g) of each other.
Output: matching/candidates.csv (a_uid, b_uid, score, ...). Pairs are unordered (a_source priority-ordered before b_source)."""
from __future__ import annotations
import re, sys, itertools
import numpy as np, pandas as pd
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer

ROOT = Path(__file__).resolve().parent.parent
PRIORITY = ["cnf", "usda_fdc_sr_legacy", "usda_fdc_foundation", "usda_fdc_fndds", "cofid", "ciqual", "afcd", "swiss_fcdb", "mext_japan", "taco"]
STOP = set("a an and or of the with without in for to from as by on at is are type style kind all other nfs ns".split())
STATE_TOK = {
    "raw": {"raw", "fresh", "uncooked", "unprepared"},
    "cooked": {"cooked", "boiled", "steamed", "stewed", "braised", "poached", "simmered", "microwaved", "cooking"},
    "fried": {"fried", "deep", "pan"},
    "roasted": {"roasted", "baked", "grilled", "broiled", "barbecued", "toasted"},
    "canned": {"canned", "tinned", "jarred"},
    "dried": {"dried", "dehydrated", "dry"},
    "frozen": {"frozen"},
    "pickled": {"pickled", "brined", "cured", "smoked"},
}
TOK2STATE = {t: s for s, ts in STATE_TOK.items() for t in ts}

def stem(t):
    for suf in ("ies", "es", "s"):
        if t.endswith(suf) and len(t) > len(suf) + 2:
            return t[: -len(suf)] + ("y" if suf == "ies" else "")
    return t

def tokens(name):
    n = re.sub(r"\(.*?\)", " ", name.lower()) + " " + " ".join(re.findall(r"\((.*?)\)", name.lower()))
    return [stem(t) for t in re.findall(r"[a-z]+", n) if t not in STOP and len(t) > 1]

def states(toks):
    return {TOK2STATE[t] for t in toks if t in TOK2STATE}

def main(K=3, min_score=0.45):
    f = pd.read_csv(ROOT / "out/unified/foods.csv", dtype=str, keep_default_na=False)
    wide = pd.read_csv(ROOT / "out/foods_wide.csv", low_memory=False, usecols=["food_uid", "ENERC_KCAL", "PROCNT", "FAT"]).rename(columns={"ENERC_KCAL": "energy_kcal", "PROCNT": "protein_g", "FAT": "fat_g"})
    f = f.merge(wide.rename(columns={"food_uid": "food_id"}), on="food_id", how="left")
    f = f[(f.basis == "per 100 g edible portion") & (f.status == "active")].reset_index(drop=True)
    f["toks"] = f.name_en.where(f.name_en != "", f.name_original).map(tokens)
    f["states"] = f.toks.map(states)
    f["text"] = f.toks.map(" ".join)
    vec = TfidfVectorizer(token_pattern=r"\S+", sublinear_tf=True).fit(f.text)
    X = vec.transform(f.text)
    out = []
    srcs = [s for s in PRIORITY if s in set(f.source_id)]
    for sa, sb in itertools.combinations(srcs, 2):
        ia = np.where(f.source_id == sa)[0]; ib = np.where(f.source_id == sb)[0]
        for lo in range(0, len(ia), 1500):
            blk = ia[lo: lo + 1500]
            S = (X[blk] @ X[ib].T).toarray()
            ga = np.asarray(f.food_group.astype(object))[blk][:, None] == np.asarray(f.food_group.astype(object))[ib][None, :]
            S = np.where(ga, S, 0)
            for r in range(len(blk)):
                row = S[r]
                top = np.argpartition(-row, min(K, len(row) - 1))[:K]
                for j in top:
                    if row[j] < min_score:
                        continue
                    a, b = blk[r], ib[j]
                    sta, stb = f.states[a], f.states[b]
                    if sta and stb and not (sta & stb) :
                        continue
                    if (("raw" in sta) != ("raw" in stb)) and (sta | stb) and ("raw" in sta or "raw" in stb) and (sta and stb):
                        continue
                    # nutrient gate
                    bad = False
                    for col, rel, ab in (("energy_kcal", .25, 15), ("protein_g", .25, 2), ("fat_g", .25, 2)):
                        x, y = f.at[a, col], f.at[b, col]
                        if pd.notna(x) and pd.notna(y) and abs(float(x) - float(y)) > max(rel * max(float(x), float(y)), ab):
                            bad = True
                    if bad:
                        continue
                    out.append((f.food_id[a], f.food_id[b], sa, sb, round(float(row[j]), 3)))
    c = pd.DataFrame(out, columns=["a_uid", "b_uid", "a_source", "b_source", "score"])
    c.to_csv(ROOT / "matching/candidates.csv", index=False)
    return c

if __name__ == "__main__":
    c = main()
    print(len(c)); print(c.groupby(["a_source", "b_source"]).size().to_string())
