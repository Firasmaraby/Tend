"""Select Haiku E/Q matches for Sonnet review: confidence < 0.90, or fortification/organ/mixed-dish/regional signals.
Writes SCRATCH/review_pairs.csv and rv_N.jsonl chunks. Rule-identical-name matches are reviewed only when sensitive words are present
(they never are, by construction), so they are not queued."""
import sys, glob, json, re
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent; SCR = Path(sys.argv[1]); NCH = int(sys.argv[2])
M = pd.concat([pd.read_csv(p) for p in glob.glob(str(ROOT / "matches/*.csv"))])
H = M[(M.method == "haiku") & M.match_type.isin(["exact", "equivalent"])].copy()
f = pd.read_csv(ROOT / "out/unified/foods.csv", dtype=str, keep_default_na=False).set_index("food_id")
w = pd.read_csv(ROOT / "out/foods_wide.csv", low_memory=False, usecols=["food_uid", "ENERC_KCAL", "PROCNT", "FAT"]).set_index("food_uid")
nm = lambda u: (f.at[u, "name_en"] or f.at[u, "name_original"])
SENS = set("""enriched fortified added supplemented vitamin iron calcium folic folate liver kidney heart tripe offal giblets tongue brain spleen
 lung gizzard sweetbread pate haggis blood mixed recipe dish stew casserole soup sauce pizza lasagna curry salad sandwich burger pie pudding
 cake cookie biscuit pastry gravy dressing wild farmed organic""".split())
SENSG = {"mixed_dishes", "soups_sauces", "baby_foods", "snacks"}
def why(r):
    out = []
    if r.confidence < 0.90: out.append("conf<0.90")
    wd = set(re.findall("[a-z]+", (nm(r.target_uid) + " " + nm(r.donor_uid)).lower()))
    if wd & SENS: out.append("sensitive word")
    if f.at[r.target_uid, "food_group"] in SENSG or f.at[r.donor_uid, "food_group"] in SENSG: out.append("sensitive group")
    return "; ".join(out)
H["why"] = [why(r) for r in H.itertuples()]
if len(sys.argv) > 3:   # restrict to a given pair list (e.g. the 346 non-derived NDB pairs of v1.0) and review ALL of them
    only = pd.read_csv(sys.argv[3]); keys = set(zip(only.a_uid, only.b_uid)) | set(zip(only.b_uid, only.a_uid))
    H = H[[(a, b) in keys for a, b in zip(H.target_uid, H.donor_uid)]].copy()
    H["why"] = H["why"].where(H["why"] != "", "all pairs of this group are reviewed")
R = H[H.why != ""].reset_index(drop=True); R["id"] = range(len(R))
R["a_uid"] = R.target_uid; R["b_uid"] = R.donor_uid
R["a_source"] = R.a_uid.map(f.source_id); R["b_source"] = R.b_uid.map(f.source_id)
R.to_csv(SCR / "haiku_pairs.csv", index=False)   # same layout the ingest script expects (id, a_uid, b_uid, a_source, b_source)
def desc(u):
    r = f.loc[u]; x = w.loc[u] if u in w.index else None
    n = lambda v: "" if x is None or pd.isna(x[v]) else round(float(x[v]), 1)
    return dict(name=nm(u), src=r.source_id, grp=r.food_group, state=r.state, kcal=n("ENERC_KCAL"), prot=n("PROCNT"), fat=n("FAT"))
for i in range(NCH):
    with open(SCR / f"rv_{i+1}.jsonl", "w") as fh:
        for r in R.iloc[i::NCH].itertuples():
            fh.write(json.dumps(dict(id=r.id, A=desc(r.a_uid), B=desc(r.b_uid), haiku=f"{r.match_type[0].upper()} {r.confidence}", why=r.why), ensure_ascii=False) + "\n")
print(len(H), "haiku E/Q;", len(R), "queued for review"); print(R.why.value_counts().to_string())
