# foodpipe v0.3 – Build report

Built 2026-10-21 with `python3 -m foodpipe build`. One unified, provenance-tracked table from nine approved open national databases, with name translation, cross-source matching, gap-filling by borrowing, and de-duplication (within-source supersede + cross-source canonical clusters).

**Headline numbers**

| | |
|---|---|
| Sources ingested | 9 (SR Legacy, Foundation, CNF, CoFID 2021, Ciqual 2025, AFCD R3, Swiss generic, MEXT Japan, TACO) |
| Foods | 26,565 = 26,491 active + 74 superseded |
| Nutrient codes | 54 (24 in the density score) |
| Values (source, not borrowed) | 1,036,674 rows incl. trace / below-LOD / not-quantified markers (section 1) |
| Borrowed values | 47,301 (in 8,518 foods); 12,305 are same-origin (CNF↔USDA), 34,996 cross-source |
| Superseded (within-source) | 74 (72 Foundation, 1 SR Legacy, 1 CNF) |
| Canonical clusters | 20,234 – 4,854 with 2+ sources (only 1,234 of those are independent of the CNF↔USDA derivation), 15,380 singletons |
| QA flags | 0 errors, 255 warnings, 14,247 info (reported, not fixed) |
| Spot-checks | 200 values each, both directions, 9/9 sources: 0 mismatches. Borrowed values: 300 checked, 0 mismatches |

---

## 1. Per-source counts

| Source | Version | Foods | Active | Superseded | Values* | Licence |
|---|---|---:|---:|---:|---:|---|
| usda_fdc_sr_legacy | SR Legacy 2018 | 7,793 | 7,792 | 1 | 309,983 | CC0 |
| cnf | CNF 2026 edition | 5,993 | 5,992 | 1 | 259,499 | OGL-Canada |
| ciqual | Ciqual 2025 | 3,484 | 3,484 | 0 | 115,460 | Etalab open licence |
| cofid | CoFID 2021 (new foods only) | 2,887 | 2,887 | 0 | 114,228 | OGL v3.0 |
| mext_japan | 8th ed. 2023 supp., whole-table sheet | 2,538 | 2,538 | 0 | 87,837 | free use with citation |
| afcd | AFCD Release 3 (Dec 2025) | 1,588 | 1,588 | 0 | 73,884 | CC BY |
| swiss_fcdb | Generic foods V7.1 | 1,216 | 1,216 | 0 | 48,847 | open use, cite source |
| taco | TACO 4th ed. 2011 | 597 | 597 | 0 | 16,345 | reproduction with citation |
| usda_fdc_foundation | Foundation 2026-04-30 | 469 | 397 | 72 | 10,591 | CC0 |
| **Total** | | **26,565** | **26,491** | **74** | **1,036,674** | |

\*Values the source itself supplies, plus the few we derive (kcal from kJ for AFCD; labelled `derived`). Borrowed values are listed separately.

Value types (rows): reported 1,000,529 · borrowed 47,301 · trace 13,671 · below_lod 10,698 · present_not_quantified 8,414 · derived 2,376 · not_applicable 907 · pending 79.

Not ingested: Sweden (dropped by instruction), CoFID old foods, USDA FNDDS (not delivered – optional), Japan supplementary tables, every pending/excluded source in `sources.yaml`.

## 2. Nutrient coverage before and after filling

Coverage = share of the 24 density nutrients that a food has a number for, averaged over active, per-100 g foods.

| Source | Before | After | Active foods |
|---|---:|---:|---:|
| usda_fdc_foundation | 45.8 % | 74.1 % | 397 |
| taco | 54.0 % | 63.1 % | 597 |
| ciqual | 58.1 % | 60.4 % | 3,484 |
| cofid | 70.5 % | 73.6 % | 2,856 |
| mext_japan | 78.3 % | 80.2 % | 2,538 |
| swiss_fcdb | 80.5 % | 84.0 % | 1,215 |
| usda_fdc_sr_legacy | 81.8 % | 84.8 % | 7,792 |
| afcd | 85.1 % | 87.5 % | 1,588 |
| cnf | 85.9 % | 86.9 % | 5,992 |
| **All** | **77.0 %** | **79.9 %** | 26,419 |

Biggest per-nutrient gains (share of foods with a value, before → after): omega-3 ALA F18D3N3 47.5 → 62.9 %, vitamin K1 38.5 → 44.2 %, alpha-tocopherol 65.2 → 70.5 %, choline 29.4 → 34.6 %, DFE folate 56.2 → 61.4 %, iodine 27.0 → 31.9 %. Borrowed values are labelled in `food_nutrients` (`value_type = borrowed`, donor food in the row) and listed per food in `filled_nutrients` / `filled_from_sources_cite_also` in foods_wide.

Honest reading: filling raises overall coverage by about 3 points. It helps most where a source is thin (Foundation, TACO) and for nutrients that many tables skip. It does not make the sparse nutrients dense. 12,305 of the 47,301 borrowed values come from the CNF↔USDA NDB link and are **not** independent measurements (flagged `same-origin` in the note).

Borrowing never touches energy, protein, fat, carbohydrate, water, ash, alcohol, or CHOAVLM; fortification-guarded nutrients are not borrowed across countries; moisture adjustment applies when water differs by more than 5 g; borrowed values are never re-lent.

## 3. Translation

3,135 names translated (Japan 2,538 + TACO 597) by Haiku in 8 batches, with state and species. 530 below confidence 0.8 were reviewed by Sonnet; 72 of those were edited (e.g. regional vegetables kept with their Japanese or Portuguese name in brackets; shokupan, hannama, naisō-ko). 31 Japanese sugar entries had state `raw`, corrected to `unknown`. 460 entries stay below 0.8 because they are proper transliterations with no English equivalent (kept as "Name (local name, transliterated)"). Everything is in `config/translations.csv` with method (`haiku` / `sonnet-review`). Original names are never overwritten.

## 4. Matching

Candidates: TF-IDF on English names within the same food group, both foods per-100 g and active, state-consistent, and with energy/protein/fat within 25 % where both report them → 32,433 candidate pairs.

| Route | Pairs | Result |
|---|---:|---|
| CNF↔USDA by NDB code | 3,377 | deterministic, same-origin (not independent) |
| Identical normalised name + numbers, no sensitive word (rule) | 1,416 | equivalent 0.90, method `rule_identical_name` |
| Haiku judged (score ≥ 0.65) | 10,441 | 1,069 exact, 1,988 equivalent kept; 3,620 similar; rest none |
| Sonnet final review of Haiku exact/equivalent that were <0.90, or touched fortification, organ meat, mixed dish, sauce/soup, baby food or snack | 2,836 | 232 exact, 1,335 equivalent kept; **1,269 downgraded to similar** (45 % of those reviewed) |
| Deterministic guard after the models | 161 downgraded | opposite statements about salt, milk, skin, etc., or fortification stated on one side only (`out/match_guard_log.csv`) |
| Earlier TACO→Foundation seed matches | 74 | method `claude-review` |

Usable pairs (exact/equivalent, ≥ 0.85): 6,103 non-NDB pairs plus the 3,377 NDB links. Every row in `matches/*.csv` records its method; guard downgrades carry `+guard`.

Quality evidence: on pairs where both foods report a value, median relative difference in kcal is 0.2 %, protein 0.1 % (this includes the NDB-linked pairs, which share data); 0.2 % of pairs differ by more than 50 % in kcal. Model-judged pairs (Haiku, Sonnet) differ by more than 20 % in kcal in 1–2 % of cases; rule-matched identical-name pairs in 11 % (mostly low-energy vegetables, where a few kcal is a big percentage). Vitamin A (RE) agrees poorly across pairs (median 43 % apart) – conventions differ; it is borrowed only within its own code.

## 5. De-duplication (DEDUP_SPEC checks)

* Within source: key = source + normalised name + state; newest release then most density nutrients wins; collapse only if energy/protein/fat/carb agree within 20 % (with an absolute floor of 1 g / 1 g / 10 kcal). 74 superseded; 3 left active for review (`out/dedup_within_source_review.csv`). Foundation's 72 are repeated samples of the same food (milk, broccoli, salt…).
* Cross source: only exact/equivalent at ≥ 0.85, one food per source per cluster; region priority CNF > SR Legacy > Foundation > CoFID > Ciqual > AFCD > Swiss > Japan > TACO; tie-break by nutrient count then newest release. Pairs that would merge two clusters (1,489) or add a second food from the same source (448) are not merged and are listed in `out/dedup_cluster_review.csv` (1,937 rows).
* Cluster size: 15,380 × 1, 3,985 × 2, 548 × 3, 197 × 4, 66 × 5, 36 × 6, 14 × 7, 7 × 8, 1 × 9.
* All six spec checks pass: every food_id appears once (26,565); foods before = active + superseded (26,565 = 26,491 + 74); one preferred record per cluster (20,234); every active food in exactly one cluster (26,491); no cluster holds two foods from one source; foods_wide has one `is_preferred` per cluster.
* I read 100 random multi-source clusters: one clear miss (a fruit cocktail of peach–pear–apricot matched to one of peach–pineapple) and one borderline case (rye flour type 130 vs type 815); the rest were the same food. Nothing was chained into a giant cluster (largest = 9 entries across 8 databases: canola/rapeseed oil).

## 6. QA summary (flagged, never silently fixed)

0 errors · 255 warnings · 14,247 info.

| Check | Severity | Count |
|---|---|---:|
| energy_mismatch | warning | 162 |
| fatty_acids_exceed_fat | warning | 51 |
| proximate_over_100g | warning | 17 |
| fiber_exceeds_carb | warning | 11 |
| sugar_exceeds_carb | warning | 11 |
| duplicate_source_id | warning | 2 |
| matrix_unit_missing | warning | 1 |
| group_outlier | info | 9,858 |
| derived_from_usda (CNF) | info | 4,185 |
| duplicate_name_in_source | info | 148 |
| per_100ml_basis | info | 31 |
| negative_carb_by_difference | info | 14 |
| over_100g_monosaccharide_equivalents (CoFID available carbs; downgraded from error as instructed) | info | 10 |
| malformed_source_cell | info | 1 |

QA runs on source values before borrowing. Borrowed values are verified by `checks/spot_check_borrowed.py` (donor value present, factor correct, match ≥ 0.85, both foods active and per-100 g, never-borrow list and fortification guard respected): 300 sampled, 0 mismatches.

## 7. Decisions made (all mine unless marked)

**Scope (your instructions)**
1. Sweden dropped; CoFID old foods out; Japan supplementary tables skipped; FNDDS not delivered so skipped; Foundation and AFCD added (both loaded cleanly).
2. CNF values whose origin is Frida (21), Fineli (15) or "International database" (14) withheld → `out/withheld_values.csv`. **Your message said 72; this CNF edition has 50.** All 50 are withheld; see open question 2.
3. CoFID available carbohydrate → new code CHOAVLM (monosaccharide equivalents), never borrowed, 3.75 kcal/g in the energy check; the 10 over-100 g errors are now info.
4. CoFID "N" → `present_not_quantified` (never 0), still eligible to receive borrowed values.
5. Per-100 mL drinks (31 CoFID Q* foods) and Swiss 1539 (assumed, not stated) carry a non-standard `basis`; they are excluded from density, candidate generation and borrowing.
6. Japan vitamin K (K1 + MK-4) → separate code VITK (`vitamin_k_total_ug`), density weight 0.

**Evidence-based calls you asked me to make**
7. CNF vitamin E (alpha-tocopherol, mg) and niacin equivalents: factor 1 kept, as decided earlier. The CNF unit label "NE" means 1 mg of niacin by definition, and alpha-tocopherol is already in mg, so no conversion is warranted by the evidence.
8. CoFID group code BTM (not in the user-guide group table; its three foods are baking fat, compound cooking fat and ghee) mapped to `fats_oils`.

**Judgment calls**
9. AFCD: per-100 g sheet used; kcal derived from kJ (labelled `derived`); vitamin D = D3 equivalents; vitamin A = RE; where AFCD's profiles file and Food Details disagree (3 foods' derivation, 2 foods' classification) the profiles file wins; mg→g conversion allowed only with an explicit factor in the AFCD map.
10. Same-origin borrowing (CNF↔USDA) is allowed but labelled and counted separately. Matches are used symmetrically (A→B and B→A).
11. Ciqual carbohydrate (includes polyols; possibly the EU monosaccharide-equivalent convention) and the Swiss carbohydrate definition are left as CHOAVL.
12. Sonnet's review is final; the deterministic guard can only downgrade, never upgrade. A "with salt" vs "without salt" cooking difference is treated as a mismatch even though only sodium changes – conservative, costs about 140 matches.
13. Rule matching (identical names) is used instead of asking a model, but never when fortification, organ, mixed-dish or similar words are present.
14. Foundation repeated samples and CNF/SR duplicates collapsed only inside the 20 % rule; everything else is listed for review.
15. Translations: 460 transliterated Japanese/Portuguese names stay below 0.8 confidence on purpose.

## 8. Open questions

1. **Licence wording to confirm (you decide, I am not a lawyer):** AFCD is CC BY 4.0 on the FSANZ site but data.gov.au lists CC BY 2.5 AU; I cite both. MEXT and TACO permissions are citation-based statements, not named licences. TACO file provenance: unmodified NEPA file obtained via GitHub, byte-identical across two repos (as accepted).
2. CNF withheld values: 50 here vs the 72 you mentioned. Is the 72 from a different CNF release, or should some other class be withheld too? Reversal is a one-line change in `sources.yaml`.
3. Do you want same-origin CNF↔USDA clusters counted as "multi-source" in the app? I report both numbers (4,854 vs 1,234 independent).
4. Ciqual and Swiss carbohydrate definitions – worth a conversion pass later if you need strict CHOAVL comparability.
5. FNDDS: add when you have the file; the adapter slot exists in the dedup priority list.
6. The 1,937 cluster-review pairs and the 3 within-source review pairs: left unmerged. A person could resolve them in an afternoon; none blocks use.

## 9. Deliverables

* `foodpipe-v0.3.zip` – code, config, matches, matching scripts, prompts, docs, checks, reports, and outputs (`out/unified/*.csv`, citation files, review queues, guard log). Raw data and the TACO PDF are not included; no CNF guide PDFs, no Ciqual PDF.
* `food_database_v0.3.xlsx` – README, CITATIONS_REQUIRED, foods_wide (with `canonical_id`, `is_preferred`, `status`, `superseded_by`), foods, nutrients, food_nutrients (split over two sheets for Excel's row limit), food_groups, qa_flags, canonical_foods, canonical_members.
* `BUILD_REPORT.md` – this file.

Citations are a licence condition: `source_citation`, `licence`, `citation_required`, `filled_from_sources_cite_also`, the CITATIONS_REQUIRED sheet, NOTICE.txt, CITATIONS.md and datapackage.json are all present in the outputs and untouched.
