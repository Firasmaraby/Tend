# foodpipe workflow: phases, models and handoffs

Each chat in a Claude project has its OWN workspace. Files built in one chat are not visible in the next.
So every phase ends by sending a versioned zip, and the next phase starts by uploading it.
Project files (knowledge) hold the rules and docs. Big data files go into the chat as attachments.

| Phase | Model | Chat | Input | Output (handoff) |
|---|---|---|---|---|
| 1. Build | Sonnet 5.5 | New chat in project | foodpipe.zip + all official data files | foodpipe-v0.2.zip, food_database_v0.2.xlsx, BUILD_REPORT.md |
| 1b. Bulk passes | Haiku 5.5 | Sub-agents launched from the Phase 1 chat (or a separate Haiku chat if sub-agents are unavailable) | translate_tasks.jsonl, match candidate files | translations + proposed matches, reviewed by Sonnet |
| 2. Dedup | Sonnet 5.5 | Same Phase 1 chat (the workspace is still there) | Phase 1 build | foodpipe-v0.3.zip, food_database_v0.3.xlsx, DEDUP_REPORT.md |
| 3. Independent review | Opus 5.5 | NEW chat in project (fresh eyes: it must not have seen the build) | v0.3 zip + the same raw data files | REVIEW.md: findings ranked by severity, sample audits, go/no-go |
| 4. Fixes | Sonnet 5.5 | New chat in project | v0.3 zip + REVIEW.md + raw files | v1.0 release |

## Version and handoff rules
- Version name: v0.2, v0.3, ... v1.0. Bump on every handoff. Write the version into out/unified/metadata.json.
- Every handoff includes a short report: what changed, counts (foods, values, borrowed, superseded, clusters),
  QA flag summary, decisions made, open questions.
- Never hand off a build whose validation failed. Fix it first, or label it clearly as failed.

## Why Opus reviews in a new chat
A reviewer that watched the work being built tends to grade its own reasoning. A fresh Opus chat sees only
the outputs, the rules and the raw files. It re-derives values from the raw files and checks the work.
