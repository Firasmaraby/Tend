# Prompts for each phase

## Phase 1 + 2: Sonnet 5.5 (build, bulk passes, dedup)

Attach in the chat: foodpipe.zip and every official data file.

```
Phase 1 + 2 of foodpipe (see WORKFLOW.md). Model: you are Sonnet, doing build and dedup.

Attached: foodpipe.zip and the official downloads for the approved sources.

Step 0 - Inventory and plan (stop here and wait for my OK):
- Unzip foodpipe. Read README.md, sources.yaml, DEDUP_SPEC.md, fill_rules.yaml.
- List every attached file: name, size, which source_id it belongs to, release/version if visible.
- Flag anything missing or unexpected, and any licence text inside the files that differs from sources.yaml.
- Give me the order of work and roughly how long each source will take.

After my OK:

Step 1 - Ingest, one source at a time
- Put files in data/incoming/<source_id>/. Order: usda_fdc_sr_legacy, usda_fdc_foundation, usda_fdc_fndds
  (adapter exists), cnf, cofid, ciqual, afcd, livsmedelsverket, swiss_fcdb, mext_japan, taco (official file).
- Inspect each file's real layout, write its adapter and source map, then rebuild WITHOUT --dev.
- After each source: spot-check 200 random values against the raw file (report mismatches),
  then report foods/values added, nutrients covered and QA flags. Don't move on with unexplained mismatches.

Step 2 - Bulk passes (Haiku sub-agents if available; otherwise tell me and I'll run a Haiku chat)
- Translate non-English names with prompts/translate_foods.md. Review everything below confidence 0.8 yourself.
- Generate match candidates in code (same food group, name similarity), have Haiku judge them with
  prompts/match_foods.md, and review borderline and fortification-sensitive ones yourself.
  Save to matches/*.csv with the method recorded.

Step 3 - Dedup per DEDUP_SPEC.md
- Within-source: collapse to one active record, mark the rest superseded.
- Cross-source: canonical clusters + preferred record via config/dedup_rules.yaml (create it, using the
  default priority in the spec). Add canonical_id and is_preferred to foods_wide.
- Run the checks in the spec, including "foods before = active + superseded".

Step 4 - Handoff
- Confirm each source's citation wording against the publisher's own requested citation (inside the files or on their site) and update sources.yaml if needed.
- Rebuild. Deliver foodpipe-v0.3.zip (code, config, matches, outputs; raw data files may be left out if too
  large), food_database_v0.3.xlsx, and BUILD_REPORT.md: per-source counts, nutrient coverage before and
  after filling, borrowed-value count, superseded count, cluster count, QA summary, decisions made, open questions.

Stop and ask me if anything contradicts the project rules.
```

## Phase 3: Opus 5.5 (independent review)

Start a NEW chat in the project, select Opus. Attach: foodpipe-v0.3.zip, food_database_v0.3.xlsx,
BUILD_REPORT.md and the same official data files.

```
Phase 3 of foodpipe: independent review. You did not build this; review it as an auditor.

Attached: the v0.3 build, its report, and the raw official data files.

Check, by re-deriving from the raw files (not by trusting the build's own logs):
1. Licences: every ingested source is approved; ATTRIBUTION covers each one.
2. Fidelity: for each source, 300 random values traced back to the raw file cell (value, unit, special codes).
3. Units and methods: CHOCDF/CHOAVL kept apart, RAE/RE apart, IU conversions, kJ/kcal, per-100 g basis,
   edible-portion handling.
4. Gap filling: sample 100 borrowed values. Is the match truly exact/equivalent? Fortification guard applied?
   Moisture adjustment correct?
5. Dedup: sample 100 clusters and 50 superseded records against DEDUP_SPEC.md. Any wrong merges (state,
   variety, fortification)? Anything lost (foods before = active + superseded)?
6. Format: column names, stable IDs, empty vs 0, metadata version, and the workbook opens cleanly.
7. Citations: every row in foods_wide, foods and food_nutrients has source_citation; borrowed values cite their donor;
   CITATIONS_REQUIRED lists every source used, with wording matching each publisher's requested citation;
   NOTICE.txt, datapackage.json and the workbook properties carry the notice.
8. Density ranking: sanity-check the top 50.

Deliver REVIEW.md: findings ranked by severity (blocker / major / minor), each with evidence (IDs, values,
file cells), plus a go/no-go for v1.0. Fix nothing; report only.
```

## Phase 4: Sonnet 5.5 (fixes)

New chat. Attach v0.3 zip, REVIEW.md, raw files.

```
Phase 4 of foodpipe: apply the fixes in REVIEW.md, blockers and majors first. For each finding, mark it
fixed / not fixed (why) / disputed (evidence). Re-run validation and deliver foodpipe-v1.0.zip,
food_database_v1.0.xlsx and CHANGELOG.md.
```

## Fallback if Haiku sub-agents are unavailable

Open a chat with Haiku 5.5. Attach translate_tasks.jsonl (or a match candidates file) from the Sonnet chat
and paste the system prompt from prompts/translate_foods.md (or match_foods.md). Ask it to return a CSV with
custom_id plus the JSON fields. Bring that CSV back to the Sonnet chat for review.
