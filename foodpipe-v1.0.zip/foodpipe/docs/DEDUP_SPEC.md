# Duplicate handling spec (foodpipe)

There are two kinds of duplicate, and they get opposite treatment.

## 1. Same food twice inside ONE source -> collapse to one record

Example: USDA Foundation lists "Spinach, baby" under two FDC IDs (an older and a newer release record).
QA already flags these as `duplicate_name_in_source`.

Rule:
- Group by source + normalised name (+ identical state).
- Keep ONE active record: the newest publication date; if tied, the one with more nutrients reported.
- The others get `status = superseded` and `superseded_by = <food_id>`. They are not deleted from
  food_nutrients, so the history stays auditable.
- Exception: if the two records differ by more than 20% on protein, fat or energy, do not collapse.
  Flag them for review: they may be different products with the same name.

## 2. Same food in DIFFERENT sources -> link, never delete

Example: raw broccoli in USDA, CNF, CoFID and CIQUAL. These are four independent lab measurements from
four countries. Deleting three would throw away real data and the country-specific values (fortification,
soil, varieties).

Rule: create a canonical food layer.
- `canonical_foods` table: canonical_id, canonical_name_en, food_group, state, preferred_food_id.
- `canonical_members` table: canonical_id, food_id, match_type, confidence, method.
- Members come from the same matching process as gap filling: candidate generation in code,
  Haiku proposes, Sonnet reviews. Only `exact` and `equivalent` matches at confidence >= 0.85 join a cluster.
  `similar` never joins.
- The preferred record is chosen by `config/dedup_rules.yaml`:
  1. region priority (default for a Canadian app: cnf > usda_fdc_sr_legacy > usda_fdc_foundation > cofid >
     ciqual > afcd > livsmedelsverket > swiss_fcdb > mext_japan > taco), then
  2. most density nutrients reported, then
  3. newest release.
- foods_wide gets two new columns: `canonical_id` and `is_preferred` (true/false). An app that wants one entry
  per food filters `is_preferred = true`. An app that wants regional values picks by country.
- A food belongs to at most one cluster. If a candidate would join two clusters, stop and flag it for review.

## What NOT to do
- Never average values across sources into a new number. That creates data no lab measured.
- Never merge foods in different states (raw vs boiled, dry vs cooked).
- Never merge across fortification status (milk with added vitamin D vs without; enriched vs unenriched flour).
- Never merge different varieties that differ in composition (orange vs white sweet potato, Hass vs
  Brazilian avocado, farmed vs wild salmon).

## Checks after dedup
- Every food_id appears exactly once in foods_wide.
- Every cluster has exactly one preferred record.
- Random sample of 100 clusters reviewed by a human or by the Opus review pass.
- Count of foods before = active + superseded (nothing lost).


## v1.0 amendments (2026-10-22, after the independent review)
- **Preferred record order:** (1) has energy + protein + fat from its own source, (2) region priority, (3) most density nutrients, (4) newest release.
  Within-source supersede uses the same first rule before "newest wins".
- **Non-standard basis** (`per 100 g as purchased (incl. refuse)`, `per 100 g dry matter`, `per 100 mL`, assumed): never in a multi-source cluster. Such a
  food is a singleton cluster; if a standard-basis record exists under the same name (same source, name with the basis phrase removed, or its token subset)
  it is NOT preferred and its cluster has no preferred record (`canonical_foods.preferred_food_id` is empty, `preferred_note` says why).
  The check "exactly one preferred record per cluster" therefore holds for every cluster except these listed singletons.
- **canonical_id** = "cf_" + first 10 hex of md5(preferred food_id) (the food_id of the sole member for a singleton without a preferred record). It does not change when other members join or leave.
- **Cluster consistency:** a food joins a cluster only if the match guard (foodpipe/guard.py) finds no conflict with ANY existing member; otherwise the pair goes to the review queue.
- **Links:** CNF<->USDA `ndb_code` links are used only where `derived_from_usda` is True; other CNF foods with an NDB code go through candidate -> Haiku -> Sonnet like any other food.
