"""Independent check of borrowed values (csv module only): sample N borrowed rows and verify that
 (1) the donor has a reported/trace/derived value for that code, (2) borrowed value = donor value x (1 or the dry-matter ratio when
 the two foods' WATER differ by > 5 g), (3) a match >= 0.85 exact/equivalent (or an NDB link) exists in either direction,
 (4) neither food is superseded or on a non-standard basis, (5) the code is not on the never-borrow list, (6) fortification-guard
 patterns do not apply, (7) the original_value/label point at the donor's text."""
import csv, glob, random, re, sys, math
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
rows = list(csv.DictReader(open(ROOT / "out/food_values_long.csv", encoding="utf-8")))
val = {}
for r in rows:
    if r["value_type"] in ("reported", "trace", "derived") and r["value"] != "": val[(r["food_uid"], r["code"])] = float(r["value"])
b = [r for r in rows if r["value_type"] == "borrowed"]
foods = {r["food_id"]: r for r in csv.DictReader(open(ROOT / "out/unified/foods.csv", encoding="utf-8"))}
pairs = {}
for p in glob.glob(str(ROOT / "matches/*.csv")):
    for r in csv.DictReader(open(p, encoding="utf-8")):
        if r["match_type"] in ("exact", "equivalent") and float(r["confidence"]) >= .85:
            for k in ((r["target_uid"], r["donor_uid"]), (r["donor_uid"], r["target_uid"])): pairs[k] = r["method"]
for r in csv.DictReader(open(ROOT / "out/links/cnf_usda_derivation.csv", encoding="utf-8")):
    if r.get("usda_uid"): pairs[(r["cnf_uid"], r["usda_uid"])] = pairs[(r["usda_uid"], r["cnf_uid"])] = "ndb_code"
import yaml
rules = yaml.safe_load(open(ROOT / "config/fill_rules.yaml"))
random.seed(7); sample = random.sample(b, n); bad = []
for r in sample:
    t, d, c = r["food_uid"], r["donor_food_uid"], r["code"]
    dv = val.get((d, c))
    if dv is None: bad.append((t, c, "donor has no value")); continue
    wt, wd = val.get((t, "WATER")), val.get((d, "WATER"))
    exp = dv
    if wt is not None and wd is not None and abs(wt - wd) > rules["moisture_adjust_threshold_g"] and wd < 100: exp = dv * (100 - wt) / (100 - wd)
    if not math.isclose(float(r["value"]), exp, rel_tol=1e-3, abs_tol=1e-6): bad.append((t, c, f"value {r['value']} != expected {exp}"))
    if (t, d) not in pairs: bad.append((t, c, "no match >= 0.85"))
    for u in (t, d):
        if foods[u]["status"] != "active" or foods[u]["basis"] != "per 100 g edible portion": bad.append((t, c, f"{u} superseded/non-standard basis"))
    if c in rules["never_borrow"]: bad.append((t, c, "never-borrow code"))
    nm = (foods[t]["name_en"] + " " + foods[t]["name_original"])
    for g in rules["fortification_guard"]:
        if c in g["nutrients"] and re.search(g["pattern"], nm) and foods[t]["source_id"].split("_")[0] != foods[d]["source_id"].split("_")[0] and "same-origin" not in r["note"]:
            bad.append((t, c, "fortification guard should have blocked"))
    if r["value_type"] != "borrowed" or not r["original_label"]: bad.append((t, c, "missing provenance"))
print(f"borrowed: {len(b)} rows in output; checked {n}; mismatches {len(bad)}")
for x in bad[:15]: print("  ", x)
