"""Independent spot-check: sample N output values for a USDA FDC source and compare them with the raw CSV text.
Reads the raw files with the csv module (not pandas, not the adapter) so the check does not share code with the adapter.
usage: python checks/spot_check_usda.py <source_id> [n] [seed]
"""
import csv, random, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sid = sys.argv[1]; n = int(sys.argv[2]) if len(sys.argv) > 2 else 200; seed = int(sys.argv[3]) if len(sys.argv) > 3 else 42
raw = ROOT / "data" / "incoming" / sid
out = ROOT / "out" / "food_values_long.csv"
rows = [r for r in csv.DictReader(open(out, encoding="utf-8")) if r["data_source"] == sid and r["value_type"] in ("reported", "trace") and r["value"] != ""]
random.seed(seed); sample = random.sample(rows, n)
fmap = {r["source_key"]: float(r["factor"]) for r in csv.DictReader(open(ROOT / "config/source_maps/usda_fdc.csv", encoding="utf-8"))}
want = {}
for r in sample:
    fid = r["food_uid"].split(":")[1]; nid = r["original_label"].rsplit("[", 1)[1].rstrip("]")
    want[(fid, nid)] = r
found = {}
with open(raw / "food_nutrient.csv", encoding="utf-8", newline="") as fh:
    for rec in csv.DictReader(fh):
        k = (rec["fdc_id"], rec["nutrient_id"])
        if k in want: found[k] = rec["amount"]
names = {}
with open(raw / "food.csv", encoding="utf-8", newline="") as fh:
    for rec in csv.DictReader(fh):
        names[rec["fdc_id"]] = rec["description"]
bad = []
for (fid, nid), r in want.items():
    rawamt = found.get((fid, nid))
    if rawamt is None: bad.append((fid, nid, "raw row missing")); continue
    exp = float(rawamt) * fmap[nid]
    ok_val = abs(float(r["value"]) - exp) <= 1e-6 * max(1, abs(exp))
    ok_orig = float(r["original_value"]) == float(rawamt)
    if not (ok_val and ok_orig): bad.append((fid, nid, f"out {r['value']} orig {r['original_value']} vs raw {rawamt} x{fmap[nid]}"))
print(f"{sid}: checked {len(want)} values, mismatches {len(bad)}")
for b in bad[:20]: print("  MISMATCH", b)
