"""Independent spot-check for CNF: sample N output values and compare with the raw CSV text (csv module, not pandas)."""
import csv, random, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
n = int(sys.argv[1]) if len(sys.argv) > 1 else 200; seed = int(sys.argv[2]) if len(sys.argv) > 2 else 42
raw = ROOT / "data/incoming/cnf"
rows = [r for r in csv.DictReader(open(ROOT / "out/food_values_long.csv", encoding="utf-8")) if r["data_source"] == "cnf" and r["value_type"] != "borrowed" and r["value"] != ""]
random.seed(seed); sample = random.sample(rows, n)
fmap = {r["source_key"]: r for r in csv.DictReader(open(ROOT / "config/source_maps/cnf.csv", encoding="utf-8"))}
want = {}
for r in sample:
    fid = r["food_uid"].split(":")[1]; nid = r["original_label"].rsplit("[", 1)[1].rstrip("]")
    want[(fid, nid)] = r
found = {}
with open(raw / "Nutrient_Amount.csv", encoding="utf-8-sig", newline="") as fh:
    for rec in csv.DictReader(fh):
        k = (rec["Food_Code"], rec["Nutrient_Code"])
        if k in want: found[k] = rec
bad = []
for k, r in want.items():
    rec = found.get(k)
    if rec is None: bad.append((k, "raw row missing")); continue
    m = fmap[k[1]]
    if float(m["factor"]) != 1.0: bad.append((k, "factor != 1"))
    if rec["Nutrient_Amount"] != r["original_value"]: bad.append((k, f"original_value {r['original_value']} vs raw {rec['Nutrient_Amount']}"))
    if float(r["value"]) != float(rec["Nutrient_Amount"]): bad.append((k, f"value {r['value']} vs raw {rec['Nutrient_Amount']}"))
    if r["nutrient_code" if "nutrient_code" in r else "code"] != m["code"]: bad.append((k, "code differs"))
    if rec["Nutrient_Source_Code"] in ("81", "82", "83"): bad.append((k, "withheld source code loaded"))
# food names
names = {}
with open(raw / "Food_Name.csv", encoding="utf-8-sig", newline="") as fh:
    for rec in csv.DictReader(fh): names[rec["Food_Code"]] = rec["Food_Description_EN"]
import pandas as pd
foods = pd.read_csv(ROOT / "out/unified/foods.csv", keep_default_na=False, dtype=str).set_index("food_id")
for (fid, _), r in want.items():
    if foods.loc[f"cnf:{fid}", "name_original"] != names[fid]: bad.append((fid, "food name differs"))
print(f"cnf: checked {len(want)} values (+ food names), mismatches {len(bad)}")
for b in bad[:20]: print("  MISMATCH", b)
