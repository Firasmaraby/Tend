"""Independent spot-check for CoFID: reads the xlsx straight from its XML (zipfile + ElementTree, no openpyxl/pandas),
then (1) samples N output values and compares with the raw cell, (2) samples N non-empty raw cells in mapped columns and
checks each one reached the output (completeness)."""
import csv, math, random, re, sys, zipfile
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
seed = int(sys.argv[2]) if len(sys.argv) > 2 else 42
xlsx = next(p for p in (ROOT / "data/incoming/cofid").glob("*.xlsx") if "old" not in p.name.lower())
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
RNS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
z = zipfile.ZipFile(xlsx)
sst = ["".join(t.text or "" for t in si.iter("{%s}t" % NS["m"])) for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", NS)]
rels = {r.get("Id"): r.get("Target") for r in ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))}
sheets = {s.get("name"): "xl/" + rels[s.get(RNS)].lstrip("/").replace("xl/", "") for s in ET.fromstring(z.read("xl/workbook.xml")).find("m:sheets", NS)}
_cache = {}

def grid(name):
    if name in _cache: return _cache[name]
    g = defaultdict(dict)
    for row in ET.fromstring(z.read(sheets[name])).find("m:sheetData", NS):
        for c in row:
            col = re.match(r"[A-Z]+", c.get("r")).group(); r = int(c.get("r")[len(col):])
            t = c.get("t"); v = c.find("m:v", NS)
            if t == "s" and v is not None: val = sst[int(v.text)]
            elif t == "inlineStr": val = "".join(x.text or "" for x in c.iter("{%s}t" % NS["m"]))
            elif v is not None: val = v.text
            else: continue
            g[r][col] = val
    _cache[name] = g
    return g

def colnum(c): 
    x = 0
    for ch in c: x = x * 26 + ord(ch) - 64
    return x

def locate(sheet, mnemonic, native_id):
    g = grid(sheet)
    col = next(c for c, v in g[2].items() if v.strip() == mnemonic)
    code, _, nth = native_id.partition("#")
    rows = sorted(r for r in g if r >= 4 and g[r].get("A", "").strip() == code)
    r = rows[int(nth) - 1] if nth else rows[0]
    return g[r].get(col), g[r].get("B")

fmap = {r["source_key"]: r for r in csv.DictReader(open(ROOT / "config/source_maps/cofid.csv", encoding="utf-8"))}
out = [r for r in csv.DictReader(open(ROOT / "out/food_values_long.csv", encoding="utf-8")) if r["data_source"] == "cofid" and r["value_type"] != "borrowed"]
random.seed(seed)
bad = []
# (1) output -> raw
for r in random.sample(out, n):
    mnem = re.search(r"\[([^\]]+)\]$", r["original_label"]).group(1)
    sheet = next(k.split("|")[0] for k in fmap if k.endswith("|" + mnem) and fmap[k]["code"] == r["code"])
    raw, name = locate(sheet, mnem, r["food_uid"].split(":", 1)[1])
    key = f"{sheet}|{mnem}"
    if raw is None: bad.append((r["food_uid"], r["code"], "raw cell empty")); continue
    s = raw.strip()
    if r["original_value"].strip() != s and not (re.fullmatch(r"-?\d+(\.\d+)?(E-?\d+)?", s) and math.isclose(float(r["original_value"]), float(s), rel_tol=1e-12)):
        bad.append((r["food_uid"], r["code"], f"original_value {r['original_value']!r} vs raw {raw!r}"))
    if s == "Tr": ok = r["value_type"] == "trace" and float(r["value"]) == 0
    elif s == "N": ok = r["value_type"] == "present_not_quantified" and r["value"] == ""
    elif s.startswith("("): ok = r["value_type"] == "reported" and math.isclose(float(r["value"]), float(s.strip("()")), rel_tol=1e-12)
    else: ok = r["value_type"] == "reported" and math.isclose(float(r["value"]), float(s), rel_tol=1e-12)
    if not ok: bad.append((r["food_uid"], r["code"], f"value/type {r['value']!r}/{r['value_type']} for raw {raw!r}"))
    if float(fmap[key]["factor"]) != 1.0: bad.append((r["food_uid"], r["code"], "factor != 1"))
    if fmap[key]["code"] != r["code"]: bad.append((r["food_uid"], r["code"], "code differs from map"))
    if name.strip() != next(f for f in csv.DictReader(open(ROOT / "out/unified/foods.csv", encoding="utf-8")) if f["food_id"] == r["food_uid"])["name_original"]:
        bad.append((r["food_uid"], r["code"], "food name differs"))
# (2) raw -> output (completeness): random mapped cell positions that are non-empty in the source
have = {(r["food_uid"], r["code"]) for r in out}
checked = 0; tries = 0
keys = list(fmap)
fibre_have = {(u, c) for u, c in have if c == "FIBTG"}
while checked < n and tries < 20000:
    tries += 1
    key = random.choice(keys); sheet, mnem = key.split("|")
    g = grid(sheet); col = next(c for c, v in g[2].items() if v.strip() == mnem)
    r = random.choice([x for x in g if x >= 4])
    raw = g[r].get(col)
    if raw is None or raw.strip() == "": continue
    code = g[r]["A"].strip()
    dup = [x for x in g if x >= 4 and g[x].get("A", "").strip() == code]
    uid = "cofid:" + (f"{code}#{sorted(dup).index(r)+1}" if len(dup) > 1 else code)
    checked += 1
    if (uid, fmap[key]["code"]) not in have: bad.append((uid, fmap[key]["code"], f"raw cell {raw!r} in {key} missing from output"))
print(f"cofid: checked {n} output values -> raw and {checked} raw cells -> output, mismatches {len(bad)}")
for b in bad[:25]: print("  MISMATCH", b)
