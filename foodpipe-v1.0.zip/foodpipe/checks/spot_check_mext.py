"""Independent spot-check for MEXT Japan: reads the xlsx straight from its XML (zipfile + ElementTree).
(1) N output values -> raw cell, (2) N raw cells -> output, (3) full-population token checks, (4) chapter sheets not used."""
import csv, math, random, re, sys, zipfile
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
seed = int(sys.argv[2]) if len(sys.argv) > 2 else 42
xlsx = next((ROOT / "data/incoming/mext_japan").glob("*.xlsx"))
M = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
RID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
z = zipfile.ZipFile(xlsx)
def _si_text(si):  # displayed text only: <t> and <r><t>; NOT <rPh> (furigana / phonetic readings)
    return "".join((t.text or "") for t in list(si.findall(M + "t")) + [x for r in si.findall(M + "r") for x in r.findall(M + "t")])
sst = [_si_text(si) for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall(M + "si")]
rels = {r.get("Id"): r.get("Target") for r in ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))}
sheets = {s.get("name"): "xl/" + rels[s.get(RID)].lstrip("/").replace("xl/", "") for s in ET.fromstring(z.read("xl/workbook.xml")).find(M + "sheets")}
G = defaultdict(dict)
for row in ET.fromstring(z.read(sheets["表全体"])).find(M + "sheetData"):
    for c in row:
        col = re.match(r"[A-Z]+", c.get("r")).group(); r = int(c.get("r")[len(col):])
        v = c.find(M + "v"); t = c.get("t")
        if v is None:
            is_ = c.find(M + "is")
            if is_ is not None: G[r][col] = "".join(x.text or "" for x in is_.iter(M + "t"))
            continue
        G[r][col] = sst[int(v.text)] if t == "s" else v.text
def cl(i):
    s = ""
    while i: i, r = divmod(i - 1, 26); s = chr(65 + r) + s
    return s
idrow = {re.sub(r"\s+", "", v): c for c, v in G[12].items()}
fmap = {r["source_key"]: r for r in csv.DictReader(open(ROOT / "config/source_maps/mext.csv", encoding="utf-8"))}
food_row = {G[r]["B"].strip(): r for r in G if r >= 13 and G[r].get("B", "").strip()}
out = [r for r in csv.DictReader(open(ROOT / "out/food_values_long.csv", encoding="utf-8")) if r["data_source"] == "mext_japan" and r["value_type"] != "borrowed" and r["value_type"] != "derived"]
foods = {f["food_id"]: f for f in csv.DictReader(open(ROOT / "out/unified/foods.csv", encoding="utf-8"))}
bad = []
def judge(s):
    """expected (value_type, value, derivation_flag) for a raw cell text"""
    if s == "Tr": return "trace", 0.0, False
    if s == "(Tr)": return "trace", 0.0, True
    if s == "*": return "pending", None, False
    m = re.fullmatch(r"\((\d+(?:\.\d+)?)\)", s)
    if m: return "reported", float(m.group(1)), True
    m = re.fullmatch(r"(\d+(?:\.\d+)?)†", s)
    if m: return "reported", float(m.group(1)), False
    if re.fullmatch(r"\d+(?:\.\d+)?(?:E-?\d+)?", s): return "reported", float(s), False
    return None
random.seed(seed)
for r in random.sample(out, n):
    fid = r["food_uid"].split(":")[1]; key = re.search(r"\[([^\]]+)\]$", r["original_label"]).group(1)
    raw = G[food_row[fid]].get(idrow[key]); s = (raw or "").strip()
    exp = judge(s)
    if exp is None: bad.append((fid, key, f"raw cell {raw!r} should not have produced a row")); continue
    vt, val, est = exp
    if r["original_value"].strip() != s and not (re.fullmatch(r"-?\d+(\.\d+)?(E-?\d+)?", s) and math.isclose(float(r["original_value"]), float(s), rel_tol=1e-12)):
        bad.append((fid, key, f"original_value {r['original_value']!r} vs raw {raw!r}"))
    if r["value_type"] != vt: bad.append((fid, key, f"type {r['value_type']} vs {vt} for {s!r}"))
    elif val is None and r["value"] != "": bad.append((fid, key, "pending stored a number"))
    elif val is not None and not math.isclose(float(r["value"]), val, rel_tol=1e-12, abs_tol=1e-12): bad.append((fid, key, f"value {r['value']} vs {val}"))
    if est != bool(r["derivation"] and "estimated" in r["derivation"]): bad.append((fid, key, f"estimated flag for {s!r}: {r['derivation']!r}"))
    if fmap[key]["code"] != r["code"] or float(fmap[key]["factor"]) != 1.0: bad.append((fid, key, "map code/factor"))
    if G[food_row[fid]]["D"].strip() != foods[r["food_uid"]]["name_original"]: bad.append((fid, key, "food name differs"))
have = {(r["food_uid"], r["code"]) for r in out}
checked = 0; keys = list(fmap); fids = list(food_row)
while checked < n:
    k = random.choice(keys); f = random.choice(fids)
    s = (G[food_row[f]].get(idrow[k]) or "").strip()
    if s in ("", "-"): continue
    checked += 1
    if (f"mext_japan:{f}", fmap[k]["code"]) not in have: bad.append((f, k, f"raw {s!r} missing from output"))
cnt = defaultdict(int); lab = {(r["food_uid"], re.search(r"\[([^\]]+)\]$", r["original_label"]).group(1)): r for r in out}
for f, rr in food_row.items():
    for k in fmap:
        s = (G[rr].get(idrow[k]) or "").strip(); o = lab.get((f"mext_japan:{f}", k))
        if s in ("", "-"):
            cnt["-/blank"] += 1
            if o: bad.append((f, k, f"{s!r} produced a row"))
        else:
            cnt["value"] += 1
            if not o: bad.append((f, k, f"{s!r} missing"))
chap = [x for x in sheets if x != "表全体"]
print(f"mext_japan: {n} output->raw, {checked} raw->output; population {dict(cnt)}; foods in sheet {len(food_row)}, in build {sum(1 for u in foods if u.startswith('mext_japan:'))}; chapter sheets ignored {len(chap)}; mismatches {len(bad)}")
for b in bad[:25]: print("  MISMATCH", b)
