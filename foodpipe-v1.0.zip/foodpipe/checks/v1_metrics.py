"""Before/after counts for the v1.0 review findings. usage: python3 -I checks/v1_metrics.py TAG  (reads out/ and out/unified/; writes reports/v1_metrics_TAG.json)
The review evidence (REVIEW_evidence.zip) is read from the directory given in env EVIDENCE (default /tmp/rv)."""
import json, os, re, sys
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
tag = sys.argv[1]; EV = Path(os.environ.get("EVIDENCE", "/tmp/rv"))
U = ROOT / "out/unified"
f = pd.read_csv(U / "foods.csv", dtype=str, keep_default_na=False)
fn = pd.read_csv(U / "food_nutrients.csv", low_memory=False)
cm = pd.read_csv(U / "canonical_members.csv"); cf = pd.read_csv(U / "canonical_foods.csv")
fw_cols = pd.read_csv(U / "foods_wide.csv", nrows=0).columns.tolist()
M = {}
# ---- B1
pat = (f.source_id == "cofid") & f.name_original.str.contains(r"weighed (?:with|whole|as served|as whole)", case=False, regex=True) | \
      ((f.source_id == "usda_fdc_foundation") & f.name_original.str.contains(r"\(0% moisture\)", regex=True))
b1 = f[pat]; ids = set(b1.food_id)
M["B1_records_in_scope"] = len(b1)
M["B1_labelled_per_100g_edible_portion"] = int((b1.basis == "per 100 g edible portion").sum())
M["B1_is_preferred"] = int((b1.is_preferred.astype(str) == "True").sum())
cs = cm.groupby("canonical_id").size()
M["B1_in_multi_member_clusters"] = int(cm[cm.food_id.isin(ids)].canonical_id.map(cs).gt(1).sum())
bor = fn[fn.value_type == "borrowed"]
M["B1_borrowed_values_into_or_from"] = int((bor.food_id.isin(ids) | bor.donor_food_id.isin(ids)).sum())
dr = pd.read_csv(ROOT / "out/density_rank.csv", usecols=["food_uid"]); M["B1_in_density_ranking"] = int(dr.food_uid.isin(ids).sum())
# ---- M1
nd = pd.read_csv(EV / "cnf_nonderived_ndb_links.csv", dtype=str)
nd_pairs = set(zip(nd.cnf_uid, nd.usda_uid)) | set(zip(nd.usda_uid, nd.cnf_uid))
M["M1_borrowed_with_same_origin_note"] = int(bor.note.fillna("").str.contains("same-origin").sum())
M["M1_borrowed_values_via_the_346_pairs"] = int(sum((a, b) in nd_pairs for a, b in zip(bor.food_id, bor.donor_food_id)))
cmx = cm.merge(cm, on="canonical_id"); cmx = cmx[cmx.food_id_x < cmx.food_id_y]
M["M1_of_346_pairs_in_same_cluster"] = int(sum((a, b) in nd_pairs for a, b in zip(cmx.food_id_x, cmx.food_id_y)))
# ---- M2 (the 69 confirmed wrong clusters, by members of the v0.3 clusters)
wp = ROOT / "reports/v03_wrong69_members.json"
if tag == "before" and not wp.exists():
    ww = pd.read_csv(EV / "confirmed_wrong_clusters.csv")
    wp.write_text(json.dumps({c: cm[cm.canonical_id == c].food_id.tolist() for c in ww.canonical_id}))
w69 = json.loads(wp.read_text()); cid_of = dict(zip(cm.food_id, cm.canonical_id))
still = 0; gone_sets = []
for c, mem in w69.items():
    cl = pd.Series([cid_of.get(m) for m in mem]).dropna()
    if cl.duplicated(keep=False).any(): still += 1
M["M2_confirmed_wrong_clusters_still_merged"] = still; M["M2_confirmed_wrong_clusters_total"] = len(w69)
gl = ROOT / "out/match_guard_log.csv"; M["M2_guard_log_rows"] = int(len(pd.read_csv(gl))) if gl.exists() else 0
# ---- M3
lk = pd.read_csv(EV / "enrichment_leakage.csv", usecols=["food_id", "nutrient_code", "donor_food_id"])
keys = set(zip(lk.food_id, lk.nutrient_code, lk.donor_food_id))
M["M3_leaked_values_present"] = int(sum(k in keys for k in zip(bor.food_id, bor.nutrient_code, bor.donor_food_id)))
M["M3_leaked_foods_present"] = len({k[0] for k in zip(bor.food_id, bor.nutrient_code, bor.donor_food_id) if k in keys})
# ---- M4
M["M4_cnf_values"] = int(((fn.data_source == "cnf") & (fn.value_type != "borrowed")).sum())
M["M4_withheld_values_file_rows"] = int(len(pd.read_csv(ROOT / "out/withheld_values.csv"))) if (ROOT / "out/withheld_values.csv").exists() else 0
sw = fn[(fn.data_source == "swiss_fcdb") & (fn.value_type != "borrowed")]
M["M4_swiss_values_from_IFCT_2290"] = int(sw.derivation.fillna("").str.contains(r"source 2290\b").sum()) if "derivation" in fn.columns else "n/a (no derivation column)"
M["M4_swiss_values"] = len(sw)
# ---- m4
fw = pd.read_csv(U / "foods_wide.csv", usecols=["food_id", "is_preferred", "energy_kcal", "protein_g", "fat_g", "status", "source_id"], low_memory=False)
pref = fw[fw.is_preferred.astype(str) == "True"]
M["m4_preferred_without_energy"] = int(pref.energy_kcal.isna().sum())
M["m4_preferred_without_energy_protein_fat"] = int((pref.energy_kcal.isna() | pref.protein_g.isna() | pref.fat_g.isna()).sum())
hm = fw[fw.energy_kcal.notna() & fw.protein_g.notna() & fw.fat_g.notna() & (fw.status == "active")].food_id
M["m4_preferred_without_macros_but_sibling_has_them"] = int(sum(
    1 for c, g in cm[cm.food_id.isin(pref.food_id[pref.energy_kcal.isna() | pref.protein_g.isna() | pref.fat_g.isna()])].groupby("canonical_id")
    if cm[cm.canonical_id == c].food_id.isin(hm).any())) if False else None
pb = fw[fw.food_id.isin(["usda_fdc_foundation:2758989", "usda_fdc_foundation:2262072"])].set_index("food_id")["status"].to_dict()
M["m4_peanut_butter_2758989_vs_2262072_status"] = pb
# ---- item 7
fnc = fn.columns.tolist()
M["I7_food_nutrients_has_derivation"] = "derivation" in fnc; M["I7_food_nutrients_has_licence"] = "licence" in fnc
M["I7_foods_wide_has_estimated_nutrients"] = "estimated_nutrients" in fw_cols
M["I7_food_nutrients_dup_key_food_nutrient"] = int(fn.duplicated(["food_id", "nutrient_code"]).sum())
M["I7_food_nutrients_dup_key_with_value_type"] = int(fn.duplicated(["food_id", "nutrient_code", "value_type"]).sum())
meta = json.loads((U / "metadata.json").read_text()); M["I7_metadata_version"] = meta["version"]
M["I7_notice_has_as_is"] = "as is" in (U / "NOTICE.txt").read_text().lower() and "not medical advice" in (U / "NOTICE.txt").read_text().lower()
M["I7_ciqual_changes_notice_mentions_derived"] = any("derived" in c["changes_made"] for c in meta["citations"] if c["source_id"] == "ciqual")
M["I7_cnf_changes_notice_mentions_derived"] = any("derived" in c["changes_made"] for c in meta["citations"] if c["source_id"] == "cnf")
M["I7_legacy_out_csv_with_no_citation_cols"] = [p for p in ("foods_wide.csv", "density_rank.csv", "qa_flags.csv") if (ROOT / "out" / p).exists()]
# stable ids: preferred-derived
import hashlib
exp = {"cf_" + hashlib.md5(p.encode()).hexdigest()[:10] for p in cf.preferred_food_id.dropna() if p}
M["I7_canonical_id_derived_from_preferred_food_id"] = f"{len(set(cf.canonical_id) & exp)}/{len(cf)}"
M["clusters"] = len(cf); M["multi_source_clusters"] = int((cf.n_sources > 1).sum()); M["foods"] = len(f)
M["active"] = int((f.status == "active").sum()); M["superseded"] = int((f.status == "superseded").sum())
(ROOT / "reports").mkdir(exist_ok=True)
(ROOT / f"reports/v1_metrics_{tag}.json").write_text(json.dumps(M, indent=1, default=str))
print(json.dumps(M, indent=1, default=str))
