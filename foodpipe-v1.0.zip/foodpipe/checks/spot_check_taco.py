"""Independent spot-check for TACO: the build reads the .xls with pandas/xlrd; this converts the same file with LibreOffice to
xlsx (a different parser) and reads the XML directly. (1) N output values -> raw cell, (2) N raw cells -> output,
(3) full-population token check (Tr / NA / * / malformed / blank)."""
import csv, math, random, re, subprocess, sys, tempfile, zipfile
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
seed = int(sys.argv[2]) if len(sys.argv) > 2 else 42
src = next((ROOT / "data/incoming/taco").glob("*.xls"))
tmp = Path(tempfile.mkdtemp(prefix="taco_check_"))
subprocess.run(["soffice", "--headless", "--convert-to", "xlsx", "--outdir", str(tmp), str(src)], check=True, capture_output=True, timeout=240)
xlsx = next(tmp.glob("*.xlsx"))
M = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
RID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
z = zipfile.ZipFile(xlsx)
sst = ["".join(t.text or "" for t in si.iter(M + "t")) for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall(M + "si")]
rels = {r.get("Id"): r.get("Target") for r in ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))}
sheets = {s.get("name"): "xl/" + rels[s.get(RID)].lstrip("/").replace("xl/", "") for s in ET.fromstring(z.read("xl/workbook.xml")).find(M + "sheets")}
def cn(c):
    x = 0
    for ch in c: x = x * 26 + ord(ch) - 64
    return x - 1
def grid(name):
    G = defaultdict(dict)
    for row in ET.fromstring(z.read(sheets[name])).find(M + "sheetData"):
        for c in row:
            col = re.match(r"[A-Z]+", c.get("r")).group(); r = int(c.get("r")[len(col):])
            v = c.find(M + "v"); t = c.get("t")
            if v is None: continue
            G[r][cn(col)] = sst[int(v.text)] if t == "s" else v.text
    return G
SH = {"main": grid("CMVCol taco3"), "fa": grid("AGtaco3")}
rowof = {}
for k, G in SH.items():
    d = {}
    for r, cells in G.items():
        c0 = cells.get(0, "")
        if re.fullmatch(r"\d+(\.0+)?", c0.strip()): d[int(float(c0))] = r
    rowof[k] = d
fmap = {r["source_key"]: r for r in csv.DictReader(open(ROOT / "config/source_maps/taco.csv", encoding="utf-8"))}
out = [r for r in csv.DictReader(open(ROOT / "out/food_values_long.csv", encoding="utf-8")) if r["data_source"] == "taco" and r["value_type"] != "borrowed" and r["value_type"] != "derived"]
foods = {f["food_id"]: f for f in csv.DictReader(open(ROOT / "out/unified/foods.csv", encoding="utf-8"))}
key_of = {}
for k, m in fmap.items():
    key_of[(m["code"], m["source_label"], m["source_unit"])] = k
bad = []
def judge(s):
    if s == "Tr": return "trace", 0.0
    if s == "NA": return "not_applicable", None
    if s == "*": return "pending", None
    f = re.sub(r"^[,.]+", "", s).replace(",", ".")
    try: return "reported", float(f)
    except ValueError: return "pending", None
random.seed(seed)
def lookup(r):
    label = r["original_label"]; k = next(k for k, m in fmap.items() if m["code"] == r["code"] and label.startswith(m["source_label"]) and f"({m['source_unit']})" in label)
    sheet, col = k.split(":"); fid = int(r["food_uid"].split(":")[1])
    return k, SH[sheet][rowof[sheet][fid]].get(int(col))
for r in random.sample(out, n):
    k, raw = lookup(r)
    if raw is None: bad.append((r["food_uid"], r["code"], "raw cell empty")); continue
    s = raw.strip(); vt, val = judge(s)
    if vt != r["value_type"]: bad.append((r["food_uid"], r["code"], f"type {r['value_type']} vs {vt} for {raw!r}")); continue
    if val is None and r["value"] != "": bad.append((r["food_uid"], r["code"], "NaN expected"))
    elif val is not None and not math.isclose(float(r["value"]), val * float(fmap[k]["factor"]), rel_tol=1e-9, abs_tol=1e-12): bad.append((r["food_uid"], r["code"], f"value {r['value']} vs {val} (raw {raw!r})"))
    ov = r["original_value"].strip()
    if ov != s and not (re.fullmatch(r"-?\d+(\.\d+)?(E-?\d+)?", s) and re.fullmatch(r"-?\d+(\.\d+)?(e-?\d+)?", ov) and math.isclose(float(ov), float(s), rel_tol=1e-9, abs_tol=1e-12)):
        bad.append((r["food_uid"], r["code"], f"original_value {ov!r} vs raw {raw!r}"))
    nm = SH["main"][rowof["main"][int(r["food_uid"].split(":")[1])]].get(1, "").strip()
    if nm != foods[r["food_uid"]]["name_original"]: bad.append((r["food_uid"], r["code"], "food name differs"))
have = {(r["food_uid"], r["code"]) for r in out}
checked = 0; keys = list(fmap)
while checked < n:
    k = random.choice(keys); sheet, col = k.split(":"); fid = random.choice(list(rowof[sheet]))
    raw = SH[sheet][rowof[sheet][fid]].get(int(col))
    if raw is None or raw.strip() == "": continue
    checked += 1
    if (f"taco:{fid}", fmap[k]["code"]) not in have: bad.append((fid, k, f"raw {raw!r} missing from output"))
cnt = defaultdict(int)
present = defaultdict(int)
for r in out: present[(r["food_uid"], r["code"])] += 1
for k, m in fmap.items():
    sheet, col = k.split(":")
    for fid, rr in rowof[sheet].items():
        raw = SH[sheet][rr].get(int(col)); s = (raw or "").strip()
        if s == "": cnt["blank"] += 1
        else:
            cnt["filled"] += 1
            if s in ("Tr", "NA", "*"): cnt[s] += 1
            if (f"taco:{fid}", m["code"]) not in have: bad.append((fid, k, f"{s!r} missing"))
nfoods = sum(1 for u in foods if u.startswith("taco:"))
print(f"taco: {n} output->raw, {checked} raw->output; population {dict(cnt)}; foods in sheet {len(rowof['main'])}, in build {nfoods}; mismatches {len(bad)}")
for b in bad[:25]: print("  MISMATCH", b)
