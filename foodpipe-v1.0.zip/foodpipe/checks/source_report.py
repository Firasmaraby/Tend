"""Per-source report from the last build: foods, values, value types, nutrient coverage, QA flags.
usage: python checks/source_report.py <source_id> [--json out.json]"""
import json, sys
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
sid = sys.argv[1]
foods = pd.read_csv(ROOT / "out/unified/foods.csv", keep_default_na=False, na_values=[""], low_memory=False)
vals = pd.read_csv(ROOT / "out/food_values_long.csv", keep_default_na=False, na_values=[""], low_memory=False)
flags = pd.read_csv(ROOT / "out/qa_flags.csv", keep_default_na=False, na_values=[""], low_memory=False)
nut = pd.read_csv(ROOT / "config/nutrients.csv", keep_default_na=False)
f = foods[foods.source_id == sid]; uids = set(f.food_id)
v = vals[vals.food_uid.isin(uids)]
fl = flags[flags.food_uid.isin(uids)]
nf = len(f)
cov = v[v.value.notna()].groupby("code").food_uid.nunique().reindex(nut.code).fillna(0).astype(int)
res = dict(source=sid, foods=nf, values=len(v), value_types=v.value_type.value_counts().to_dict(),
           values_with_number=int(v.value.notna().sum()),
           nutrients_covered=int((cov > 0).sum()), nutrients_total=len(nut),
           not_covered=[c for c in nut.code if cov[c] == 0],
           coverage_pct={c: round(100 * cov[c] / nf, 1) for c in nut.code if cov[c] > 0},
           qa=fl.groupby(["check", "severity"]).size().rename("n").reset_index().to_dict("records"),
           groups=f.food_group_original.value_counts().head(30).to_dict() if "food_group_original" in f else {})
print(f"== {sid}: {nf} foods, {len(v)} value rows ({res['values_with_number']} numeric), "
      f"{res['nutrients_covered']}/{res['nutrients_total']} canonical nutrients")
print("value types:", res["value_types"])
print("not covered:", ", ".join(res["not_covered"]) or "-")
lo = sorted(res["coverage_pct"].items(), key=lambda kv: kv[1])[:12]
print("lowest coverage % of foods:", ", ".join(f"{c} {p}" for c, p in lo))
print("QA flags:", "; ".join(f"{r['check']}/{r['severity']}={r['n']}" for r in res["qa"]) or "none")
if "--json" in sys.argv:
    Path(sys.argv[sys.argv.index("--json") + 1]).write_text(json.dumps(res, indent=1, default=str))
