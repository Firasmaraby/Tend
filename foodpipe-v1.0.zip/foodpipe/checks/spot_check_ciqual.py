"""Independent spot-check for Ciqual: the build reads the XML release; this compares against the xlsx copy of the same
table (a different file and layout: wide, French headers). (1) N output values -> xlsx cell text, (2) N xlsx cells -> output."""
import csv, random, re, sys
from pathlib import Path
import openpyxl

ROOT = Path(__file__).resolve().parent.parent
n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
seed = int(sys.argv[2]) if len(sys.argv) > 2 else 42
norm = lambda s: re.sub(r"[\s/]+", "", s or "")
wb = openpyxl.load_workbook(next((ROOT / "data/incoming/ciqual").glob("*.xlsx")), read_only=True, data_only=True)
ws = wb["composition nutritionnelle"]
rows = list(ws.iter_rows(values_only=True))
hdr = [norm(h) for h in rows[0]]
col_of = {h: i for i, h in enumerate(hdr)}
food = {str(r[6]).strip(): r for r in rows[1:]}
# const_code -> xlsx column, through the French label in the XML constituent file (read as plain text, no XML parser)
import xml.etree.ElementTree as ET
cfile = next((ROOT / "data/incoming/ciqual").glob("const_*.xml"))
fr = {c.find("const_code").text.strip(): c.find("const_nom_fr").text.strip() for c in ET.parse(cfile).getroot()}
fmap = {r["source_key"]: r for r in csv.DictReader(open(ROOT / "config/source_maps/ciqual.csv", encoding="utf-8"))}
bad = []
colfor = {}
for k in fmap:
    h = norm(fr[k])
    if h not in col_of: bad.append((k, f"xlsx column for {fr[k]!r} not found")); continue
    colfor[k] = col_of[h]
out = [r for r in csv.DictReader(open(ROOT / "out/food_values_long.csv", encoding="utf-8")) if r["data_source"] == "ciqual" and r["value_type"] != "borrowed" and r["value_type"] != "derived"]
random.seed(seed)
foods = {f["food_id"]: f for f in csv.DictReader(open(ROOT / "out/unified/foods.csv", encoding="utf-8"))}
for r in random.sample(out, n):
    k = re.search(r"\[(\d+)\]$", r["original_label"]).group(1)
    aid = r["food_uid"].split(":")[1]
    cell = " ".join(str(food[aid][colfor[k]]).split())
    if cell != r["original_value"]: bad.append((aid, r["code"], f"original_value {r['original_value']!r} vs xlsx {cell!r}")); continue
    if cell == "traces": ok = r["value_type"] == "trace" and float(r["value"]) == 0
    elif cell.startswith("<"): ok = r["value_type"] == "below_lod" and r["value"] == ""
    else: ok = r["value_type"] == "reported" and float(r["value"]) == float(cell.replace(",", "."))
    if not ok: bad.append((aid, r["code"], f"value/type {r['value']!r}/{r['value_type']} for xlsx {cell!r}"))
    if float(fmap[k]["factor"]) != 1.0 or fmap[k]["code"] != r["code"]: bad.append((aid, r["code"], "map factor/code"))
    if " ".join(str(food[aid][7]).split()) != " ".join(foods[r["food_uid"]]["name_original"].split()): bad.append((aid, r["code"], "food name differs"))
have = {(r["food_uid"], r["code"]) for r in out}
checked = 0
keys = list(colfor); ids = list(food)
while checked < n:
    k = random.choice(keys); aid = random.choice(ids)
    cell = food[aid][colfor[k]]
    if cell is None or str(cell).strip() in ("", "-"): continue
    checked += 1
    if (f"ciqual:{aid}", fmap[k]["code"]) not in have: bad.append((aid, fmap[k]["code"], f"xlsx cell {cell!r} ({k}) missing from output"))
# special tokens must never be a number: every '<' / traces cell in the xlsx maps to the right value_type
kinds = {"below_lod": 0, "trace": 0}
for r in out:
    if r["value_type"] == "below_lod":
        kinds["below_lod"] += 1
        if r["value"] != "" or not r["original_value"].startswith("<"): bad.append((r["food_uid"], r["code"], "below_lod stored a number"))
    if r["value_type"] == "trace": kinds["trace"] += 1
print(f"ciqual: checked {n} output values -> xlsx and {checked} xlsx cells -> output, mismatches {len(bad)}; below_lod rows {kinds['below_lod']}, trace rows {kinds['trace']}")
for b in bad[:25]: print("  MISMATCH", b)
# full-population check of the special tokens (not sampled): every '<' / 'traces' xlsx cell in a mapped column
vt = {(r["food_uid"], r["original_label"].rsplit("[", 1)[1].rstrip("]")): r for r in out}
full_bad = 0; seen = {"<": 0, "traces": 0}
for aid, r in food.items():
    for k, ci in colfor.items():
        cell = " ".join(str(r[ci]).split()) if r[ci] is not None else ""
        kind = "<" if cell.startswith("<") else ("traces" if cell == "traces" else None)
        if not kind: continue
        seen[kind] += 1
        o = vt.get((f"ciqual:{aid}", k))
        if o is None:
            # only legitimate when a higher-priority constituent supplied the same canonical code
            if (f"ciqual:{aid}", fmap[k]["code"]) in have and int(fmap[k]["priority"]) > 1: continue
            full_bad += 1; print("  MISSING", aid, k, cell); continue
        want = "below_lod" if kind == "<" else "trace"
        if o["value_type"] != want or o["original_value"] != cell or (kind == "<" and o["value"] != ""): full_bad += 1; print("  WRONG", aid, k, cell, o["value_type"], o["value"])
print(f"ciqual full special-token check: {seen['<']} '<x' cells and {seen['traces']} 'traces' cells in mapped columns, problems {full_bad}")
