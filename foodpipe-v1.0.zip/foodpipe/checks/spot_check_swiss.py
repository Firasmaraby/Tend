"""Independent spot-check for the Swiss database: reads the xlsx straight from its XML (zipfile + ElementTree).
(1) N output values -> raw cell, (2) N raw cells -> output, (3) full-population checks of n.d./tr./'<x' tokens,
(4) no branded-sheet food is in the output."""
import csv, re, math, random, sys, zipfile
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
seed = int(sys.argv[2]) if len(sys.argv) > 2 else 42
xlsx = next((ROOT / "data/incoming/swiss_fcdb").glob("*.xlsx"))
M = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
RID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
z = zipfile.ZipFile(xlsx)
sst = ["".join(t.text or "" for t in si.iter(M + "t")) for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall(M + "si")]
rels = {r.get("Id"): r.get("Target") for r in ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))}
sheets = {s.get("name"): "xl/" + rels[s.get(RID)].lstrip("/").replace("xl/", "") for s in ET.fromstring(z.read("xl/workbook.xml")).find(M + "sheets")}

def grid(name):
    g = defaultdict(dict)
    for row in ET.fromstring(z.read(sheets[name])).find(M + "sheetData"):
        for c in row:
            col = re.match(r"[A-Z]+", c.get("r")).group(); r = int(c.get("r")[len(col):])
            v = c.find(M + "v"); t = c.get("t")
            if v is None: continue
            g[r][col] = sst[int(v.text)] if t == "s" else v.text
    return g

def cn(c):
    x = 0
    for ch in c: x = x * 26 + ord(ch) - 64
    return x
def cl(i):
    s = ""
    while i: i, r = divmod(i - 1, 26); s = chr(65 + r) + s
    return s

G = grid("Generic Foods")
hdr = G[3]
colof = {h: c for c, h in hdr.items() if h not in ("Derivation of value", "Source")}
fmap = {r["source_key"]: r for r in csv.DictReader(open(ROOT / "config/source_maps/swiss.csv", encoding="utf-8"))}
ids = {r: G[r]["A"] for r in G if r >= 4 and "A" in G[r]}
row_of = {v: r for r, v in ids.items()}
out = [r for r in csv.DictReader(open(ROOT / "out/food_values_long.csv", encoding="utf-8")) if r["data_source"] == "swiss_fcdb" and r["value_type"] != "borrowed"]
foods = {f["food_id"]: f for f in csv.DictReader(open(ROOT / "out/unified/foods.csv", encoding="utf-8"))}
bad = []
random.seed(seed)
for r in random.sample(out, n):
    fid = r["food_uid"].split(":")[1]; k = r["original_label"]
    raw = G[row_of[fid]].get(colof[k])
    if raw is None: bad.append((fid, r["code"], "raw cell empty")); continue
    s = raw.strip()
    if r["original_value"].strip() != s and not (re.fullmatch(r"-?\d+(\.\d+)?(E-?\d+)?", s) and math.isclose(float(r["original_value"]), float(s), rel_tol=1e-12)):
        bad.append((fid, r["code"], f"original_value {r['original_value']!r} vs raw {raw!r}"))
    if s == "tr.": ok = r["value_type"] == "trace" and float(r["value"]) == 0
    elif s.startswith("<"): ok = r["value_type"] == "below_lod" and r["value"] == ""
    elif s == "n.d.": ok = False
    else: ok = r["value_type"] == "reported" and math.isclose(float(r["value"]), float(s), rel_tol=1e-12)
    if not ok: bad.append((fid, r["code"], f"value/type {r['value']!r}/{r['value_type']} for raw {raw!r}"))
    if fmap[k]["code"] != r["code"] or float(fmap[k]["factor"]) != 1.0: bad.append((fid, r["code"], "map code/factor"))
    if G[row_of[fid]]["D"].strip() != foods[r["food_uid"]]["name_original"]: bad.append((fid, r["code"], "food name differs"))
    nxt = cl(cn(colof[k]) + 1); src = cl(cn(colof[k]) + 2)
    d = G[row_of[fid]].get(nxt); sid = G[row_of[fid]].get(src)
    want = "; ".join(x for x in [d if d not in (None, "-") else None, f"source {sid}" if sid is not None else None] if x) or ""
    if (r["derivation"] or "") != want: bad.append((fid, r["code"], f"derivation {r['derivation']!r} vs {want!r}"))
have = {(r["food_uid"], r["code"]) for r in out}
EXCL = {"2290"}   # IFCT India: removed on purpose (sources.yaml swiss_fcdb.upstream_decision); must be listed in out/removed_upstream_values.csv
def excluded(rr, k):
    sv = G[rr].get(cl(cn(colof[k]) + 2))
    return bool(sv) and any(t in EXCL for t in re.split(r"[\s,;/]+", sv.strip()))
removed_listed = {(r["food_uid"], r["code"]) for r in csv.DictReader(open(ROOT / "out/removed_upstream_values.csv", encoding="utf-8"))}
checked = 0
keys = list(fmap)
while checked < n:
    k = random.choice(keys); rr = random.choice(list(ids))
    raw = G[rr].get(colof[k])
    if raw is None or raw.strip() in ("", "n.d."): continue
    if excluded(rr, k): continue
    checked += 1
    if (f"swiss_fcdb:{ids[rr]}", fmap[k]["code"]) not in have: bad.append((ids[rr], fmap[k]["code"], f"raw {raw!r} missing from output"))
# full population: tokens
cnt = defaultdict(int)
lab = {(r["food_uid"], r["original_label"]): r for r in out}
for rr, fid in ids.items():
    for k in fmap:
        raw = G[rr].get(colof[k])
        if raw is None: continue
        s = raw.strip(); key = (f"swiss_fcdb:{fid}", k); o = lab.get(key)
        if s == "n.d.":
            cnt["n.d."] += 1
            if o: bad.append((fid, k, "n.d. cell produced a row"))
        elif s == "tr.":
            cnt["tr."] += 1
            if not o or o["value_type"] != "trace": bad.append((fid, k, "tr. not trace"))
        elif s.startswith("<"):
            cnt["<x"] += 1
            if not o or o["value_type"] != "below_lod" or o["value"] != "": bad.append((fid, k, "<x not below_lod"))
        else:
            if excluded(rr, k):
                cnt["removed (IFCT 2290)"] += 1
                if o or (key[0], fmap[k]["code"]) not in removed_listed: bad.append((fid, k, "IFCT-sourced value not removed / not listed"))
                continue
            cnt["num"] += 1
            if not o: bad.append((fid, k, f"number {s} missing"))
# branded foods absent
B = grid("Branded foods"); bid = {B[r]["A"] for r in B if r >= 4 and "A" in B[r]}
leak = [i for i in bid if f"swiss_fcdb:{i}" in foods and i not in ids.values()]
if leak: bad.append(("branded", len(leak), "branded-sheet foods present in output"))
print(f"swiss: {n} output values -> raw, {checked} raw cells -> output; population: {dict(cnt)}; branded sheet foods {len(bid)}, leaked {len(leak)}; mismatches {len(bad)}")
for b in bad[:25]: print("  MISMATCH", b)
