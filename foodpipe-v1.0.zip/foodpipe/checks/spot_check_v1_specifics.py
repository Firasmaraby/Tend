"""v1.0 specifics, independent of the build code (csv module): (1) every CNF value with Nutrient_Source 81/82/83 in a mapped nutrient is in the output,
unchanged; (2) the 4 Swiss IFCT values are absent and listed; (3) no 'same-origin' note on a borrowed value unless the CNF food is derived_from_usda;
(4) basis labels of the 240 B1 foods; (5) no non-standard-basis food is in a multi-member cluster or borrowed from / into."""
import csv, json, re, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
bad = []
mp = {r["source_key"]: r["code"] for r in csv.DictReader(open(ROOT / "config/source_maps/cnf.csv", encoding="utf-8"))}
raw = [r for r in csv.DictReader(open(ROOT / "data/incoming/cnf/Nutrient_Amount.csv", encoding="utf-8-sig")) if r["Nutrient_Source_Code"] in ("81", "82", "83")]
raw_all = len(raw); raw = [r for r in raw if r["Nutrient_Code"] in mp]
out = {}
for r in csv.DictReader(open(ROOT / "out/unified/food_nutrients.csv", encoding="utf-8")):
    if r["data_source"] == "cnf" and r["value_type"] != "borrowed": out[(r["food_id"], r["nutrient_code"])] = r
miss = 0
for r in raw:
    o = out.get((f"cnf:{r['Food_Code']}", mp[r["Nutrient_Code"]]))
    if not o or float(o["value"]) != float(r["Nutrient_Amount"]): miss += 1; bad.append(("cnf-released", r["Food_Code"], r["Nutrient_Code"]))
print(f"CNF values with Nutrient_Source 81/82/83: {raw_all} in the file, {len(raw)} in loaded nutrients, {len(raw) - miss} present unchanged in the output")
rem = list(csv.DictReader(open(ROOT / "out/removed_upstream_values.csv", encoding="utf-8")))
sw = [r for r in csv.DictReader(open(ROOT / "out/unified/food_nutrients.csv", encoding="utf-8")) if r["data_source"] == "swiss_fcdb" and r["value_type"] != "borrowed" and re.search(r"source 2290\b", r["derivation"] or "")]
print(f"Swiss IFCT 2290: {len(rem)} listed as removed, {len(sw)} still in food_nutrients"); bad += [("swiss", "still present", len(sw))] if sw else []
L = {r["cnf_uid"]: r for r in csv.DictReader(open(ROOT / "out/links/cnf_usda_derivation.csv", encoding="utf-8"))}
foods = {r["food_id"]: r for r in csv.DictReader(open(ROOT / "out/unified/foods.csv", encoding="utf-8"))}
n_so = 0
for r in csv.DictReader(open(ROOT / "out/unified/food_nutrients.csv", encoding="utf-8")):
    if r["value_type"] == "borrowed" and "same-origin" in (r["note"] or ""):
        n_so += 1
        c = r["food_id"] if r["food_id"].startswith("cnf:") else r["donor_food_id"]
        if L.get(c, {}).get("derived_from_usda") != "True": bad.append(("same-origin note on non-derived", r["food_id"], r["donor_food_id"]))
print(f"borrowed values with a same-origin note: {n_so}, all on CNF foods derived from USDA: {not any(b[0].startswith('same-origin') for b in bad)}")
nonstd = {k for k, r in foods.items() if r["basis"] != "per 100 g edible portion"}
b1 = [k for k, r in foods.items() if (r["source_id"] == "cofid" and re.search(r"weighed (?:with|whole|as served|as whole)", r["name_original"], re.I)) or
      (r["source_id"] == "usda_fdc_foundation" and "(0% moisture)" in r["name_original"])]
wrong = [k for k in b1 if foods[k]["basis"] not in ("per 100 g as purchased (incl. refuse)", "per 100 g dry matter")]
print(f"B1 foods {len(b1)}, wrong basis label {len(wrong)}"); bad += [("b1 label", k) for k in wrong]
cm = list(csv.DictReader(open(ROOT / "out/unified/canonical_members.csv", encoding="utf-8")))
size = {}
for r in cm: size[r["canonical_id"]] = size.get(r["canonical_id"], 0) + 1
multi = [r["food_id"] for r in cm if r["food_id"] in nonstd and size[r["canonical_id"]] > 1]
print(f"non-standard-basis foods ({len(nonstd)}) inside multi-member clusters: {len(multi)}"); bad += [("nonstd in cluster", m) for m in multi]
bor = [r for r in csv.DictReader(open(ROOT / "out/unified/food_nutrients.csv", encoding="utf-8")) if r["value_type"] == "borrowed" and (r["food_id"] in nonstd or r["donor_food_id"] in nonstd)]
print(f"borrowed values into or out of non-standard-basis foods: {len(bor)}"); bad += [("nonstd borrow", r["food_id"]) for r in bor]
print("mismatches:", len(bad)); [print("  ", b) for b in bad[:10]]
