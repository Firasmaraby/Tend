"""Independent spot-check for AFCD: reads the profiles xlsx straight from its XML (zipfile + ElementTree), not via openpyxl.
(1) N output values -> raw cell (with the map factor), (2) N raw cells -> output, (3) full-population count of numeric
mapped cells vs reported rows, (4) derived kcal = kJ/4.184 for every derived row, (5) food count, (6) liquids sheet adds no food."""
import csv, math, random, re, sys, zipfile
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
seed = int(sys.argv[2]) if len(sys.argv) > 2 else 42
xlsx = ROOT / "data/incoming/afcd/AFCD_Release_3_-_Nutrient_profiles.xlsx"
M = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
RID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
z = zipfile.ZipFile(xlsx)
sst = ["".join(t.text or "" for t in si.iter(M + "t")) for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall(M + "si")]
rels = {r.get("Id"): r.get("Target") for r in ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))}
sheets = {s.get("name"): "xl/" + rels[s.get(RID)].lstrip("/").replace("xl/", "") for s in ET.fromstring(z.read("xl/workbook.xml")).find(M + "sheets")}

def grid(name):
    g = defaultdict(dict)
    for row in ET.fromstring(z.read(sheets[name])).find(M + "sheetData"):
        for c in row:
            col = re.match(r"[A-Z]+", c.get("r")).group(); r = int(c.get("r")[len(col):])
            v = c.find(M + "v"); t = c.get("t")
            if v is None: continue
            g[r][col] = (sst[int(v.text)], "s") if t == "s" else (v.text, "n")
    return g

G = grid("All solids & liquids per 100 g")
hdr = {c: " ".join(v[0].split()) for c, v in G[3].items()}
colof = {h: c for c, h in hdr.items()}
fmap = {r["source_key"]: r for r in csv.DictReader(open(ROOT / "config/source_maps/afcd.csv", encoding="utf-8"))}
rowof = {G[r]["A"][0]: r for r in G if r >= 4 and "A" in G[r]}
out = [r for r in csv.DictReader(open(ROOT / "out/food_values_long.csv", encoding="utf-8")) if r["data_source"] == "afcd" and r["value_type"] != "borrowed"]
rep = [r for r in out if r["value_type"] == "reported"]
random.seed(seed)
bad = []
def check(r):
    key = r["food_uid"].split(":")[1]; lab = r["original_label"]; m = fmap[lab]
    cell = G[rowof[key]].get(colof[lab])
    if cell is None or cell[1] != "n": return f"{key} {lab}: raw cell empty/non-numeric {cell}"
    if float(cell[0]) != float(r["original_value"]): return f"{key} {lab}: original_value {r['original_value']} vs raw {cell[0]}"
    exp = float(cell[0]) * float(m["factor"])
    if not math.isclose(float(r["value"]), exp, rel_tol=1e-9, abs_tol=1e-12): return f"{key} {lab}: value {r['value']} vs expected {exp}"
    if r["code"] != m["code"]: return f"{key} {lab}: code {r['code']} vs {m['code']}"
    return None
for r in random.sample(rep, n):
    e = check(r)
    if e: bad.append(e)
# raw -> output
outkey = {(r["food_uid"].split(":")[1], r["original_label"]): r for r in rep}
cells = [(k, lab) for k, rw in rowof.items() for lab in fmap if colof[lab] in G[rw] and G[rw][colof[lab]][1] == "n"]
for k, lab in random.sample(cells, n):
    if (k, lab) not in outkey: bad.append(f"{k} {lab}: raw numeric cell missing from output")
# population
text_cells = [(k, lab) for k, rw in rowof.items() for lab in fmap if colof[lab] in G[rw] and G[rw][colof[lab]][1] == "s"]
pop_ok = len(cells) == len(rep) and set(cells) == set(outkey) and not text_cells
# derived kcal
kj = {r["food_uid"]: float(r["value"]) for r in out if r["code"] == "ENERC_KJ"}
der = [r for r in out if r["value_type"] == "derived"]
dbad = [r["food_uid"] for r in der if r["code"] != "ENERC_KCAL" or not math.isclose(float(r["value"]), kj[r["food_uid"]] / 4.184, rel_tol=1e-9)]
foods = [f for f in csv.DictReader(open(ROOT / "out/unified/foods.csv", encoding="utf-8")) if f["source_id"] == "afcd"]
print(f"afcd: {n} output->raw, {n} raw->output; population: raw numeric mapped cells {len(cells)}, text cells {len(text_cells)}, reported rows {len(rep)}, identical sets {pop_ok}")
print(f"  derived rows {len(der)}, bad derived {len(dbad)}; foods in sheet {len(rowof)}, in build {len(foods)}; mismatches {len(bad) + len(dbad) + (0 if pop_ok else 1) + (0 if len(foods)==len(rowof) else 1)}")
for b in bad[:20]: print("  MISMATCH", b)
