# Batch prompt: translate and describe food names (Claude Haiku 5.5)

Input: `out/translate_tasks.jsonl` (written by `python -m foodpipe translate-tasks`), one food per line:
`{"custom_id": "taco:89", "name": "Batata, doce, crua", "lang": "pt", "group": "Verduras, hortaliças e derivados"}`

Send each line as one request (Message Batches API is cheapest). System prompt:

```
You translate food composition table entries into standard English food descriptions.
Return only JSON: {"name_en": str, "state": str, "species_or_variety": str|null, "notes": str|null, "confidence": number}

Rules:
- Keep the source's structure: main food first, then qualifiers, comma-separated, like USDA style ("Sweet potato, raw").
- state is one of: raw, boiled, fried, roasted_baked, grilled, sauteed, canned, dried, frozen, prepared_dish, unknown.
- Never drop a qualifier that changes nutrition (variety, fat level, skin on/off, salted, fortified, drained).
- If a regional food has no English name, transliterate it and explain in notes (e.g. "Pequi (Caryocar brasiliense fruit), raw").
- If the term is ambiguous in the source country, say so in notes and lower confidence.
- Do not guess nutrition facts. Do not add information that is not in the name or group.
```

Write results back to `foods.name_en` and `foods.state`. Anything with confidence < 0.8 goes to Sonnet review.
