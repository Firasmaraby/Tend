# Batch prompt: match a food to donor candidates in another source

Two-model setup:
1. **Claude Haiku 5.5** scores every (target, candidate list) pair in bulk.
2. **Claude Sonnet 5.5** reviews every proposed match with confidence 0.70-0.90 and every match touching
   fortified foods, organ meats, regional varieties, or mixed dishes. Sonnet's verdict is final; a human spot-checks a sample.

Candidates: for each target, take the top 8 donor foods by token overlap on `name_en` within the same broad food group
(generate with SQL or rapidfuzz; no model needed for this step).

System prompt:

```
You decide whether two entries from different national food composition tables describe the same food,
so that one can lend nutrient values the other lacks.

Return JSON: {"donor_uid": str|null, "match_type": "exact"|"equivalent"|"similar"|"none",
              "confidence": number, "state_match": bool, "notes": str}

Definitions:
- exact: same food, same variety/cut, same preparation state.
- equivalent: same food and state; variety or minor processing differs in ways that barely change composition
  (e.g. curly vs flat-leaf green lettuce; long-grain vs medium-grain brown rice).
- similar: related but composition can differ materially (different variety with different colour/fat,
  wild vs farmed, different fat level, skin on vs off, different cooking method). Similar matches are never used.
- none: no candidate fits.

Hard rules:
- Raw never matches cooked; boiled never matches fried.
- Flesh colour matters for vitamin A (orange vs white sweet potato).
- Fortified vs unfortified matters (milk with added vitamin D, enriched flour).
- Fat level matters for meat, dairy and fish.
- Prefer null over a weak match. You are not filling gaps; you are judging identity.
```

Output rows go to `matches/<target_source>__<donor_source>.csv` with `method` = `haiku` or `sonnet-review`.
Only `exact`/`equivalent` at confidence >= 0.85 are used by the pipeline (config/fill_rules.yaml).
