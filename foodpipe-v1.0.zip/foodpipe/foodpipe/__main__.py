"""foodpipe command line.

  python -m foodpipe status            licence status and which input files are present
  python -m foodpipe build [--dev]     run the pipeline (--dev allows development mirrors when official files are absent)
  python -m foodpipe translate-tasks   write JSONL tasks for name translation (for a Haiku batch job)
"""
from __future__ import annotations

import argparse
import json
import sys

import pandas as pd

from . import dedup, density, export, fill, guard, links, normalize, qa, source_checks, translate, unified
from .adapters import ADAPTERS
from .common import BASIS_DRY, BASIS_PURCHASED, BASIS_STD, INCOMING, MIRROR, OUT, ROOT, load_sources


def resolve_inputs(dev: bool):
    sources = load_sources()
    chosen, report = {}, []
    for sid, s in sources.items():
        status = s.get("status")
        official = INCOMING / sid
        has_official = official.exists() and any(official.iterdir())
        mirror_rel = (s.get("dev_mirror") or "").split(" ")[0]
        mirror = ROOT / mirror_rel if mirror_rel else None
        has_mirror = bool(mirror and mirror.exists())
        if status != "approved":
            report.append((sid, status, "not ingested (licence not approved)"))
            continue
        if s.get("adapter") not in ADAPTERS:
            report.append((sid, status, f"adapter '{s.get('adapter')}' not written yet" + (" - files present" if has_official else " - waiting for files")))
            continue
        missing = [k for k in ("citation", "citation_short", "licence_notice", "changes_notice") if not s.get(k)]
        if missing:
            raise SystemExit(f"{sid}: approved source is missing citation fields {missing} in sources.yaml - "
                             "citations are mandatory, refusing to build")
        if has_official:
            chosen[sid] = dict(path=official, dev_mirror=False)
            report.append((sid, status, f"official files: {official.relative_to(ROOT)}"))
        elif dev and has_mirror:
            chosen[sid] = dict(path=mirror, dev_mirror=True)
            report.append((sid, status, f"DEV MIRROR: {mirror.relative_to(ROOT)}"))
        else:
            report.append((sid, status, "waiting for files in " + str(official.relative_to(ROOT))))
    return sources, chosen, report


def cmd_status(args):
    _, _, report = resolve_inputs(dev=True)
    for sid, status, msg in report:
        print(f"{status:9s} {sid:22s} {msg}")


def cmd_build(args):
    sources, chosen, report = resolve_inputs(args.dev)
    for sid, status, msg in report:
        print(f"{status:9s} {sid:22s} {msg}")
    if not chosen:
        sys.exit("nothing to build")
    foods, values = [], []
    for sid, inp in chosen.items():
        f, v = ADAPTERS[sources[sid]["adapter"]](sid, inp["path"])
        print(f"  loaded {sid}: {len(f)} foods, {len(v)} values")
        foods.append(f)
        values.append(v)
    foods = pd.concat(foods, ignore_index=True)
    values = pd.concat(values, ignore_index=True)
    foods = translate.apply(foods)
    values = normalize.harmonise(values)
    values = normalize.derive(values)
    foods["basis"] = source_checks.basis(foods, values)
    print(f"  foods not on a per-100 g basis (left out of density ranking, matching, borrowing and multi-source clusters): {int((foods['basis'] != BASIS_STD).sum())}")
    print("    " + str(foods.loc[foods['basis'] != BASIS_STD].groupby(['source_id', 'basis']).size().to_dict()))
    basis_flags = foods.loc[foods["basis"].isin([BASIS_PURCHASED, BASIS_DRY]), ["food_uid", "basis"]].assign(
        code=None, check="basis_not_edible_portion", severity="info",
        detail=lambda d: "values are published " + d["basis"] + "; NOT converted, not comparable with per-100 g edible portion")[
        ["food_uid", "code", "check", "severity", "detail"]]
    flags = pd.concat([qa.run(foods, values), source_checks.run(values), basis_flags], ignore_index=True)
    link_table, link_flags = links.cnf_usda(chosen, foods, values)
    if link_table is not None:
        flags = pd.concat([flags, link_flags], ignore_index=True)
        print(f"  cnf->usda links: {int(link_table['derived_from_usda'].sum())} CNF foods derived from USDA, "
              f"{int(link_table['usda_uid'].notna().sum())} linked by NDB code to a loaded SR Legacy food")
    n_before = len(foods)
    dates = dedup.release_dates(foods)
    status, ws_review = dedup.within_source(foods, values, dates)
    foods = foods.merge(status, on="food_uid", how="left")
    print(f"  within-source duplicates: {int((status['status'] == 'superseded').sum())} superseded, {len(ws_review)} left active for review")
    raw_matches = fill.load_matches(symmetric=False)
    foods_g = foods.assign(food_group=unified.assign_groups(foods))
    matches, glog = guard.apply(raw_matches, foods_g, values)
    checker = guard.make_checker(foods_g, values)
    new_g = glog[glog["rule"] != "v0.3_text_guard"]
    print(f"  match guard: {len(new_g)} exact/equivalent matches downgraded to similar this build "
          f"(+{int((glog['rule'] == 'v0.3_text_guard').sum())} already downgraded by the v0.3 text guard); log out/match_guard_log.csv")
    values, fill_log, skipped = fill.borrow(foods, values, matches)
    dens = density.score(foods, values)
    foods, canon_f, canon_m, cl_review = dedup.clusters(foods, values, status, dates, matches, checker)
    ws_review.to_csv(OUT / "dedup_within_source_review.csv", index=False)
    cl_review.to_csv(OUT / "dedup_cluster_review.csv", index=False)
    checks = dedup.checks(foods, n_before, canon_f, canon_m)
    for name, ok, detail in checks:
        print(f"  dedup check {'OK  ' if ok else 'FAIL'} {name}: {detail}")
    print(f"  clusters: {len(canon_f)} ({int((canon_f['n_members'] > 1).sum())} with 2+ sources), review queue {len(cl_review)}")
    meta = dict(inputs={k: dict(path=str(v["path"].relative_to(ROOT)), dev_mirror=v["dev_mirror"]) for k, v in chosen.items()})
    db = export.write(foods, values, flags, fill_log, dens, {k: sources[k] for k in chosen}, meta)
    ud = unified.build(foods, values, flags, {k: sources[k] for k in chosen}, meta, canon=(canon_f, canon_m))
    import sqlite3
    with sqlite3.connect(db) as con:
        canon_f.to_sql("canonical_foods", con, index=False, if_exists="replace")
        canon_m.to_sql("canonical_members", con, index=False, if_exists="replace")
    print(f"  unified tables: {ud.relative_to(ROOT)}/ (CSV + food_database.xlsx)")
    (OUT / "build_meta.json").write_text(json.dumps(dict(meta, n_foods=len(foods), n_values=len(values),
                                                         skipped_matches=skipped), indent=2))
    print(f"  qa flags: {flags['severity'].value_counts().to_dict()}")
    print(f"  borrowed values: {(values['value_type'] == 'borrowed').sum()}  (matches below threshold/unused: {skipped})")
    print(f"  wrote {db.relative_to(ROOT)} and CSVs in out/")


def cmd_translate_tasks(args):
    """Foods whose names are not English -> JSONL for a batch translation job (see prompts/translate_foods.md)."""
    import sqlite3
    with sqlite3.connect(OUT / "foodpipe.sqlite") as con:
        f = pd.read_sql("select food_uid, name_original, lang, group_original from foods "
                        "where lang != 'en' and (name_en is null or trim(name_en) = '')", con)
    path = OUT / "translate_tasks.jsonl"
    with path.open("w") as fh:
        for r in f.itertuples():
            fh.write(json.dumps(dict(custom_id=r.food_uid, name=r.name_original, lang=r.lang, group=r.group_original),
                                ensure_ascii=False) + "\n")
    print(f"wrote {len(f)} tasks to {path.relative_to(ROOT)}")


def main():
    ap = argparse.ArgumentParser(prog="foodpipe")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status").set_defaults(fn=cmd_status)
    b = sub.add_parser("build")
    b.add_argument("--dev", action="store_true")
    b.set_defaults(fn=cmd_build)
    sub.add_parser("translate-tasks").set_defaults(fn=cmd_translate_tasks)
    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
