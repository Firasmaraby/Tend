"""Post-model guard for exact/equivalent matches (v1.0, fix M2). It can only DOWNGRADE a match to 'similar' (never upgrade, never add),
so the model verdicts in matches/*.csv stay exactly as the models gave them and the guard is re-applied on every build.
Every downgrade is written to out/match_guard_log.csv with the rule that fired.

True CNF<-USDA derivations (method ndb_code) are not guarded: the CNF food *is* the USDA food.

Rules (numeric rules need both foods to have a reported value for the nutrient; text rules use name_en + name_original):
  sodium_3x          SODIUM differs >= 3x AND by > 150 mg, unless both names say cured / brined / pickled / salted / corned
  salt_wording       exactly one name says 'with salt' / 'salted' / 'salt added'
  sugar_2x           SUGAR differs >= 2x AND by > 5 g
  water_10g          WATER differs by > 10 g
  folic_acid         FOLAC >= 1 ug on one side and <= 0.5 ug on the other (enriched vs not)
  vitamin_d_drink    dairy / plant drinks: VITD >= 0.5 ug on one side and <= 0.15 ug on the other
  flour_type         both are flours with a 'type NNN' / 'T NNN' number and the numbers differ
  text_contradiction opposite statements about salt, milk, skin, bone, fat, sugar, ..., drained / not drained, or fortification stated on one
                     side only (the v0.3 text guard, kept)
Matches already downgraded by the v0.3 guard (method '...+guard') are listed in the log as 'v0.3_text_guard'.
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

from .common import OUT

SIMILAR_CONF = 0.6
CURED = re.compile(r"\b(cured|brine|brined|pickled|salted|salt[- ]cured|corned|salt added|with salt)\b")
SALT_SAYS = re.compile(r"(?<!un)\bsalted\b|\bwith salt\b|\bsalt added\b|\badded salt\b")
SALT_NOT = re.compile(r"\bwithout (?:added )?salt\b|\bunsalted\b|\bno salt\b|\bsalt[- ]free\b")
DRINK = re.compile(r"\b(milk|drink|beverage|soy ?milk|almond|oat|rice drink|yogurt|yoghurt|kefir)\b")
FLOUR = re.compile(r"\b(flour|farine|mehl|farinha|bran|meal)\b")
FTYPE = re.compile(r"\b(?:type|typ|t)\s*-?(\d{2,4})\b")

OBJ = "salt|milk|skin|bone|fat|sugar|cream|butter|oil|sauce|syrup|seeds?|shell|peel|juice|water|cheese|egg|meat|gravy|filling"
FORT = re.compile(r"\b(fortified|enriched|added (?:vitamin|vitamins|calcium|iron|folic|minerals?|nutrients?)|with added (?:vitamin|calcium|iron))\b")


def _facts(n: str) -> set:
    s = set()
    for m in re.finditer(r"\bwithout (?:added |any )?(%s)\b" % OBJ, n): s.add(("no", m.group(1)))
    for m in re.finditer(r"\bno (?:added )?(%s)\b" % OBJ, n): s.add(("no", m.group(1)))
    for m in re.finditer(r"(?<!out )\bwith (?:added |some )?(%s)\b" % OBJ, n): s.add(("yes", m.group(1)))
    for m in re.finditer(r"(?<!out )\bwith (?:\w+ ){0,2}(%s)\b" % OBJ, n): s.add(("yes", m.group(1)))
    if re.search(r"\bunsalted\b|\bsalt[- ]free\b|\bno salt\b", n): s.add(("no", "salt"))
    elif re.search(r"\bsalted\b", n): s.add(("yes", "salt"))
    if re.search(r"\bunsweetened\b|\bno sugar added\b|\bsugar[- ]free\b", n): s.add(("no", "sugar"))
    elif re.search(r"\bsweetened\b", n): s.add(("yes", "sugar"))
    if re.search(r"\bnot drained\b|\bundrained\b|\bwith liquid\b|\bsolids and liquid\b", n): s.add(("no", "drained"))
    elif re.search(r"\bdrained\b", n): s.add(("yes", "drained"))
    if re.search(r"\bskinless\b", n): s.add(("no", "skin"))
    if re.search(r"\bboneless\b", n): s.add(("no", "bone"))
    return s


def _text_contradiction(a: str, b: str):
    A, B = _facts(a), _facts(b)
    for k, o in A:
        opp = "no" if k == "yes" else "yes"
        if (opp, o) in B and (k, o) not in B:
            return f"{k} {o} vs {opp} {o}"
    if bool(FORT.search(a)) != bool(FORT.search(b)):
        return "fortification stated on one side only"
    return None


def _says_salt(n: str) -> bool:
    return bool(SALT_SAYS.search(n)) and not SALT_NOT.search(n)


def make_checker(foods: pd.DataFrame, values: pd.DataFrame):
    """-> reasons(target_uid, donor_uid) -> list of (rule, detail). Pure function of the two foods; used for single matches (apply) and for
    the cluster-level consistency check in dedup.clusters (a hub food like generic 'Flour, rye' must not chain 'type 130' and 'Type 815')."""
    v = values[values["value"].notna() & (values["value_type"] != "borrowed")]
    w = v.pivot_table(index="food_uid", columns="code", values="value", aggfunc="first")
    cols = {c: w[c].to_dict() for c in ("SODIUM", "SUGAR", "WATER", "FOLAC", "VITD") if c in w.columns}
    name = dict(zip(foods["food_uid"], (foods["name_en"].fillna("") + " | " + foods["name_original"].fillna("")).str.lower()))
    group = dict(zip(foods["food_uid"], foods["food_group"])) if "food_group" in foods.columns else {}

    def val(uid, code):
        x = cols.get(code, {}).get(uid, np.nan)
        return x

    def reasons(t, d):
        nt, nd = name.get(t, ""), name.get(d, "")
        why = []
        na, nb = val(t, "SODIUM"), val(d, "SODIUM")
        if pd.notna(na) and pd.notna(nb) and abs(na - nb) > 150 and max(na, nb) >= 3 * max(min(na, nb), 1e-9) and not (CURED.search(nt) and CURED.search(nd)):
            why.append(("sodium_3x", f"SODIUM {na:g} vs {nb:g} mg"))
        if _says_salt(nt) != _says_salt(nd):
            why.append(("salt_wording", "one name says with salt / salted / salt added"))
        sa, sb = val(t, "SUGAR"), val(d, "SUGAR")
        if pd.notna(sa) and pd.notna(sb) and abs(sa - sb) > 5 and max(sa, sb) >= 2 * max(min(sa, sb), 1e-9):
            why.append(("sugar_2x", f"SUGAR {sa:g} vs {sb:g} g"))
        wa, wb = val(t, "WATER"), val(d, "WATER")
        if pd.notna(wa) and pd.notna(wb) and abs(wa - wb) > 10:
            why.append(("water_10g", f"WATER {wa:g} vs {wb:g} g"))
        fa, fb = val(t, "FOLAC"), val(d, "FOLAC")
        if pd.notna(fa) and pd.notna(fb) and ((fa >= 1 and fb <= 0.5) or (fb >= 1 and fa <= 0.5)):
            why.append(("folic_acid", f"FOLAC {fa:g} vs {fb:g} ug"))
        da, db = val(t, "VITD"), val(d, "VITD")
        is_drink = group.get(t) == "dairy" or group.get(d) == "dairy" or DRINK.search(nt) or DRINK.search(nd)
        if is_drink and pd.notna(da) and pd.notna(db) and ((da >= 0.5 and db <= 0.15) or (db >= 0.5 and da <= 0.15)):
            why.append(("vitamin_d_drink", f"VITD {da:g} vs {db:g} ug"))
        if FLOUR.search(nt) and FLOUR.search(nd):
            ta, tb = FTYPE.search(nt), FTYPE.search(nd)
            if ta and tb and ta.group(1) != tb.group(1):
                why.append(("flour_type", f"type {ta.group(1)} vs {tb.group(1)}"))
        tc = _text_contradiction(nt, nd)
        if tc:
            why.append(("text_contradiction", tc))
        return why

    reasons.short = dict(zip(foods["food_uid"], foods["name_en"].fillna(foods["name_original"])))
    return reasons


def apply(matches: pd.DataFrame, foods: pd.DataFrame, values: pd.DataFrame):
    """-> (matches with downgrades applied, log DataFrame). `matches` = directed rows target_uid, donor_uid, match_type, confidence, method, notes."""
    reasons = make_checker(foods, values)
    short = reasons.short
    m = matches.copy()
    log = []
    em = m["match_type"].isin(["exact", "equivalent"])
    for i in m.index[m["method"].astype(str).str.contains("+guard", regex=False)]:   # downgraded earlier by the v0.3 text guard
        r = m.loc[i]
        log.append(dict(target_uid=r.target_uid, donor_uid=r.donor_uid, old_type="", old_conf=np.nan, old_method=r["method"],
                        rule="v0.3_text_guard", detail=str(r["notes"])[:160], target_name=short.get(r.target_uid), donor_name=short.get(r.donor_uid)))
    for i in m.index[em & (m["method"] != "ndb_code")]:
        r = m.loc[i]
        t, d = r.target_uid, r.donor_uid
        why = reasons(t, d)
        if why:
            log.append(dict(target_uid=t, donor_uid=d, old_type=r.match_type, old_conf=r.confidence, old_method=r["method"],
                            rule="; ".join(x[0] for x in why), detail="; ".join(x[1] for x in why),
                            target_name=short.get(t), donor_name=short.get(d)))
            m.loc[i, ["match_type", "confidence"]] = ["similar", SIMILAR_CONF]
            m.loc[i, "method"] = f"{r['method']}+guard"
            m.loc[i, "notes"] = f"guard {why[0][0]}: {why[0][1]}; was {r.match_type} {r.confidence} ({r['method']})"
    L = pd.DataFrame(log, columns=["target_uid", "donor_uid", "old_type", "old_conf", "old_method", "rule", "detail", "target_name", "donor_name"])
    OUT.mkdir(parents=True, exist_ok=True)
    L.to_csv(OUT / "match_guard_log.csv", index=False)
    return m, L
