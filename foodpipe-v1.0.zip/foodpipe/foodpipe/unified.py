"""Unified, app-portable export: one consistent set of tables as CSV (for apps/databases) and XLSX (for people).

Conventions (also written into the README sheet):
  * One header row, snake_case, unit in the column name (protein_g, vitamin_d_ug). Never renamed between versions.
  * Values per 100 g edible portion. Empty cell = unknown. 0 = measured zero or trace (see value_type).
  * Stable IDs: food_id = "<source_id>:<source_food_id>"; nutrient codes from config/nutrients.csv.
  * UTF-8, comma separated, dot decimals, ISO dates.
  * To change a label, unit note, daily value or group: edit config/*.csv once and rebuild. Every output follows.
"""
from __future__ import annotations

import datetime as dt
import fnmatch
import json
import re

import pandas as pd

from .common import CONFIG, OUT, load_nutrients, read_csv

GROUP_LABELS = {
    "vegetables": "Vegetables", "fruits": "Fruits", "grains_cereals": "Grains & cereals", "legumes": "Legumes",
    "nuts_seeds": "Nuts & seeds", "meat_poultry": "Meat & poultry", "fish_seafood": "Fish & seafood", "eggs": "Eggs",
    "dairy": "Dairy", "fats_oils": "Fats & oils", "sweets_sugars": "Sweets & sugars", "beverages": "Beverages",
    "mixed_dishes": "Mixed dishes", "soups_sauces": "Soups & sauces", "herbs_spices_condiments": "Herbs, spices & condiments",
    "snacks": "Snacks", "baby_foods": "Baby foods", "other": "Other",
}


def assign_groups(foods: pd.DataFrame) -> pd.Series:
    rules = read_csv(CONFIG / "food_groups.csv").fillna("")
    out = []
    for f in foods.itertuples():
        g = "other"
        for r in rules.itertuples():
            if fnmatch.fnmatch(f.source_id, r.source_pattern) and r.group_original == (f.group_original or "") \
                    and (not r.name_regex or re.search(r.name_regex, f.name_original or "")):
                g = r.food_group
                break
        out.append(g)
    return pd.Series(out, index=foods.index)


def build(foods, values, flags, sources_used: dict, meta: dict, canon=None):
    nut = load_nutrients()
    code2col = nut.set_index("code")["column"]
    dev = any(v["dev_mirror"] for v in meta["inputs"].values())
    version = "1.0" + ("-dev" if dev else "")
    unk = sorted(set(foods["group_original"].dropna()) - set(read_csv(CONFIG / "food_groups.csv")["group_original"]))
    if unk:
        print(f"  note: food groups without a mapping in config/food_groups.csv -> 'other': {unk}")

    cite_short = {k: s["citation_short"] for k, s in sources_used.items()}
    lic = {k: s["licence"] for k, s in sources_used.items()}

    f = foods.rename(columns={"food_uid": "food_id", "native_id": "source_food_id", "lang": "language"}).copy()
    f["food_group"] = assign_groups(foods)
    f["food_group_original"] = f["group_original"]
    if "basis" not in f.columns:
        f["basis"] = "per 100 g edible portion"
    f["source_citation"] = f["source_id"].map(cite_short)
    f["licence"] = f["source_id"].map(lic)
    f["citation_required"] = True
    dd_cols = [c for c in ("status", "superseded_by", "canonical_id", "is_preferred") if c in f.columns]
    foods_t = f[["food_id", "name_en", "name_original", "language", "food_group", "food_group_original", "state",
                 "country", "source_id", "source_citation", "licence", "citation_required", "source_food_id", "basis"] + dd_cols]

    v = values.copy()
    long_t = pd.DataFrame({
        "food_id": v["food_uid"], "nutrient_code": v["code"], "nutrient": v["code"].map(code2col),
        "value": v["value"].round(6), "unit": v["unit"], "value_type": v["value_type"], "data_source": v["data_source"],
        "source_citation": v["data_source"].map(cite_short), "licence": v["data_source"].map(lic), "citation_required": True,
        "donor_food_id": v["donor_food_uid"], "original_value": v["original_value"], "derivation": v["derivation"], "note": v["note"],
    }).sort_values(["food_id", "nutrient_code", "value_type"])
    if long_t.duplicated(["food_id", "nutrient_code", "value_type"]).any():
        raise ValueError("food_nutrients key (food_id, nutrient_code, value_type) is not unique")
    if long_t["source_citation"].isna().any():
        raise ValueError("values without a source citation - refusing to export")

    known = v[v["value"].notna()]
    w = known.pivot_table(index="food_uid", columns="code", values="value", aggfunc="first")
    order = [c for c in nut["code"] if c in w.columns]
    w = w[order].rename(columns=code2col).round(4)
    borrowed = known[known["value_type"] == "borrowed"]
    filled = borrowed.assign(col=lambda d: d["code"].map(code2col)).groupby("food_uid")["col"] \
        .apply(lambda s: " ".join(sorted(s)))
    filled_from = borrowed.groupby("food_uid")["data_source"].apply(lambda s: "; ".join(sorted({cite_short[x] for x in s})))
    est = known[known["derivation"].fillna("").str.startswith("estimated")].assign(col=lambda d: d["code"].map(code2col)) \
        .groupby("food_uid")["col"].apply(lambda s: " ".join(sorted(s)))
    wide_t = foods_t.set_index("food_id")[["name_en", "name_original", "food_group", "state", "country", "source_id",
                                           "source_citation", "licence", "citation_required", "basis"] + dd_cols] \
        .join(w).join(filled.rename("filled_nutrients")).join(filled_from.rename("filled_from_sources_cite_also")) \
        .join(est.rename("estimated_nutrients")).reset_index()

    nutrients_t = nut.rename(columns={"code": "nutrient_code", "column": "nutrient", "name": "label", "dv": "daily_value",
                                      "density": "in_density_score"})
    nutrients_t.insert(0, "display_order", range(1, len(nutrients_t) + 1))
    used_vals = long_t[long_t["value"].notna()]
    citations_t = pd.DataFrame([dict(
        source_id=k, citation_short=s["citation_short"], citation=s["citation"],
        required_notice_verbatim=s["licence_notice"], licence=s["licence"], licence_url=s.get("licence_url"),
        changes_made=s["changes_notice"], publisher=s.get("publisher"), country=s.get("country"),
        foods_from_this_source=int((foods_t["source_id"] == k).sum()),
        values_from_this_source=int((used_vals["data_source"] == k).sum()),
        built_from=("development mirror - replace before production" if meta["inputs"][k]["dev_mirror"] else
                    "; ".join(x for x in [s.get("provenance") or "official download", s.get("data_version")] if x)),
    ) for k, s in sources_used.items()])
    groups_t = pd.DataFrame([dict(food_group=k, label=l) for k, l in GROUP_LABELS.items()])
    flags_t = flags.rename(columns={"food_uid": "food_id", "code": "nutrient_code"})

    tables = {"CITATIONS_REQUIRED": citations_t, "foods_wide": wide_t, "foods": foods_t, "nutrients": nutrients_t,
              "food_nutrients": long_t, "food_groups": groups_t, "qa_flags": flags_t}
    if canon is not None:
        tables["canonical_foods"], tables["canonical_members"] = canon

    d = OUT / "unified"
    d.mkdir(parents=True, exist_ok=True)
    for old in d.glob("*.csv"):
        old.unlink()
    for name, t in tables.items():
        t.to_csv(d / f"{name}.csv", index=False, encoding="utf-8")
    citations = [dict(source_id=r.source_id, citation=r.citation, required_notice=r.required_notice_verbatim,
                      licence=r.licence, licence_url=r.licence_url, changes_made=r.changes_made)
                 for r in citations_t.itertuples()]
    metadata = dict(dataset="foodpipe unified food composition table", version=version, built=dt.date.today().isoformat(),
                    attribution_required=True, usage_notice=NOTICE, citations=citations,
                    basis="per 100 g edible portion", n_foods=len(foods_t), n_values=int(used_vals.shape[0]),
                    sources=list(sources_used), development_build=dev,
                    tables={k: list(t.columns) for k, t in tables.items()})
    (d / "metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False))
    _notice_files(d, citations, metadata, tables)
    _xlsx(d / "food_database.xlsx", tables, metadata)
    return d


NOTICE = ("ATTRIBUTION REQUIRED. This dataset combines data from the sources listed in CITATIONS_REQUIRED. Their licences "
          "allow reuse, including commercial use, ONLY if the source is cited. Anyone who uses this data, or any part of "
          "it, must display the citation and required notice of every source whose data is used: a person, an app, a "
          "website, a document, or an AI system producing content from it. Show them, for example, on an About, Credits "
          "or Sources screen, or next to the information. Keep this notice and the source_citation columns with any copy, "
          "subset or export of the data. Do not remove them. Do not imply that any source organisation endorses the "
          "product. Rows list their own source in source_citation; values filled from another source list it in "
          "filled_from_sources_cite_also.")


def _notice_files(d, citations, metadata, tables):
    lines = [NOTICE, "", "CITATIONS (cite every source whose data you use):", ""]
    for c in citations:
        lines += [f"- {c['citation']}", f"  Required notice: {c['required_notice']}", f"  Licence: {c['licence']}"
                  + (f" ({c['licence_url']})" if c.get("licence_url") else ""), f"  Changes made: {c['changes_made']}", ""]
    (d / "NOTICE.txt").write_text("\n".join(lines), encoding="utf-8")
    (d / "CITATIONS.md").write_text("# Citations required\n\n" + "\n".join(lines), encoding="utf-8")
    # Frictionless Data Package descriptor: the standard machine-readable place for licences and sources
    pkg = dict(
        name="foodpipe-unified-food-composition", title="Unified food composition table (foodpipe)",
        version=metadata["version"], created=metadata["built"], description=NOTICE,
        licenses=[dict(title=c["licence"], path=c.get("licence_url") or "") for c in citations],
        sources=[dict(title=c["citation"], path="", notice=c["required_notice"]) for c in citations],
        resources=[dict(name=k.lower(), path=f"{k}.csv", format="csv", mediatype="text/csv", encoding="utf-8",
                        **({"schema": {"primaryKey": ["food_id", "nutrient_code", "value_type"]}} if k == "food_nutrients" else
                           {"schema": {"primaryKey": "food_id"}} if k in ("foods", "foods_wide") else {}))
                   for k in tables],
    )
    (d / "datapackage.json").write_text(json.dumps(pkg, indent=2, ensure_ascii=False), encoding="utf-8")


README_ROWS = [
    ("ATTRIBUTION REQUIRED", "See the CITATIONS_REQUIRED sheet. " + NOTICE),
    ("What this is", "One food composition table built from openly licensed national databases. Values are per 100 g edible portion."),
    ("Main sheet", "foods_wide: one row per food, one column per nutrient. Use this in apps and spreadsheets."),
    ("Key of food_nutrients", "The key is (food_id, nutrient_code, value_type), not (food_id, nutrient_code): a food can have a source marker (present_not_quantified, pending) and a borrowed value for the same nutrient. Apps that want one number per nutrient take the row with a value (value_type reported, trace, derived or borrowed) and prefer the food's own over borrowed."),
    ("Estimated values", "estimated_nutrients (foods_wide) lists nutrients whose value the source printed in parentheses, i.e. estimated by the compilers (MEXT Japan). food_nutrients.derivation says 'estimated (value in parentheses in the source)' for each. A value of (0) is an estimated zero, not a measured one."),
    ("Column names", "snake_case with the unit at the end (protein_g, vitamin_d_ug). They never change between versions, so apps keep working."),
    ("Empty vs 0", "Empty = unknown (not measured). 0 = measured as zero or as a trace. Never treat empty as 0."),
    ("Present, not quantified", "CoFID 'N': the nutrient is present in significant amounts but the source gives no reliable figure. The wide table cell is empty and food_nutrients has value_type = present_not_quantified. It is not a zero."),
    ("Basis", "Almost every food is per 100 g edible portion. Foods published per 100 mL (CoFID alcoholic beverages) carry basis = 'per 100 mL' and values are NOT converted to per 100 g; a food whose source left the basis blank (Swiss 1539) is marked 'assumed'. Both are left out of the nutrient-density ranking and are neither donors nor targets for borrowing."),
    ("Below detection limit", "Where a source printed only an upper limit (e.g. Ciqual \"< 0.5\"), the wide table cell is empty and food_nutrients has value_type = below_lod with the source's text, including the limit, in original_value. It is not a zero and not the limit as a number."),
    ("One entry per food", "Filter foods_wide on is_preferred = TRUE to get one entry per food (the preferred record of each canonical_id cluster; region priority is set in config/dedup_rules.yaml). Do not filter on it if you want every country's own values. status = superseded marks an older duplicate record inside one source; it points to the active record in superseded_by and keeps its history in food_nutrients. canonical_foods and canonical_members list the clusters: members are the same food in different sources (exact/equivalent matches only); values are never averaged."),
    ("IDs", "food_id = source_id:source_food_id. It's stable across rebuilds, so use it as the key in your app."),
    ("filled_nutrients", "Nutrients borrowed from a matched food in another source. Full detail (donor food, source) is in food_nutrients."),
    ("food_group", "Standard group shared by all sources (see food_groups). food_group_original keeps the source's own group."),
    ("Changing things", "Edit config/nutrients.csv (labels, daily values, column names), config/food_groups.csv (group mapping) or config/sources.yaml (attribution), then rebuild. Every sheet and CSV updates together."),
    ("Carbs", "carbs_by_difference_g includes fiber (US, Canada, Brazil). carbs_available_g excludes fiber (UK, France, Australia). They are different measures; don't add them together."),
    ("Citation columns", "source_citation, licence and citation_required are on every row of foods_wide, foods and food_nutrients. filled_from_sources_cite_also lists extra sources for borrowed values. Never delete these columns: they keep the citation attached even when a single sheet or CSV is copied elsewhere."),
]


def _xlsx(path, tables, metadata):
    """Write the workbook with xlsxwriter in constant-memory mode (the long table has ~1M rows). A sheet holds at most
    1,048,575 data rows, so a longer table continues on <name>_2, <name>_3 ... (the CSV and the sqlite keep one table)."""
    import xlsxwriter

    MAXROWS = 1_048_575
    short = "ATTRIBUTION REQUIRED: cite the sources in the CITATIONS_REQUIRED sheet whenever this data is used."
    cites = " | ".join(c["citation"] for c in metadata["citations"])
    red_cols = {"source_citation", "citation_required", "filled_from_sources_cite_also", "citation", "required_notice_verbatim"}
    wb = xlsxwriter.Workbook(str(path), {"constant_memory": True, "nan_inf_to_errors": True, "strings_to_numbers": False})
    wb.set_properties(dict(title="Unified food composition table - ATTRIBUTION REQUIRED", subject=short,
                           keywords="attribution required; citation required; food composition; " +
                                    "; ".join(c["source_id"] for c in metadata["citations"]),
                           comments=(NOTICE + " CITATIONS: " + cites)[:32000], author="foodpipe"))
    head = wb.add_format({"bold": True, "font_color": "#FFFFFF", "bg_color": "#1F3A5F"})
    head_red = wb.add_format({"bold": True, "font_color": "#FFFFFF", "bg_color": "#9C1C1C"})
    bold = wb.add_format({"bold": True, "valign": "top"})
    bold_red = wb.add_format({"bold": True, "font_color": "#9C1C1C", "valign": "top"})
    wrap = wb.add_format({"text_wrap": True, "valign": "top"})
    wrap_red = wb.add_format({"text_wrap": True, "valign": "top", "bold": True, "font_color": "#9C1C1C"})

    def clean(v):
        return None if (v is None or (isinstance(v, float) and v != v)) else v

    def write_table(name, t, first_sheet_note=None):
        cols = list(t.columns)
        parts = [t.iloc[k:k + MAXROWS] for k in range(0, max(len(t), 1), MAXROWS)]
        for n, part in enumerate(parts, 1):
            ws = wb.add_worksheet(name if n == 1 else f"{name}_{n}")
            ws.set_footer("&C" + short)
            for j, c in enumerate(cols):
                ws.write(0, j, c, head_red if c in red_cols else head)
                if c in red_cols:
                    try:
                        ws.write_comment(0, j, short + " Do not delete this column.", {"author": "foodpipe"})
                    except Exception:
                        pass
                sample = part[c].head(200)
                width = max([len(str(c))] + [len(str(x)) for x in sample if x == x and x is not None])
                ws.set_column(j, j, min(max(10, width + 2), 60))
            ws.freeze_panes(1, 2 if name == "foods_wide" else 0)
            if len(part):
                ws.autofilter(0, 0, len(part), len(cols) - 1)
            vals = part.astype(object).to_numpy()
            for r in range(len(part)):
                row = vals[r]
                for j in range(len(cols)):
                    v = clean(row[j])
                    if v is not None:
                        ws.write(r + 1, j, v)

    info = README_ROWS + [("Version", metadata["version"]), ("Built", metadata["built"]), ("Foods", metadata["n_foods"]),
                          ("Sources", ", ".join(metadata["sources"])),
                          ("Long table", "food_nutrients has more rows than one Excel sheet can hold, so it continues on food_nutrients_2, _3 ... The CSV and sqlite keep it as one table.")]
    if metadata["development_build"]:
        info.append(("WARNING", "Development build: some sources come from development mirrors. Rebuild from official downloads before production."))
    rd = wb.add_worksheet("README")
    rd.set_footer("&C" + short)
    rd.set_column(0, 0, 24)
    rd.set_column(1, 1, 120)
    rd.write(0, 0, "topic", head)
    rd.write(0, 1, "details", head)
    for k, (a, b) in enumerate(info, 1):
        rd.write(k, 0, a, bold_red if k == 1 else bold)
        rd.write(k, 1, b, wrap_red if k == 1 else wrap)
    for name, t in tables.items():
        write_table(name, t)
    wb.close()


