"""foodpipe - build one provenance-tracked food composition table from openly licensed national databases."""
__version__ = "0.1.0"
