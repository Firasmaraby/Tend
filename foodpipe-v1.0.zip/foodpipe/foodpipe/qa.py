"""Quality checks. Flags are reported, never auto-corrected."""
from __future__ import annotations

import numpy as np
import pandas as pd

FLAG_COLUMNS = ["food_uid", "code", "check", "severity", "detail"]


def wide(values: pd.DataFrame, include_borrowed=True) -> pd.DataFrame:
    v = values[values["value"].notna()]
    if not include_borrowed:
        v = v[v["value_type"] != "borrowed"]
    return v.pivot_table(index="food_uid", columns="code", values="value", aggfunc="first")


def _col(w, c):
    return w[c] if c in w.columns else pd.Series(np.nan, index=w.index)


def run(foods: pd.DataFrame, values: pd.DataFrame) -> pd.DataFrame:
    flags = []
    w = wide(values, include_borrowed=False)
    P, F, W, A = (_col(w, c) for c in ["PROCNT", "FAT", "WATER", "ASH"])
    CDF, CAV, FIB, ALC = (_col(w, c) for c in ["CHOCDF", "CHOAVL", "FIBTG", "ALC"])
    CAM = _col(w, "CHOAVLM")  # UK convention: monosaccharide equivalents (3.75 kcal/g, may exceed the mass of the carbohydrate by up to ~10%)
    kcal = _col(w, "ENERC_KCAL")

    # 1. energy reconciliation (general Atwater) - big gaps usually mean a unit or entry error
    carb_av = CAV.where(CAV.notna(), CDF - FIB.fillna(0))
    carb_kcal = 4 * carb_av.clip(lower=0)
    carb_kcal = carb_kcal.where(carb_av.notna(), 3.75 * CAM.clip(lower=0))
    carb_av = carb_av.where(carb_av.notna(), CAM)
    calc = 4 * P + 9 * F + carb_kcal + 2 * FIB.fillna(0) + 7 * ALC.fillna(0)
    ok = kcal.notna() & P.notna() & F.notna() & carb_av.notna()
    diff = (kcal - calc).abs()
    bad = ok & (diff > np.maximum(25, 0.20 * kcal))
    for uid in w.index[bad]:
        flags.append((uid, "ENERC_KCAL", "energy_mismatch", "warning",
                      f"reported {kcal[uid]:.0f} kcal vs {calc[uid]:.0f} from macros (Atwater general)"))

    # 2. proximate closure
    tot = W.fillna(0) + P.fillna(0) + F.fillna(0) + A.fillna(0) + CDF.where(CDF.notna(), CAV.fillna(CAM).fillna(0) + FIB.fillna(0)).fillna(0)
    slack = 105 + 0.1 * CAM.where(CAV.isna() & CDF.isna()).fillna(0)  # monosaccharide equivalents overstate carbohydrate mass by up to ~10%
    for uid in w.index[(W.notna() & P.notna() & F.notna()) & (tot > slack)]:
        flags.append((uid, None, "proximate_over_100g", "warning", f"water+protein+fat+ash+carb = {tot[uid]:.1f} g/100 g"))

    # 3. impossible values
    v = values[values["value"].notna()]
    for r in v[v["value"] < 0].itertuples():
        if r.code == "CHOCDF" and r.value > -1:  # by-difference rounding artifact in lean meat/fish
            flags.append((r.food_uid, r.code, "negative_carb_by_difference", "info",
                          f"{r.value:.3f} g: method artifact (100 - water - protein - fat - ash); treat as 0 in calculations"))
        else:
            flags.append((r.food_uid, r.code, "negative_value", "error", f"{r.value}"))
    for r in v[(v["unit"] == "g") & (v["value"] > 100)].itertuples():
        # CoFID expresses carbohydrate and sugars as monosaccharide equivalents (sucrose x 1.0526), which legitimately
        # exceeds 100 g/100 g in pure sugars (max 105.3 for sucrose, 111.1 for starch): info, not an error
        if r.data_source == "cofid" and r.code in ("CHOAVLM", "SUGAR", "STARCH") and r.value <= 112:
            flags.append((r.food_uid, r.code, "over_100g_monosaccharide_equivalents", "info",
                          f"{r.value} g/100 g: CoFID monosaccharide-equivalent convention"))
        else:
            flags.append((r.food_uid, r.code, "over_100g", "error", f"{r.value} g/100 g"))

    # 4. sub-components larger than their total
    fa_sum = _col(w, "FASAT").fillna(0) + _col(w, "FAMS").fillna(0) + _col(w, "FAPU").fillna(0)
    for uid in w.index[F.notna() & (fa_sum > F * 1.05 + 0.5)]:
        flags.append((uid, "FAT", "fatty_acids_exceed_fat", "warning", f"SFA+MUFA+PUFA {fa_sum[uid]:.2f} > fat {F[uid]:.2f}"))
    for uid in w.index[FIB.notna() & CDF.notna() & (FIB > CDF + 0.5)]:
        flags.append((uid, "FIBTG", "fiber_exceeds_carb", "warning", f"fiber {FIB[uid]} > carb {CDF[uid]}"))
    sug = _col(w, "SUGAR")
    carb_tot = CDF.where(CDF.notna(), CAV.where(CAV.notna(), CAM))
    for uid in w.index[sug.notna() & carb_tot.notna() & (sug > carb_tot + 0.5)]:
        flags.append((uid, "SUGAR", "sugar_exceeds_carb", "warning", f"sugars {sug[uid]} > carb {carb_tot[uid]}"))

    # 5. statistical outliers within source x food group (robust z on log scale)
    grp = foods.set_index("food_uid")[["source_id", "group_original"]]
    lv = v[v["value_type"] == "reported"].join(grp, on="food_uid")
    lv = lv[lv["value"] > 0].assign(lx=lambda d: np.log10(d["value"]))
    for (src, g, code), d in lv.groupby(["source_id", "group_original", "code"]):
        if len(d) < 8:
            continue
        med = d["lx"].median()
        mad = (d["lx"] - med).abs().median() * 1.4826
        if mad <= 0:
            continue
        z = (d["lx"] - med) / mad
        for r in d[z.abs() > 5].itertuples():
            flags.append((r.food_uid, code, "group_outlier", "info",
                          f"{r.value:g} vs group median {10 ** med:.3g} (robust z {((r.lx - med) / mad):.1f})"))

    # 6. same food listed twice in one source (FDC keeps older and newer records side by side)
    norm = foods.assign(n=foods["name_original"].str.lower().str.replace(r"\s*\(includes.*\)", "", regex=True).str.strip())
    for (src, n), d in norm.groupby(["source_id", "n"]):
        if len(d) > 1:
            ids = ", ".join(d["food_uid"])
            for uid in d["food_uid"]:
                flags.append((uid, None, "duplicate_name_in_source", "info", f"same name in {src}: {ids}"))

    # 7. source cells that needed repair
    for r in values[values["note"].fillna("").str.contains("malformed|unparseable")].itertuples():
        flags.append((r.food_uid, r.code, "malformed_source_cell", "info", r.note))

    return pd.DataFrame(flags, columns=FLAG_COLUMNS)
