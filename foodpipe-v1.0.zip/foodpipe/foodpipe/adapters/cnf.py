"""Canadian Nutrient File (Health Canada, 2026 edition) adapter - reads the official CSV release untouched.

Files used: Food_Name.csv, Nutrient_Amount.csv, Nutrient_Name.csv, Nutrient_Source.csv, CNF_Food_Group.csv.
(Measure_* files are portion weights, not composition; the PDF guides are not read and are never redistributed.)

Rules specific to CNF (Health Canada copyright guidelines 2026: "You may not modify the nutrient value"):
  * every factor in config/source_maps/cnf.csv must be exactly 1 - the adapter refuses to run otherwise;
  * a nutrient that would need a unit conversion is not mapped (it is listed in the build report instead);
  * Nutrient_Amount is kept as text in original_value.

Withheld values: Health Canada took a few values from databases whose licence is excluded or pending in
config/sources.yaml (Nutrient_Source codes 81 international, 82 Danish Frida, 83 Finnish Fineli). They are NOT loaded;
they are written to out/withheld_values.csv so the decision can be reversed. The list of codes is in sources.yaml
(cnf.withhold_nutrient_sources).
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

from ..common import FOOD_COLUMNS, OUT, VALUE_COLUMNS, guess_state, load_map, load_sources


def _read(folder: Path, name: str) -> pd.DataFrame:
    return pd.read_csv(folder / name, encoding="utf-8-sig", dtype=str, keep_default_na=False)


def load(source_id: str, folder: Path):
    cmap = load_map("cnf")
    if not (cmap["factor"] == 1.0).all():
        bad = cmap[cmap["factor"] != 1.0]
        raise ValueError(f"CNF source map may only use factor 1 (Health Canada: values must not be modified):\n{bad}")
    withhold = {str(x) for x in load_sources()[source_id].get("withhold_nutrient_sources", [])}

    names = _read(folder, "Food_Name.csv")
    amounts = _read(folder, "Nutrient_Amount.csv")
    nnames = _read(folder, "Nutrient_Name.csv").set_index("Nutrient_Code")
    nsrc = _read(folder, "Nutrient_Source.csv").set_index("Nutrient_Source_Code")["Nutrient_Source_Description_EN"]
    groups = _read(folder, "CNF_Food_Group.csv").set_index("CNF_Food_Group_Code")["CNF_Food_Group_Description_EN"]

    foods = pd.DataFrame({
        "food_uid": source_id + ":" + names["Food_Code"],
        "source_id": source_id,
        "native_id": names["Food_Code"],
        "name_original": names["Food_Description_EN"],
        "lang": "en",
        "name_en": names["Food_Description_EN"],
        "group_original": names["CNF_Food_Group_Code"].map(groups),
        "state": names["Food_Description_EN"].map(guess_state),
        "country": "CA",
    })[FOOD_COLUMNS]

    a = amounts.merge(cmap, left_on="Nutrient_Code", right_on="source_key", how="inner")
    held = a[a["Nutrient_Source_Code"].isin(withhold)]
    if len(held):
        h = held.assign(food_uid=source_id + ":" + held["Food_Code"],
                        nutrient_source=held["Nutrient_Source_Code"].map(nsrc),
                        food_name=held["Food_Code"].map(names.set_index("Food_Code")["Food_Description_EN"]))
        OUT.mkdir(parents=True, exist_ok=True)
        h[["food_uid", "food_name", "Nutrient_Code", "source_label", "Nutrient_Amount", "Nutrient_Source_Code",
           "nutrient_source"]].to_csv(OUT / "withheld_values.csv", index=False)
    a = a[~a["Nutrient_Source_Code"].isin(withhold)]
    a = a.sort_values("priority").drop_duplicates(["Food_Code", "code"], keep="first")

    def _note(r):
        parts = [r.note] if isinstance(r.note, str) and r.note else []
        if r.Observations not in ("", "0.0", "0"):
            parts.append(f"n={r.Observations}" + (f", SE={r.STD_Error}" if r.STD_Error != "" else ""))
        return "; ".join(parts) or None

    values = pd.DataFrame({
        "food_uid": source_id + ":" + a["Food_Code"],
        "code": a["code"],
        "value": a["Nutrient_Amount"].astype(float) * a["factor"],
        "unit": a["source_unit"],
        "value_type": "reported",
        "data_source": source_id,
        "donor_food_uid": None,
        "original_label": a["source_label"] + " [" + a["Nutrient_Code"] + "]",
        "original_value": a["Nutrient_Amount"],
        "original_unit": a["source_unit"],
        "derivation": "NS" + a["Nutrient_Source_Code"] + ": " + a["Nutrient_Source_Code"].map(nsrc).fillna(""),
        "note": [_note(r) for r in a.itertuples()],
    })
    return foods, values[VALUE_COLUMNS]
