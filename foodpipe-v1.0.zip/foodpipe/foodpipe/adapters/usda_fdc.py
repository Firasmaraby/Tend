"""USDA FoodData Central adapter (Foundation, SR Legacy, FNDDS).

Accepts either the official CSV release folder (food.csv, food_nutrient.csv, nutrient.csv, food_category.csv)
or the parquet dev mirror (hadley/foodbank) with the same table names.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

from ..common import FOOD_COLUMNS, VALUE_COLUMNS, guess_state, load_map

DATA_TYPES = {  # FDC food.data_type per source id
    "usda_fdc_foundation": {"foundation_food"},
    "usda_fdc_sr_legacy": {"sr_legacy_food"},
    "usda_fdc_fndds": {"survey_fndds_food"},
}


def _read(folder: Path, table: str) -> pd.DataFrame:
    for p in [folder / f"{table}.csv", folder / f"{table}.parquet"]:
        if p.exists():
            return pd.read_csv(p, low_memory=False) if p.suffix == ".csv" else pd.read_parquet(p)
    hits = list(folder.rglob(f"{table}.csv"))  # official zips unpack into a dated sub-folder
    if hits:
        return pd.read_csv(hits[0], low_memory=False)
    raise FileNotFoundError(f"{table}.csv not found under {folder}")


def load(source_id: str, folder: Path):
    food = _read(folder, "food")
    fn = _read(folder, "food_nutrient")
    cat = _read(folder, "food_category")
    if "data_type" in food.columns:  # official CSV: keep only this dataset's foods
        food = food[food["data_type"].isin(DATA_TYPES[source_id])]
    fn = fn[fn["fdc_id"].isin(food["fdc_id"])]

    cmap = load_map("usda_fdc")
    cmap["source_key"] = cmap["source_key"].astype(int)
    fn = fn.merge(cmap, left_on="nutrient_id", right_on="source_key", how="inner")
    fn = fn[fn["amount"].notna()]
    # several USDA nutrients can feed one canonical code (e.g. 3 energy variants): keep the best priority
    fn = fn.sort_values("priority").drop_duplicates(["fdc_id", "code"], keep="first")

    # derivation: use the USDA derivation code (A = analytical, NC = calculated, Z = assumed zero ...) when the
    # lookup table is in the release, otherwise the raw id
    derivation = pd.Series(None, index=fn.index, dtype="object")
    if "derivation_id" in fn.columns:
        derivation = fn["derivation_id"].astype("Int64").astype(str).replace("<NA>", None)
        try:
            dtab = _read(folder, "food_nutrient_derivation")
            derivation = fn["derivation_id"].map(dtab.set_index("id")["code"])
        except FileNotFoundError:
            pass
    elif "derivation" in fn.columns:
        derivation = fn["derivation"].astype(str)
    canon_unit = {"G": "g", "MG": "mg", "UG": "ug", "KCAL": "kcal", "kJ": "kJ", "IU": "ug"}
    values = pd.DataFrame({
        "food_uid": source_id + ":" + fn["fdc_id"].astype(str),
        "code": fn["code"],
        "value": fn["amount"].astype(float) * fn["factor"],
        "unit": fn["source_unit"].map(canon_unit),
        "value_type": "reported",
        "data_source": source_id,
        "donor_food_uid": None,
        "original_label": fn["source_label"] + " [" + fn["nutrient_id"].astype(str) + "]",
        "original_value": fn["amount"].astype(str),
        "original_unit": fn["source_unit"],
        "derivation": derivation,
        "note": fn["note"].replace("", None),
    })[VALUE_COLUMNS]

    cat_name = cat.set_index("id")["description"]
    foods = pd.DataFrame({
        "food_uid": source_id + ":" + food["fdc_id"].astype(str),
        "source_id": source_id,
        "native_id": food["fdc_id"].astype(str),
        "name_original": food["description"],
        "lang": "en",
        "name_en": food["description"],
        "group_original": food["food_category_id"].map(cat_name),
        "state": food["description"].map(guess_state),
        "country": "US",
    })[FOOD_COLUMNS]
    return foods, values
