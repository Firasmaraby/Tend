"""Australian Food Composition Database (FSANZ), Release 3 - reads the six official xlsx files untouched.

Layout (verified): 'AFCD Release 3 - Nutrient profiles.xlsx', sheet 'All solids & liquids per 100 g': row 1 title, row 3 header,
data from row 4. Columns A-D = Public Food Key, Classification, Derivation, Food Name; every later column is
'<nutrient name> (<unit>)' (text normalised: line breaks and double spaces collapsed). Cells are plain numbers or empty:
AFCD has no trace / below-limit markers in this file, so every number is `reported` (a 0 is a reported 0) and an empty
cell gives no row.

The second sheet ('Liquids only per 100 mL') repeats 213 foods that are also on the per-100 g sheet, so it is NOT read:
every food is loaded on one basis (per 100 g). Unit factors: all 1 except three mg -> g columns (x 0.001), asserted below.

Group: Classification is a 5-digit code; its first three digits are the sub-group listed in 'Food group information'
(config/afcd_groups.csv). `derivation` on each value = the FOOD's AFCD derivation (Analysed / Borrowed / Recipe / Imputed /
Estimated / Label Data); Borrowed and Recipe foods are not independent measurements and the build report says so.
Not carried: Food Description, Sampling Details, Specific Gravity, Nitrogen and Fat factors, Recipes, Reference List (the
food-details file is only cross-checked for names).
"""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import openpyxl
import pandas as pd

from ..common import CONFIG, FOOD_COLUMNS, VALUE_COLUMNS, guess_state, load_map, load_nutrients, read_csv

PROFILES = "AFCD_Release_3_-_Nutrient_profiles.xlsx"
DETAILS = "AFCD_Release_3_-_Food_Details.xlsx"
SHEET = "All solids & liquids per 100 g"
UNIT = re.compile(r"\(([^()]*)\)\s*$")


def _norm(x) -> str:
    return " ".join(str(x).split())


def load(source_id: str, folder: Path):
    cmap = load_map("afcd")
    nut = load_nutrients().set_index("code")["unit"]
    for m in cmap.itertuples():  # a factor other than 1 is only allowed for mg -> g
        exp = 0.001 if (m.source_unit, nut[m.code]) == ("mg", "g") else 1.0
        if m.factor != exp:
            raise ValueError(f"AFCD map {m.source_key!r}: factor {m.factor} but {m.source_unit}->{nut[m.code]} needs {exp}")
        if m.source_unit != UNIT.search(m.source_key).group(1):
            raise ValueError(f"AFCD map {m.source_key!r}: unit differs from the header")
    wb = openpyxl.load_workbook(folder / PROFILES, read_only=True, data_only=True)
    rows = list(wb[SHEET].iter_rows(values_only=True))
    if "Nutrient profiles (per 100 g" not in str(rows[0][0]):
        raise ValueError(f"unexpected AFCD title: {rows[0][0]!r}")
    hdr = [_norm(h) if h is not None else None for h in rows[2]]
    if hdr[:4] != ["Public Food Key", "Classification", "Derivation", "Food Name"]:
        raise ValueError(f"AFCD header layout changed: {hdr[:4]}")
    col = {}
    for i, h in enumerate(hdr):
        if h in col:
            raise ValueError(f"duplicate AFCD column header {h!r}")
        col[h] = i
    for m in cmap.itertuples():
        if m.source_key not in col:
            raise ValueError(f"AFCD nutrient column {m.source_key!r} not found")

    groups = read_csv(CONFIG / "afcd_groups.csv").set_index("code")["description"]
    groups.index = groups.index.astype(str)
    data = [r for r in rows[3:] if r[0]]
    keys = [r[0] for r in data]
    if len(set(keys)) != len(keys):
        raise ValueError("duplicate Public Food Key in AFCD profiles")

    # names must agree with the food-details file (same keys)
    dwb = openpyxl.load_workbook(folder / DETAILS, read_only=True, data_only=True)
    det = {r[0]: _norm(r[3]) for r in dwb["Food details"].iter_rows(min_row=4, values_only=True) if r[0]}
    if set(det) != set(keys) or any(det[r[0]] != _norm(r[3]) for r in data):
        raise ValueError("AFCD Food details and Nutrient profiles disagree on keys or names")

    foods, out = [], []
    for r in data:
        key = str(r[0]).strip()
        uid = f"{source_id}:{key}"
        sub = str(r[1]).strip()[:3]
        if sub not in groups.index:
            raise ValueError(f"AFCD classification {r[1]!r} (food {key}): sub-group {sub} is not in config/afcd_groups.csv")
        name = _norm(r[3])
        foods.append(dict(food_uid=uid, source_id=source_id, native_id=key, name_original=name, lang="en", name_en=name,
                          group_original=f"{sub} - {groups[sub]}", state=guess_state(name), country="AU"))
        deriv = f"AFCD food derivation: {r[2]}"
        for m in cmap.itertuples():
            c = r[col[m.source_key]]
            if c is None:
                continue
            if isinstance(c, bool) or not isinstance(c, (int, float)):
                raise ValueError(f"unexpected AFCD cell {c!r} (food {key}, {m.source_key})")
            out.append(dict(food_uid=uid, code=m.code, value=float(c) * m.factor, unit=None, value_type="reported",
                            data_source=source_id, donor_food_uid=None, original_label=m.source_key,
                            original_value=str(c), original_unit=m.source_unit, derivation=deriv,
                            note=(m.note if isinstance(m.note, str) and m.note else None)))
    return pd.DataFrame(foods)[FOOD_COLUMNS], pd.DataFrame(out)[VALUE_COLUMNS]
