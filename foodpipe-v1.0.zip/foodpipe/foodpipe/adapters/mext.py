"""Standard Tables of Food Composition in Japan (MEXT, 8th revised edition, 2023 supplement) - whole-table sheet only.

Layout (verified against the real file): sheet '表全体' (the per-chapter sheets are NOT read). Row 1 has the file update date
('更新日：2026年3月27日'), rows 2-7 are merged Japanese headers, row 11 has the units (a label such as '(...... mg ......)' that
applies to the columns to its right until the next label), row 12 has the component identifiers (INFOODS-style tags such as
'ENERC_KCAL', 'PROT-'), data starts on row 13: col A = food group, B = food number (5 digits, unique), C = index number,
D = food name, E.. = components, col BJ (index 61) = remarks (Japanese free text, not carried). Columns 14 and 17 hold a '*'
marker meaning 'this carbohydrate value was used for the energy calculation' (MEXT); they are not nutrients and are ignored.
The source map is keyed by the row-12 identifier; the row-11 unit is checked against the map.

Cell notation (MEXT tables; wording confirmed in the English Chapter 1 of the 7th edition, the 8th-edition key could not be retrieved):
  12.3     measured/calculated value                             -> reported
  (12.3)   estimated value (parentheses)                         -> reported, derivation 'estimated (value in parentheses in the source)'
  0        'less than 1/10 of the minimum listed unit, or not detected' -> reported 0 (the source's own number)
  Tr       trace (1/10 up to 5/10 of the minimum unit)           -> value 0, value_type "trace"; '(Tr)' = estimated trace
  -        unmeasured                                            -> no row (unknown)
  12.3†    '† = measured by the prescribed method' (remark column) -> reported, noted
  *        in the iodine column: 'see chapter 3'                 -> value NaN, value_type "pending"
Not carried: remarks (備考), component columns with no canonical nutrient (e.g. amino-acid protein, TAG-equivalent fat,
monosaccharide-equivalent and by-difference available carbohydrate, sugar alcohols, organic acids, carotenes other than
beta-carotene, tocopherols other than alpha, chromium, molybdenum, salt equivalent). Vitamin K is carried as the separate
code VITK (column vitamin_k_total_ug): MEXT defines it as phylloquinone + menaquinone-4, which is not the canonical VITK1.
"""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import openpyxl
import pandas as pd

from ..common import FOOD_COLUMNS, VALUE_COLUMNS, load_map

SHEET = "表全体"
ID_ROW, UNIT_ROW, FIRST_DATA_ROW = 12, 11, 13
NUM = re.compile(r"^\d+(?:\.\d+)?$")
PAREN_NUM = re.compile(r"^\(\s*(\d+(?:\.\d+)?)\s*\)$")
DAGGER_NUM = re.compile(r"^(\d+(?:\.\d+)?)†$")
UNIT_RE = re.compile(r"(kcal|kJ|mg|[μµ]g|g|%)")
GROUP_EN = {"01": "Cereals", "02": "Potatoes and starches", "03": "Sugars and sweeteners", "04": "Pulses", "05": "Seeds and nuts",
            "06": "Vegetables", "07": "Fruits", "08": "Mushrooms", "09": "Algae", "10": "Fish and shellfish", "11": "Meats",
            "12": "Eggs", "13": "Milks", "14": "Fats and oils", "15": "Confectioneries", "16": "Beverages",
            "17": "Seasonings and spices", "18": "Prepared foods"}
_STATE_JA = [  # (substring, state) in priority order; Japanese names have no word boundaries
    (("揚げ", "油いため", "フライ", "天ぷら"), "fried"), (("焼き", "直火", "グリル"), "grilled"),
    (("オーブン", "ロースト", "素焼き"), "roasted_baked"), (("ゆで", "水煮", "煮", "蒸し"), "cooked_moist"),
    (("缶詰",), "canned"), (("乾", "干し"), "dried"), (("冷凍",), "frozen"), (("生",), "raw"),
]


def _state(name: str) -> str:
    for subs, st in _STATE_JA:
        if any(s in name for s in subs):
            return st
    return "unknown"


def _clean(s) -> str:
    return re.sub(r"\s+", "", str(s)) if s is not None else ""


def _find(folder: Path) -> Path:
    c = [p for p in folder.glob("*.xlsx") if not p.name.startswith("~$")]
    if len(c) != 1:
        raise FileNotFoundError(f"expected exactly one MEXT xlsx in {folder}, found {c}")
    return c[0]


def load(source_id: str, folder: Path):
    cmap = load_map("mext")
    if not (cmap["factor"] == 1.0).all():
        raise ValueError("MEXT source map: only factor 1 is expected")
    wb = openpyxl.load_workbook(_find(folder), read_only=True, data_only=True)
    rows = [list(r) + [None] * (70 - len(r)) for r in wb[SHEET].iter_rows(values_only=True)]
    if "2026年3月27日" not in _clean(rows[0][61]):
        raise ValueError(f"update date cell changed: {rows[0][61]!r} (record the new data_version in sources.yaml)")
    groups_ja = {re.match(r"\d+", n).group().zfill(2): re.sub(r"^\d+", "", n) for n in wb.sheetnames if re.match(r"\d", n)}
    ids = {_clean(c): i for i, c in enumerate(rows[ID_ROW - 1]) if c is not None}
    # forward-filled unit per column from the unit row
    unit_at, cur = {}, None
    for j, c in enumerate(rows[UNIT_ROW - 1]):
        if j >= 4 and c is not None:
            m = UNIT_RE.search(str(c))
            cur = m.group(1).replace("μ", "µ") if m else cur
        unit_at[j] = cur
    for m in cmap.itertuples():
        if m.source_key not in ids:
            raise ValueError(f"MEXT component {m.source_key!r} not found in the identifier row")
        if unit_at[ids[m.source_key]] != m.source_unit:
            raise ValueError(f"MEXT {m.source_key}: unit row says {unit_at[ids[m.source_key]]!r}, map says {m.source_unit!r}")

    foods, out = [], []
    for r in rows[FIRST_DATA_ROW - 1:]:
        if r[1] in (None, ""):
            continue
        fid, gcode, name = str(r[1]).strip(), str(r[0]).strip(), str(r[3]).strip()
        if gcode not in groups_ja:
            raise ValueError(f"MEXT food group {gcode!r} (food {fid}) has no chapter sheet")
        uid = f"{source_id}:{fid}"
        foods.append(dict(food_uid=uid, source_id=source_id, native_id=fid, name_original=name, lang="ja", name_en=None,
                          group_original=f"{gcode} {groups_ja[gcode]} ({GROUP_EN[gcode]})", state=_state(name), country="JP"))
        for m in cmap.itertuples():
            c = r[ids[m.source_key]]
            if c is None:
                continue
            s = str(c).strip()
            if s in ("", "-"):
                continue
            note, deriv = [m.note if isinstance(m.note, str) and m.note else None], None
            if isinstance(c, (int, float)) and not isinstance(c, bool):
                val, vt = float(c), "reported"
            elif NUM.match(s):
                val, vt = float(s), "reported"
            elif (pm := PAREN_NUM.match(s)):
                val, vt, deriv = float(pm.group(1)), "reported", "estimated (value in parentheses in the source)"
            elif (dm := DAGGER_NUM.match(s)):
                val, vt = float(dm.group(1)), "reported"
                note.append("source marks the value with a dagger: measured by the prescribed method (remark column)")
            elif s == "Tr":
                val, vt = 0.0, "trace"; note.append("MEXT 'Tr': trace")
            elif s == "(Tr)":
                val, vt, deriv = 0.0, "trace", "estimated (value in parentheses in the source)"; note.append("MEXT '(Tr)': estimated trace")
            elif s == "*":
                val, vt = np.nan, "pending"; note.append("MEXT '*' in this column: 'see chapter 3' (no value in the table)")
            else:
                raise ValueError(f"unexpected MEXT cell {c!r} (food {fid}, {m.source_key})")
            out.append(dict(food_uid=uid, code=m.code, value=val, unit=None, value_type=vt, data_source=source_id,
                            donor_food_uid=None, original_label=f"{m.source_label} [{m.source_key}]", original_value=s,
                            original_unit=m.source_unit, derivation=deriv, note="; ".join(x for x in note if x) or None))
    return pd.DataFrame(foods)[FOOD_COLUMNS], pd.DataFrame(out)[VALUE_COLUMNS]
