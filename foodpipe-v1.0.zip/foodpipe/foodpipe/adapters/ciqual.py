"""Anses Ciqual French food composition table 2025 - reads the official XML release untouched.

Files used (dated suffix varies): alim_*.xml (foods, French + English names, group codes), alim_grp_*.xml (group names),
compo_*.xml (one row per food x constituent), const_*.xml (constituents + INFOODS tags), sources_*.xml (reference list; the
source_code is kept in `derivation`, the reference text is not copied). The PDF documentation and the xls/xlsx copies of the
table are not read by the adapter.

Rules specific to Ciqual (Anses reuse conditions: values must not be altered, source and version stated):
  * every factor in config/source_maps/ciqual.csv must be exactly 1 - the adapter refuses to run otherwise;
    a constituent that would need a unit conversion is not mapped (listed in the build report instead);
  * the unit in the French constituent label is checked against the map, so a unit change in a later release stops the build.

Cell conventions of the 'teneur' field (Ciqual documentation 3.2):
  '-'        value not known (never zero)                  -> no row
  'traces'   detected but not quantifiable / very low      -> value 0, value_type "trace"
  '< 0,5'    result below a limit                          -> value NaN, value_type "below_lod"; the limit stays in original_value
  '12,3'     number, decimal comma                         -> reported (3 significant figures in the source)
min / max (lowest / highest source value) go into `note`; confidence class (A-D) and source_code into `derivation`.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import pandas as pd

from ..common import FOOD_COLUMNS, VALUE_COLUMNS, guess_state, load_map

NUM = re.compile(r"^\d+(?:,\d+)?$")
LOD = re.compile(r"^<\s*(\d+(?:,\d+)?)$")
UNIT_IN_LABEL = re.compile(r"\(([^()/]*?)\s*/\s*100\s*(?:g|mg)\s*\)\s*$")


def _one(folder: Path, pattern: str) -> Path:
    hits = sorted(folder.glob(pattern))
    if len(hits) != 1:
        raise FileNotFoundError(f"expected exactly one file matching {pattern} in {folder}, found {hits}")
    return hits[0]


def _records(path: Path, tag: str):
    for _, e in ET.iterparse(path):
        if e.tag == tag:
            yield {c.tag: (c.text or "").strip() for c in e}
            e.clear()


def group_label(grp: str, ssgrp: str, sssgrp: str, names: dict) -> str:
    """Readable, unique group string used as group_original and in config/food_groups.csv."""
    if grp == "00":
        return "00 (no group - average/placeholder food)"
    code = sssgrp if sssgrp != "000000" else ssgrp
    parts = [names["grp"][grp], names["ss"].get(ssgrp, "-")]
    if sssgrp != "000000":
        parts.append(names["sss"][sssgrp])
    return f"{code} " + " > ".join(parts)


def _state(en: str | None, fr: str) -> str:
    st = guess_state(en) if en else "unknown"
    return st if st != "unknown" else guess_state(fr)


def load_groups(folder: Path) -> dict:
    names = {"grp": {}, "ss": {}, "sss": {}}
    for r in _records(_one(folder, "alim_grp_*.xml"), "ALIM_GRP"):
        names["grp"][r["alim_grp_code"]] = r["alim_grp_nom_eng"]
        names["ss"][r["alim_ssgrp_code"]] = r["alim_ssgrp_nom_eng"]
        if r["alim_ssssgrp_code"] != "000000":
            names["sss"][r["alim_ssssgrp_code"]] = r["alim_ssssgrp_nom_eng"]
    return names


def load(source_id: str, folder: Path):
    cmap = load_map("ciqual")
    if not (cmap["factor"] == 1.0).all():
        raise ValueError(f"Ciqual source map may only use factor 1 (Anses: values must not be altered):\n{cmap[cmap['factor'] != 1.0]}")
    names = load_groups(folder)

    consts = {r["const_code"]: r for r in _records(_one(folder, "const_*.xml"), "CONST")}
    for m in cmap.itertuples():
        c = consts.get(m.source_key)
        if c is None:
            raise ValueError(f"Ciqual constituent {m.source_key} not in const xml")
        if c["const_nom_eng"] != m.source_label:
            raise ValueError(f"Ciqual constituent {m.source_key}: label {c['const_nom_eng']!r} != map {m.source_label!r}")
        u = UNIT_IN_LABEL.search(c["const_nom_fr"])
        if not u or u.group(1).strip() != m.source_unit:
            raise ValueError(f"Ciqual constituent {m.source_key}: unit in French label {c['const_nom_fr']!r} != map unit {m.source_unit!r}")

    foods = []
    for r in _records(_one(folder, "alim_[0-9]*.xml"), "ALIM"):
        en = r["alim_nom_eng"] or None
        foods.append(dict(
            food_uid=f"{source_id}:{r['alim_code']}", source_id=source_id, native_id=r["alim_code"],
            name_original=r["alim_nom_fr"], lang="fr", name_en=en,
            group_original=group_label(r["alim_grp_code"], r["alim_ssgrp_code"], r["alim_ssssgrp_code"], names),
            state=_state(en, r["alim_nom_fr"]),
            country="FR"))
    foods = pd.DataFrame(foods)[FOOD_COLUMNS]
    known = set(foods["native_id"])

    cm = cmap.set_index("source_key")
    rows = []
    for r in _records(_one(folder, "compo_*.xml"), "COMPO"):
        m = cm.loc[r["const_code"]] if r["const_code"] in cm.index else None
        if m is None:
            continue
        t = r["teneur"]
        if t == "-":
            continue
        if r["alim_code"] not in known:
            raise ValueError(f"compo row for unknown food {r['alim_code']}")
        notes = [m["note"] if isinstance(m["note"], str) and m["note"] else None]
        if t == "traces":
            val, vtype = 0.0, "trace"
            notes.append("Ciqual 'traces': detected but not quantifiable, or estimated very low but not nil")
        elif LOD.match(t):
            val, vtype = np.nan, "below_lod"
            notes.append(f"result below a limit: '{t}' ({m['source_unit']}/100 g); the limit is in original_value, no number is stored")
        elif NUM.match(t):
            val, vtype = float(t.replace(",", ".")), "reported"
        else:
            raise ValueError(f"unexpected Ciqual teneur {t!r} (food {r['alim_code']}, constituent {r['const_code']})")
        lo, hi = r.get("min", ""), r.get("max", "")
        if lo or hi:
            notes.append(f"min {lo or '-'}; max {hi or '-'}")
        deriv = None
        if r.get("code_confiance") or r.get("source_code"):
            deriv = f"confidence {r.get('code_confiance') or '-'}; source_code {r.get('source_code') or '-'}"
        rows.append(dict(food_uid=f"{source_id}:{r['alim_code']}", code=m["code"], value=val, unit=None, value_type=vtype,
                         data_source=source_id, donor_food_uid=None,
                         original_label=f"{m['source_label']} [{r['const_code']}]", original_value=t,
                         original_unit=m["source_unit"], derivation=deriv,
                         note="; ".join(x for x in notes if x) or None, _prio=int(m["priority"])))
    values = pd.DataFrame(rows)
    # fallback constituents (energy/protein variants): lowest priority number wins
    values = (values.sort_values("_prio").drop_duplicates(["food_uid", "code"], keep="first")
              .drop(columns="_prio").sort_values(["food_uid", "code"]).reset_index(drop=True))
    return foods, values[VALUE_COLUMNS]
