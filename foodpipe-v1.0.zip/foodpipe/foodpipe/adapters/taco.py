"""TACO 4th edition (NEPA-UNICAMP, 2011) adapter - reads the original XLS untouched.

Special codes in TACO cells:
  Tr  = trace (below the quantification limit)         -> value 0, value_type "trace"
  NA  = not applicable                                  -> value NaN, value_type "not_applicable"
  *   = samples under re-analysis                       -> value NaN, value_type "pending"
  ''  = not analysed                                    -> no row (genuinely unknown)
"""
from __future__ import annotations

import numbers
import re
from pathlib import Path

import numpy as np
import pandas as pd

from ..common import FOOD_COLUMNS, VALUE_COLUMNS, guess_state, load_map

MAIN_SHEET = "CMVCol taco3"
FA_SHEET = "AGtaco3"


def _parse_cell(raw):
    """Return (value, value_type, note) for one TACO cell, or None when the cell is empty."""
    if raw is None or (isinstance(raw, numbers.Real) and np.isnan(float(raw))):
        return None
    if isinstance(raw, numbers.Real):
        return float(raw), "reported", None
    s = str(raw).strip()
    if s == "":
        return None
    if s == "Tr":
        return 0.0, "trace", "TACO 'Tr': below quantification limit"
    if s == "NA":
        return np.nan, "not_applicable", "TACO 'NA': not applicable"
    if s == "*":
        return np.nan, "pending", "TACO '*': samples under re-analysis"
    fixed = re.sub(r"^[,.]+", "", s).replace(",", ".")  # e.g. ',0,02' -> '0.02'
    try:
        return float(fixed), "reported", f"malformed source cell '{s}' parsed as {fixed}"
    except ValueError:
        return np.nan, "pending", f"unparseable source cell '{s}'"


def _food_rows(sheet: pd.DataFrame):
    """Yield (row_index, food_id, name, category) for data rows; category rows set the running group."""
    category = None
    for i in range(sheet.shape[0]):
        c0 = sheet.iat[i, 0]
        c1 = sheet.iat[i, 1]
        if isinstance(c0, numbers.Real) and not np.isnan(float(c0)):
            yield i, int(c0), str(c1).strip(), category
        elif isinstance(c0, str) and c0.strip() and c0.strip() not in ("Número do", "Alimento") \
                and (c1 is None or (isinstance(c1, numbers.Real) and np.isnan(float(c1))) or str(c1).strip() == ""):
            category = c0.strip()


def load(source_id: str, folder: Path):
    xls = next(folder.glob("*.xls"))
    book = pd.read_excel(xls, sheet_name=None, header=None, keep_default_na=False, na_values=[])
    book = {k: v.replace("", np.nan) for k, v in book.items()}
    cmap = load_map("taco")

    foods, rows = [], []
    for sheet_key, sheet_name in [("main", MAIN_SHEET), ("fa", FA_SHEET)]:
        sheet = book[sheet_name]
        smap = cmap[cmap["source_key"].str.startswith(sheet_key + ":")]
        for i, fid, name, cat in _food_rows(sheet):
            uid = f"{source_id}:{fid}"
            if sheet_key == "main":
                foods.append(dict(food_uid=uid, source_id=source_id, native_id=str(fid), name_original=name,
                                  lang="pt", name_en=None, group_original=cat, state=guess_state(name), country="BR"))
            for m in smap.itertuples():
                col = int(m.source_key.split(":")[1])
                raw = sheet.iat[i, col]
                parsed = _parse_cell(raw)
                if parsed is None:
                    continue
                val, vtype, note = parsed
                notes = "; ".join(x for x in [note, m.note] if isinstance(x, str) and x)
                rows.append(dict(food_uid=uid, code=m.code, value=val * m.factor if not np.isnan(val) else np.nan,
                                 unit=None, value_type=vtype, data_source=source_id, donor_food_uid=None,
                                 original_label=f"{m.source_label} ({m.source_unit})", original_value=str(raw),
                                 original_unit=m.source_unit, derivation=None, note=notes or None))
            if sheet_key == "fa":  # trans fat = 18:1t + 18:2t when both reported (columns 23, 24)
                parts = [_parse_cell(sheet.iat[i, c]) for c in (23, 24)]
                if all(p is not None and not np.isnan(p[0]) for p in parts):
                    rows.append(dict(food_uid=uid, code="FATRN", value=parts[0][0] + parts[1][0], unit=None,
                                     value_type="derived", data_source=source_id, donor_food_uid=None,
                                     original_label="18:1t + 18:2t (g)",
                                     original_value=f"{sheet.iat[i, 23]} + {sheet.iat[i, 24]}",
                                     original_unit="g", derivation="sum of TACO trans isomers", note=None))
    values = pd.DataFrame(rows)
    foods = pd.DataFrame(foods)[FOOD_COLUMNS]
    # fatty-acid sheet only covers foods present in the main sheet
    values = values[values["food_uid"].isin(foods["food_uid"])]
    return foods, values[VALUE_COLUMNS]
