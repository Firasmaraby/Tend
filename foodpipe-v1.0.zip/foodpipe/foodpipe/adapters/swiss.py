"""Swiss Food Composition Database (FSVO/BLV), "Generic Foods" sheet only - reads the official xlsx untouched.

Layout (verified): sheet 'Generic Foods', row 1 title with version, row 3 header, data from row 4. Columns A-H:
ID, ID V 4.0, ID SwissFIR, Name, Synonyms, Category, Density, Matrix unit. From column I every nutrient takes three
columns: value, 'Derivation of value', 'Source' (numeric source id(s) from the 'Sources' sheet). The last column is
'Record has changed' (not a nutrient). The 'Branded foods' sheet is NOT read (decision: generic foods only).

Cells: number -> reported; 'tr.' -> trace (0); '<x' -> below_lod (limit stays in original_value); 'n.d.' = not determined
-> no row. All foods are 'per 100g edible portion' except one whose Matrix unit is blank; that food is loaded with a note
and a matrix_unit_missing QA warning (the basis is assumed, not stated). Any other Matrix unit stops the build.
Not carried: Synonyms, ID V 4.0 / SwissFIR ids, Density (no conversion is needed, all values are per 100 g), the
resolved text of the Sources sheet (the numeric source ids are kept in `derivation`).
"""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import openpyxl
import pandas as pd

from ..common import FOOD_COLUMNS, OUT, VALUE_COLUMNS, guess_state, load_map

SHEET = "Generic Foods"
HEADER_ROW = 3
BASIS = "per 100g edible portion"
LOD = re.compile(r"^<\s*(\d+(?:\.\d+)?)$")
NUMTXT = re.compile(r"^-?\d+(?:\.\d+)?$")
UNIT_IN_LABEL = re.compile(r"\(([^()]*)\)\s*$")
# Upstream sources inside the Swiss table whose own terms do not allow redistribution (IFCT India is `excluded` in sources.yaml:
# its copyright forbids electronic products). Values whose Source cell names one of these ids are not loaded; they are listed in
# out/removed_upstream_values.csv. Decision by Firas, 2026-10-22 (sources.yaml, swiss_fcdb.upstream_decision).
EXCLUDED_UPSTREAM = {"2290": "Indian Food Composition Tables (IFCT India), NIN 2017"}


def _find(folder: Path) -> Path:
    c = [p for p in folder.glob("*.xlsx") if not p.name.startswith("~$")]
    if len(c) != 1:
        raise FileNotFoundError(f"expected exactly one Swiss xlsx in {folder}, found {c}")
    return c[0]


def load(source_id: str, folder: Path):
    cmap = load_map("swiss")
    if not (cmap["factor"] == 1.0).all():
        raise ValueError("Swiss source map: only factor 1 is expected")
    wb = openpyxl.load_workbook(_find(folder), read_only=True, data_only=True)
    rows = [list(r) + [None] * (150 - len(r)) for r in wb[SHEET].iter_rows(values_only=True)]
    if "Generic foods" not in str(rows[0][0]):
        raise ValueError(f"unexpected title in {SHEET!r}: {rows[0][0]!r}")
    hdr = rows[HEADER_ROW - 1]
    if hdr[7] != "Matrix unit" or hdr[3] != "Name" or hdr[5] != "Category":
        raise ValueError("Swiss header layout changed")
    col = {h: i for i, h in enumerate(hdr) if h not in (None, "Derivation of value", "Source")}
    for m in cmap.itertuples():
        i = col.get(m.source_key)
        if i is None:
            raise ValueError(f"Swiss nutrient column {m.source_key!r} not found")
        if hdr[i + 1] != "Derivation of value" or hdr[i + 2] != "Source":
            raise ValueError(f"Swiss column {m.source_key!r}: the next two columns are not Derivation/Source")
        u = UNIT_IN_LABEL.search(m.source_key)
        if not u or u.group(1) != m.source_unit:
            raise ValueError(f"Swiss column {m.source_key!r}: unit differs from map ({m.source_unit!r})")

    data = [r for r in rows[HEADER_ROW:] if r[0] is not None]
    foods, out, removed = [], [], []
    for r in data:
        basis = r[7]
        if basis not in (BASIS, None):
            raise ValueError(f"Swiss food {r[0]} has Matrix unit {basis!r}; only {BASIS!r} is handled")
        uid = f"{source_id}:{r[0]}"
        foods.append(dict(food_uid=uid, source_id=source_id, native_id=str(r[0]), name_original=str(r[3]).strip(), lang="en",
                          name_en=str(r[3]).strip(), group_original=str(r[5]).strip(), state=guess_state(str(r[3])), country="CH"))
        for m in cmap.itertuples():
            i = col[m.source_key]
            c = r[i]
            if c is None:
                continue
            note = [m.note if isinstance(m.note, str) and m.note else None]
            if basis is None:
                note.append("Matrix unit blank in the source (1,215 of 1,216 foods say 'per 100g edible portion'); basis assumed, not stated")
            if isinstance(c, (int, float)) and not isinstance(c, bool):
                val, vt = float(c), "reported"
            else:
                s = str(c).strip()
                if s == "n.d.":
                    continue
                if s == "tr.":
                    val, vt = 0.0, "trace"; note.append("Swiss 'tr.': trace")
                elif LOD.match(s):
                    val, vt = np.nan, "below_lod"; note.append(f"result below a limit: '{s}' ({m.source_unit}); the limit is in original_value, no number is stored")
                elif NUMTXT.match(s):
                    val, vt = float(s), "reported"
                else:
                    raise ValueError(f"unexpected Swiss cell {c!r} (food {r[0]}, {m.source_key})")
            d, sid = r[i + 1], r[i + 2]
            hit = {t for t in re.split(r"[\s,;/]+", str(sid)) if t in EXCLUDED_UPSTREAM} if sid is not None else set()
            if hit:
                removed.append(dict(food_uid=uid, food_name=str(r[3]).strip(), code=m.code, value=str(c).strip(), swiss_source_id=str(sid),
                                    upstream="; ".join(EXCLUDED_UPSTREAM[t] for t in sorted(hit))))
                continue
            deriv = "; ".join(x for x in [d if d not in (None, "-") else None, f"source {sid}" if sid is not None else None] if x) or None
            out.append(dict(food_uid=uid, code=m.code, value=val, unit=None, value_type=vt, data_source=source_id,
                            donor_food_uid=None, original_label=m.source_key, original_value=str(c).strip(),
                            original_unit=m.source_unit, derivation=deriv, note="; ".join(x for x in note if x) or None))
    OUT.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(removed, columns=["food_uid", "food_name", "code", "value", "swiss_source_id", "upstream"]).to_csv(
        OUT / "removed_upstream_values.csv", index=False)
    values = pd.DataFrame(out)
    return pd.DataFrame(foods)[FOOD_COLUMNS], values[VALUE_COLUMNS]
