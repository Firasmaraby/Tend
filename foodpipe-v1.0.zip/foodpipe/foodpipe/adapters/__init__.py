"""Source adapters. Each adapter returns (foods, values) DataFrames in the canonical layout.

An adapter must:
  * keep every source value untouched in `original_value` (text) and its label/unit,
  * convert to the canonical unit only by an explicit factor from config/source_maps/<adapter>.csv,
  * encode the source's special codes (trace, not applicable, pending, present but not quantified) in `value_type`, never as fake numbers.
"""
from . import afcd, ciqual, cnf, cofid, mext, swiss, taco, usda_fdc

ADAPTERS = {
    "usda_fdc": usda_fdc.load,
    "taco": taco.load,
    "cnf": cnf.load,
    "cofid": cofid.load,
    "ciqual": ciqual.load,
    "swiss": swiss.load,
    "mext": mext.load,
    "afcd": afcd.load,
}
