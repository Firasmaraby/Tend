"""McCance and Widdowson's Composition of Foods Integrated Dataset 2021 (CoFID, UK) - reads the official xlsx untouched.

Layout (verified against the real file): one sheet per table group (1.2 Factors ... 1.14 Organic Acids). Every sheet has
the same foods in the same order. Columns A-G are Food Code, Food Name, Description, Group, Previous, Main data
references, Footnote. Row 1 = label with unit, row 2 = CoFID mnemonic, row 3 = long name, data from row 4.
The source map (config/source_maps/cofid.csv) is keyed "<sheet>|<mnemonic>" and the row-3 name is checked against the
map so a shifted column cannot silently load under the wrong nutrient.

Special cells (workbook notes + user guide):
  Tr        trace                                   -> value 0, value_type "trace"
  N         present in significant quantity, no reliable amount -> value NaN, value_type "present_not_quantified"
  (0.07)    number in brackets; the workbook and user guide do not define the brackets -> value 0.07, "reported", noted
  blank     not given                               -> no row
Alcoholic beverages (groups Q*) are published per 100 mL, not per 100 g. No density conversion is applied (a
specific gravity exists for only some of them); the basis is stated in the note of every value of those foods.
Food Code 13-669 is used by two different foods; both get native_id "13-669#<n>" (n = order in the file).
Not carried (no column in the unified layout): the per-food "Main data references" and "Footnote" text.
"""
from __future__ import annotations

import collections
import re
from pathlib import Path

import numpy as np
import openpyxl
import pandas as pd

from ..common import CONFIG, FOOD_COLUMNS, VALUE_COLUMNS, guess_state, load_map, read_csv

BASE_SHEET = "1.3 Proximates"
BRACKET = re.compile(r"^\(\s*(\d+(?:\.\d+)?)\s*\)$")
PLAIN = re.compile(r"^-?\d+(?:\.\d+)?$")


def _find_workbook(folder: Path) -> Path:
    cands = [p for p in folder.glob("*.xlsx") if not p.name.startswith("~$") and "old" not in p.name.lower()]
    if len(cands) != 1:
        raise FileNotFoundError(f"expected exactly one main CoFID xlsx (old-foods file excluded) in {folder}, found {cands}")
    return cands[0]


def _sheet_rows(wb, name: str):
    return [list(r) for r in wb[name].iter_rows(min_row=1, values_only=True)]


def _parse(raw):
    """(value, value_type, note) or None for an empty cell."""
    if raw is None:
        return None
    if isinstance(raw, (int, float)) and not isinstance(raw, bool):
        return float(raw), "reported", None
    s = str(raw).strip()
    if s == "":
        return None
    if s == "Tr":
        return 0.0, "trace", "CoFID 'Tr': trace"
    if s == "N":
        return np.nan, "present_not_quantified", "CoFID 'N': present in significant quantity, no reliable data on the amount"
    if PLAIN.match(s):
        return float(s), "reported", None
    m = BRACKET.match(s)
    if m:
        return float(m.group(1)), "reported", "source value is in brackets; the CoFID workbook and user guide do not define the brackets"
    raise ValueError(f"unexpected CoFID cell {raw!r}")


def load(source_id: str, folder: Path):
    wb = openpyxl.load_workbook(_find_workbook(folder), read_only=True, data_only=True)
    cmap = load_map("cofid")
    if not (cmap["factor"] == 1.0).all():
        raise ValueError("CoFID source map: only factor 1 is expected (all CoFID columns are already in the canonical units)")
    legend = read_csv(CONFIG / "cofid_groups.csv").set_index("code")["description"]
    cmap[["sheet", "mnemonic"]] = cmap["source_key"].str.split("|", n=1, expand=True)

    base = _sheet_rows(wb, BASE_SHEET)
    ident = [(r[0], r[1]) for r in base[3:]]
    codes = [str(c).strip() for c, _ in ident]
    seen = collections.Counter(codes)
    dup_index: dict[str, int] = collections.defaultdict(int)
    native = []
    for c in codes:
        if seen[c] > 1:
            dup_index[c] += 1
            native.append(f"{c}#{dup_index[c]}")
        else:
            native.append(c)
    dups = {c for c, n in seen.items() if n > 1}

    foods = []
    for r, nid in zip(base[3:], native):
        gcode = str(r[3]).strip()
        if gcode not in legend.index:
            raise ValueError(f"CoFID group code {gcode!r} (food {r[1]!r}) is not in config/cofid_groups.csv")
        foods.append(dict(food_uid=f"{source_id}:{nid}", source_id=source_id, native_id=nid, name_original=str(r[1]).strip(),
                          lang="en", name_en=str(r[1]).strip(), group_original=f"{gcode} - {legend[gcode]}",
                          state=guess_state(str(r[1])), country="GB"))
    foods = pd.DataFrame(foods)[FOOD_COLUMNS]
    per_ml = [str(r[3]).strip().startswith("Q") for r in base[3:]]

    rows = []
    for sheet, smap in cmap.groupby("sheet", sort=False):
        data = _sheet_rows(wb, sheet)
        if [str(r[1]).strip() for r in data[3:]] != [str(n).strip() for _, n in ident]:
            raise ValueError(f"CoFID sheet {sheet!r}: food names differ from {BASE_SHEET!r}")
        if [str(r[0]).strip() for r in data[3:]] != codes:
            raise ValueError(f"CoFID sheet {sheet!r}: food codes differ from {BASE_SHEET!r}")
        mnemonics = {str(c).strip(): i for i, c in enumerate(data[1]) if c is not None}
        for m in smap.itertuples():
            if m.mnemonic not in mnemonics:
                raise ValueError(f"CoFID {sheet!r}: mnemonic {m.mnemonic!r} not found in row 2")
            col = mnemonics[m.mnemonic]
            longname = str(data[2][col]).strip()
            if longname != m.source_label:
                raise ValueError(f"CoFID {sheet!r} col {col}: row-3 name {longname!r} != map label {m.source_label!r}")
            for i, r in enumerate(data[3:]):
                parsed = _parse(r[col])
                if parsed is None:
                    continue
                val, vtype, note = parsed
                extra = []
                if per_ml[i]:
                    extra.append("alcoholic beverage: CoFID gives values per 100 mL, not per 100 g; no density conversion applied")
                if codes[i] in dups:
                    extra.append(f"Food Code {codes[i]} is used twice in the source; native_id suffixed '{native[i][len(codes[i]):]}'")
                notes = "; ".join(x for x in [note, m.note] + extra if isinstance(x, str) and x)
                rows.append(dict(food_uid=f"{source_id}:{native[i]}", code=m.code, value=val, unit=None, value_type=vtype,
                                 data_source=source_id, donor_food_uid=None,
                                 original_label=f"{sheet.split(' ', 1)[0]} {m.source_label} [{m.mnemonic}]",
                                 original_value=str(r[col]), original_unit=m.source_unit, derivation=None,
                                 note=notes or None, _prio=m.priority))
    values = pd.DataFrame(rows)
    # several columns can feed one code (fibre: AOAC first, NSP only as a fallback). A real number beats an 'N'.
    values["_pend"] = values["value_type"].eq("present_not_quantified")
    values = (values.sort_values(["_pend", "_prio"]).drop_duplicates(["food_uid", "code"], keep="first")
              .drop(columns=["_pend", "_prio"]).sort_values(["food_uid", "code"]).reset_index(drop=True))
    return foods, values[VALUE_COLUMNS]
