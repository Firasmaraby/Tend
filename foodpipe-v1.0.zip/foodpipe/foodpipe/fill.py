"""Gap filling by borrowing values from a matched food in another approved source (INFOODS practice).

Nothing is generated. A missing value is filled only when:
  * a reviewed match exists in matches/*.csv with confidence >= min_confidence and an allowed match type,
  * the donor actually reports that nutrient (not borrowed itself),
  * the nutrient is not blocked by the fortification guard for either food.
Every filled value carries value_type='borrowed', the donor food and the donor's source (for attribution).
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

from .common import BASIS_STD, MATCHES, ROOT, VALUE_COLUMNS, load_fill_rules, read_csv


COLS = ["target_uid", "donor_uid", "match_type", "confidence", "method", "notes"]


def symmetrize(m: pd.DataFrame) -> pd.DataFrame:
    """exact/equivalent are symmetric: offer every pair in both directions; the highest confidence per directed pair wins."""
    r = m.rename(columns={"target_uid": "donor_uid", "donor_uid": "target_uid"})[COLS]
    m = pd.concat([m, r], ignore_index=True)
    return m.sort_values("confidence", ascending=False).drop_duplicates(["target_uid", "donor_uid"]).reset_index(drop=True)


def load_matches(symmetric: bool = True) -> pd.DataFrame:
    """matches/*.csv plus the deterministic CNF<->USDA NDB-code links (out/links/cnf_usda_derivation.csv; method ndb_code,
    same-origin: the CNF food is derived from that USDA food, so it is not an independent measurement).
    exact/equivalent are symmetric, so with symmetric=True every pair is also offered in the reverse direction
    (target and donor swapped); the highest confidence per directed pair wins."""
    frames = [read_csv(p) for p in sorted(MATCHES.glob("*.csv"))]
    link = ROOT / "out" / "links" / "cnf_usda_derivation.csv"
    if link.exists():
        L = pd.read_csv(link, dtype=str)
        # only true derivations: CNF Food_Source 0,1,3,4,6,10,11,12 (derived_from_usda). The other CNF foods that carry an NDB code
        # only point at the nearest USDA food (v1.0 fix M1); those pairs go through the normal candidate -> Haiku -> Sonnet review.
        L = L[L["usda_uid"].notna() & (L["usda_food_in_build"] == "True") & (L["derived_from_usda"].astype(str) == "True")]
        frames.append(pd.DataFrame({"target_uid": L["cnf_uid"], "donor_uid": L["usda_uid"], "match_type": "exact",
                                    "confidence": 1.0, "method": "ndb_code", "notes": "same-origin: CNF food derived from this USDA food"}))
    if not frames:
        return pd.DataFrame(columns=COLS)
    m = pd.concat(frames, ignore_index=True)[COLS]
    m["confidence"] = m["confidence"].astype(float)
    if symmetric:
        return symmetrize(m)
    return m.sort_values("confidence", ascending=False).drop_duplicates(["target_uid", "donor_uid"]).reset_index(drop=True)


def borrow(foods: pd.DataFrame, values: pd.DataFrame, matches: pd.DataFrame | None = None):
    """`matches` = the guarded match table (directed or not); when None the raw matches/*.csv are used."""
    rules = load_fill_rules()
    matches = symmetrize(matches) if matches is not None else load_matches()
    names = foods.set_index("food_uid")["name_original"]
    name_en = foods.set_index("food_uid")["name_en"].fillna("")
    ok = (foods["basis"] == BASIS_STD) if "basis" in foods.columns else pd.Series(True, index=foods.index)
    if "status" in foods.columns:
        ok &= foods["status"] == "active"   # superseded duplicates neither lend nor receive
    present = set(foods.loc[ok, "food_uid"])

    usable = matches[(matches["confidence"] >= rules["min_confidence"])
                     & matches["match_type"].isin(rules["allowed_match_types"])
                     & matches["target_uid"].isin(present) & matches["donor_uid"].isin(present)]
    skipped_matches = len(matches) - len(usable)

    have = values[values["value"].notna() | values["value_type"].isin(["not_applicable", "below_lod"])]
    have_codes = have.groupby("food_uid")["code"].apply(set).to_dict()
    donor_vals = values[values["value"].notna() & values["value_type"].isin(rules["donor_value_types"])]
    donor_idx = {(r.food_uid, r.code): r for r in donor_vals.itertuples()}
    water = values[(values["code"] == "WATER") & values["value"].notna()].set_index("food_uid")["value"].to_dict()

    guards = [(re.compile(g["pattern"]), set(g["nutrients"])) for g in rules["fortification_guard"]]
    never = set(rules["never_borrow"])
    geo = set(rules["geo_sensitive"])
    candidate_codes = sorted({c for (_, c) in donor_idx} - never)
    # v1.0 fix M3: enrichment is a property of the donor product, not of a name pattern. Across countries these nutrients are not borrowed
    # from a donor with folic acid > 0 or whose name (original OR English) says enriched / fortified / added.
    xf = rules["fortification_cross_country"]
    xf_codes, xf_rx = set(xf["nutrients"]), re.compile(xf["donor_name_pattern"])
    folac = values[(values["code"] == "FOLAC") & values["value"].notna()].groupby("food_uid")["value"].max().to_dict()
    country = foods.set_index("food_uid")["country"].to_dict()
    def fortified(uid):
        return folac.get(uid, 0) > 0 or bool(xf_rx.search(f"{names.get(uid, '')} {name_en.get(uid, '')}"))

    new, log = [], []
    for target, grp in usable.sort_values("confidence", ascending=False).groupby("target_uid", sort=False):
        missing = [c for c in candidate_codes if c not in have_codes.get(target, set())]
        blocked = set()
        for rx, nuts in guards:
            texts = [names.get(target, ""), name_en.get(target, "")] + [names.get(d, "") for d in grp["donor_uid"]] \
                + [name_en.get(d, "") for d in grp["donor_uid"]]
            if any(rx.search(t or "") for t in texts):
                blocked |= nuts
        for code in missing:
            if code in blocked:
                log.append((target, code, None, "blocked_fortification"))
                continue
            for m in grp.itertuples():  # highest confidence first
                d = donor_idx.get((m.donor_uid, code))
                if d is None:
                    continue
                if (code in xf_codes and m.method != "ndb_code" and country.get(target) != country.get(m.donor_uid)
                        and fortified(m.donor_uid)):
                    log.append((target, code, m.donor_uid, "blocked_fortified_donor"))
                    continue
                val, note = d.value, []
                wt, wd = water.get(target), water.get(m.donor_uid)
                if wt is not None and wd is not None and abs(wt - wd) > rules["moisture_adjust_threshold_g"] and wd < 100:
                    f = (100 - wt) / (100 - wd)
                    val *= f
                    note.append(f"moisture-adjusted x{f:.3f} (water {wt:.1f} vs donor {wd:.1f} g)")
                if code in geo:
                    note.append("geo-sensitive nutrient: soil/feed varies by country")
                note.append(f"match {m.match_type} conf {m.confidence:.2f} ({m.method})")
                if m.method == "ndb_code":
                    note.append("same-origin: CNF food derived from this USDA food (not an independent measurement)")
                new.append(dict(food_uid=target, code=code, value=val, unit=d.unit, value_type="borrowed",
                                data_source=d.data_source, donor_food_uid=m.donor_uid,
                                original_label=d.original_label, original_value=d.original_value,
                                original_unit=d.original_unit, derivation=d.derivation, note="; ".join(note)))
                log.append((target, code, m.donor_uid, "filled"))
                break
    filled = pd.DataFrame(new, columns=VALUE_COLUMNS)
    log = pd.DataFrame(log, columns=["food_uid", "code", "donor_uid", "outcome"])
    return pd.concat([values, filled], ignore_index=True), log, skipped_matches
