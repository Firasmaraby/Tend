"""Nutrient density: how much of the daily values a food delivers per 100 kcal.

score = sum over density nutrients of min(1, amount_per_100kcal / DV)   (each nutrient capped at 100% DV)
score_conservative treats unknown nutrients as 0 and is the ranking key; coverage shows how many are known,
so a food never ranks high just because its weak nutrients were never measured.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import BASIS_STD, load_nutrients
from .qa import wide

MIN_KCAL = 10  # below this (water, tea, salt) per-calorie scores are meaningless


def score(foods: pd.DataFrame, values: pd.DataFrame) -> pd.DataFrame:
    nut = load_nutrients()
    dens = nut[nut["density"] == 1].set_index("code")["dv"]
    keep = (foods["basis"] == BASIS_STD) if "basis" in foods.columns else pd.Series(True, index=foods.index)
    if "status" in foods.columns:
        keep &= foods["status"] == "active"
    std = set(foods.loc[keep, "food_uid"])
    w = wide(values)
    w = w[w.index.isin(std)]   # per-100 mL and assumed-basis foods are not ranked
    kcal = w["ENERC_KCAL"] if "ENERC_KCAL" in w.columns else pd.Series(dtype=float)
    w = w[kcal >= MIN_KCAL]
    per100 = w.reindex(columns=dens.index).mul(100 / w["ENERC_KCAL"], axis=0)
    frac = per100.div(dens, axis=1).clip(upper=1)
    out = pd.DataFrame({
        "kcal_per_100g": w["ENERC_KCAL"],
        "nutrients_known": frac.notna().sum(axis=1),
        "nutrients_total": len(dens),
        "score_conservative": frac.fillna(0).sum(axis=1),
        "score_known_only": frac.sum(axis=1) / frac.notna().sum(axis=1).replace(0, np.nan) * len(dens),
    })
    out["coverage"] = out["nutrients_known"] / out["nutrients_total"]
    top = frac.apply(lambda r: ", ".join(r.dropna().sort_values(ascending=False).head(4).index), axis=1)
    out["top_nutrients"] = top
    out = out.join(foods.set_index("food_uid")[["source_id", "name_original", "name_en", "group_original", "state"]])
    out = out.sort_values("score_conservative", ascending=False)
    out["rank_in_source"] = out.groupby("source_id")["score_conservative"].rank(ascending=False, method="min").astype(int)
    return out.reset_index()
