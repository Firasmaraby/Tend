"""Deterministic links between sources that share identifiers (no model, no similarity scoring).

CNF -> USDA SR Legacy: CNF Food_Name.USDA_NDB_Code equals sr_legacy_food.NDB_number. About two thirds of CNF foods
are built from USDA data (Food_Source codes below), so CNF and USDA values for them are NOT independent measurements.
This module writes out/links/cnf_usda_derivation.csv and returns an info-level QA flag `derived_from_usda` for every
CNF food built from USDA. Dedup (cluster rules) and borrowing must treat these pairs as one measurement, not two.
"""
from __future__ import annotations

import pandas as pd

from .common import INCOMING, OUT

# CNF Food_Source_Code values that say "Food based on data from USDA ..." (see Food_Source.csv)
USDA_BASED_FOOD_SOURCES = {"0", "1", "3", "4", "6", "10", "11", "12"}
# CNF Nutrient_Source_Code values that say the nutrient value itself comes from USDA
USDA_NUTRIENT_SOURCES = {"0", "1", "4", "5"}


def cnf_usda(chosen: dict, foods: pd.DataFrame, values: pd.DataFrame):
    if "cnf" not in chosen:
        return None, pd.DataFrame(columns=["food_uid", "code", "check", "severity", "detail"])
    cnf_dir = chosen["cnf"]["path"]
    fn = pd.read_csv(cnf_dir / "Food_Name.csv", encoding="utf-8-sig", dtype=str, keep_default_na=False)
    fs = pd.read_csv(cnf_dir / "Food_Source.csv", encoding="utf-8-sig", dtype=str, keep_default_na=False) \
        .set_index("Food_Source_Code")["Food_Source_Description_EN"]
    sr = None
    sr_id = "usda_fdc_sr_legacy"
    if sr_id in chosen:
        sr = pd.read_csv(chosen[sr_id]["path"] / "sr_legacy_food.csv", dtype=str, keep_default_na=False)
        sr["usda_uid"] = sr_id + ":" + sr["fdc_id"]
    out = pd.DataFrame({
        "cnf_uid": "cnf:" + fn["Food_Code"],
        "cnf_name": fn["Food_Description_EN"],
        "ndb_code": fn["USDA_NDB_Code"],
        "cnf_food_source_code": fn["Food_Source_Code"],
        "cnf_food_source": fn["Food_Source_Code"].map(fs),
        "derived_from_usda": fn["Food_Source_Code"].isin(USDA_BASED_FOOD_SOURCES),
    })
    out["usda_uid"] = None
    out["usda_name"] = None
    if sr is not None:
        m = out["ndb_code"].map(sr.set_index("NDB_number")["usda_uid"])
        out["usda_uid"] = m
        out["usda_name"] = out["usda_uid"].map(foods.set_index("food_uid")["name_original"])
    # how many of this CNF food's loaded values are USDA-origin vs Canadian/other origin
    cv = values[values["food_uid"].isin(out["cnf_uid"]) & values["derivation"].notna()]
    ns = cv["derivation"].str.extract(r"^NS(\d+)")[0]
    cnt = pd.DataFrame({"food_uid": cv["food_uid"], "usda_origin": ns.isin(USDA_NUTRIENT_SOURCES)})
    g = cnt.groupby("food_uid")["usda_origin"].agg(["sum", "size"])
    out["values_usda_origin"] = out["cnf_uid"].map(g["sum"]).fillna(0).astype(int)
    out["values_total"] = out["cnf_uid"].map(g["size"]).fillna(0).astype(int)
    out["independent_of_usda"] = ~out["derived_from_usda"]
    out["usda_food_in_build"] = out["usda_uid"].notna()
    OUT.joinpath("links").mkdir(parents=True, exist_ok=True)
    out.to_csv(OUT / "links" / "cnf_usda_derivation.csv", index=False)

    d = out[out["derived_from_usda"]]
    flags = pd.DataFrame({
        "food_uid": d["cnf_uid"], "code": None, "check": "derived_from_usda", "severity": "info",
        "detail": "CNF food built from USDA data (" + d["cnf_food_source_code"] + ": " + d["cnf_food_source"].fillna("") +
                  "); NDB " + d["ndb_code"].replace("", "none") + (" -> " + d["usda_uid"]).where(d["usda_uid"].notna(), "") +
                  "; not an independent measurement",
    })
    return out, flags
