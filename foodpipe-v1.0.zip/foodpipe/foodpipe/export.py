"""Write outputs: SQLite (everything), CSVs for app import, attribution and QA report."""
from __future__ import annotations

import datetime as dt
import json
import sqlite3

import pandas as pd

from .common import OUT, load_nutrients


def write(foods, values, flags, fill_log, density, sources_used: dict, meta: dict):
    OUT.mkdir(parents=True, exist_ok=True)
    nut = load_nutrients()

    db = OUT / "foodpipe.sqlite"
    if db.exists():
        db.unlink()
    with sqlite3.connect(db) as con:
        foods.to_sql("foods", con, index=False)
        values.to_sql("food_values", con, index=False)
        nut.to_sql("nutrients", con, index=False)
        flags.to_sql("qa_flags", con, index=False)
        fill_log.to_sql("fill_log", con, index=False)
        density.to_sql("density", con, index=False)
        pd.DataFrame([dict(source_id=k, **{kk: (json.dumps(vv) if isinstance(vv, (list, dict)) else vv)
                                         for kk, vv in v.items()}) for k, v in sources_used.items()]
                     ).to_sql("sources", con, index=False)
        con.execute("CREATE INDEX ix_v ON food_values(food_uid, code)")

    # wide CSV: one row per food, canonical columns in config order, per 100 g edible portion
    v = values[values["value"].notna()]
    w = v.pivot_table(index="food_uid", columns="code", values="value", aggfunc="first")
    w = w.reindex(columns=[c for c in nut["code"] if c in w.columns]).round(4)
    borrowed = v[v["value_type"] == "borrowed"].groupby("food_uid")["code"].apply(lambda s: " ".join(sorted(s)))
    wide = foods.set_index("food_uid").join(w).join(borrowed.rename("borrowed_codes"))
    wide.reset_index().to_csv(OUT / "foods_wide.csv", index=False)
    values.to_csv(OUT / "food_values_long.csv", index=False)
    density.to_csv(OUT / "density_rank.csv", index=False)
    flags.to_csv(OUT / "qa_flags.csv", index=False)

    # attribution - required by the licences; ship this text in the app's About/Credits screen
    lines = ["# Data sources and attribution", "",
             f"Generated {dt.date.today().isoformat()}. Values are per 100 g edible portion.", ""]
    for sid, s in sources_used.items():
        lines += [f"## {s['name']}", f"- Citation: {s['citation']}", f"- Required notice: {s['licence_notice']}",
                  f"- Licence: {s['licence']}", f"- Changes made: {s['changes_notice']}"]
        for c in s.get("conditions", []) or []:
            lines.append(f"- Condition: {c}")
        if meta["inputs"][sid]["dev_mirror"]:
            lines.append(f"- **Built from a development mirror ({meta['inputs'][sid]['path']}). Replace with the official download before production.**")
        lines.append("")
    lines += ["Some values were filled by borrowing from a matched food in another source listed above; "
              "each such value is labelled `borrowed` with its donor food and source in food_values_long.csv."]
    (OUT / "ATTRIBUTION.md").write_text("\n".join(lines))
    return db
