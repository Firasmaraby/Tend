"""Shared paths, config loading and the canonical record layout."""
from __future__ import annotations

import re
from pathlib import Path

import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / "config"
INCOMING = ROOT / "data" / "incoming"
MIRROR = ROOT / "raw_mirror"
MATCHES = ROOT / "matches"
OUT = ROOT / "out"

# Long-format value table: one row per food x nutrient.
VALUE_COLUMNS = [
    "food_uid",        # "<source_id>:<native_id>"
    "code",            # canonical nutrient code (config/nutrients.csv)
    "value",           # per 100 g edible portion, canonical unit; NaN for not_applicable/pending/present_not_quantified/below_lod (the limit stays in original_value)
    "unit",            # canonical unit
    "value_type",      # reported | trace | below_lod | not_applicable | pending | present_not_quantified | derived | borrowed
    "data_source",     # source_id that owns this value (donor source for borrowed values)
    "donor_food_uid",  # for borrowed values
    "original_label",  # the source's own nutrient name / column
    "original_value",  # the source's cell, untouched, as text
    "original_unit",
    "derivation",      # the source's own derivation code/text if it has one
    "note",
]

FOOD_COLUMNS = [
    "food_uid", "source_id", "native_id", "name_original", "lang", "name_en",
    "group_original", "state", "country",
]


BASIS_STD = "per 100 g edible portion"
BASIS_PURCHASED = "per 100 g as purchased (incl. refuse)"   # CoFID "... weighed with skin / bone / stones / whole / as served"
BASIS_DRY = "per 100 g dry matter"                           # USDA Foundation "(0% moisture)"


def read_csv(path: Path) -> pd.DataFrame:
    # keep_default_na=False: never let pandas turn codes like "NA" into missing values
    return pd.read_csv(path, keep_default_na=False, na_values=[""], dtype=str)


def load_nutrients() -> pd.DataFrame:
    df = read_csv(CONFIG / "nutrients.csv")
    df["dv"] = pd.to_numeric(df["dv"], errors="coerce")
    df["density"] = df["density"].astype(int)
    return df


def load_sources() -> dict:
    return yaml.safe_load((CONFIG / "sources.yaml").read_text())["sources"]


def load_fill_rules() -> dict:
    return yaml.safe_load((CONFIG / "fill_rules.yaml").read_text())


def load_map(name: str) -> pd.DataFrame:
    df = read_csv(CONFIG / "source_maps" / f"{name}.csv")
    df["factor"] = df["factor"].astype(float)
    df["priority"] = df["priority"].astype(int)
    return df


def empty_values() -> pd.DataFrame:
    return pd.DataFrame(columns=VALUE_COLUMNS)


_STATE_PATTERNS = [
    # (regex, state) - English and Portuguese; extend per language as sources are added
    (r"\b(raw|cru|crua|crus|cruas|fresh|fresco|fresca)\b", "raw"),
    (r"\b(boiled|cozid[oa]s?|cooked|stewed|braised|moist heat)\b", "cooked_moist"),
    (r"\b(fried|frit[oa]s?|pan-fried)\b", "fried"),
    (r"\b(roasted|assad[oa]s?|baked|torrad[oa]s?)\b", "roasted_baked"),
    (r"\b(grilled|grelhad[oa]s?|broiled|dry heat)\b", "grilled"),
    (r"\b(saut[eé]ed|refogad[oa]s?)\b", "sauteed"),
    (r"\b(canned|enlatad[oa]s?|conserva)\b", "canned"),
    (r"\b(dried|dry|desidratad[oa]s?|seco|seca|p[oó])\b", "dried"),
    (r"\b(frozen|congelad[oa]s?)\b", "frozen"),
]


def guess_state(name: str) -> str:
    n = name.lower()
    found = [s for pat, s in _STATE_PATTERNS if re.search(pat, n)]
    if not found:
        return "unknown"
    # cooked methods win over 'frozen'/'raw' when both appear (e.g. "frozen, cooked")
    for pref in ["fried", "grilled", "roasted_baked", "sauteed", "cooked_moist", "canned", "dried", "raw", "frozen"]:
        if pref in found:
            return pref
    return found[0]
