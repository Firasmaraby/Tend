"""QA flags that come from facts an adapter recorded in a value's note (so the flag and the evidence cannot drift apart).

  per_100ml_basis      info     food is published per 100 mL, not per 100 g (CoFID alcoholic beverages); values are NOT converted
  duplicate_source_id  warning  the source uses one food code for two different foods (native_id was suffixed '#n')
  matrix_unit_missing  warning  the source left the per-100 g basis blank; basis assumed (Swiss, 1 food)
  bracketed_value      info     the source printed a value in brackets (meaning not defined by the source); number kept as is
"""
from __future__ import annotations

import pandas as pd

from .common import BASIS_DRY, BASIS_PURCHASED, BASIS_STD

RULES = [
    ("per_100ml_basis", "info", "per 100 mL, not per 100 g", "published per 100 mL; loaded unconverted (no density applied)"),
    ("duplicate_source_id", "warning", "is used twice in the source", "source food code shared by two foods; native_id suffixed"),
    ("matrix_unit_missing", "warning", "Matrix unit blank in the source", "source left the basis (per 100 g) blank; assumed per 100 g like all other foods"),
    ("bracketed_value", "info", "source value is in brackets", "value printed in brackets in the source; meaning not defined"),
]


def run(values: pd.DataFrame) -> pd.DataFrame:
    cols = ["food_uid", "code", "check", "severity", "detail"]
    out = []
    note = values["note"].fillna("")
    for check, sev, needle, detail in RULES:
        hit = values[note.str.contains(needle, regex=False)]
        if check == "bracketed_value":  # per value
            out.append(pd.DataFrame({"food_uid": hit["food_uid"], "code": hit["code"], "check": check, "severity": sev,
                                     "detail": detail + " (cell " + hit["original_value"].astype(str) + ")"}))
        else:                            # per food
            h = hit.drop_duplicates("food_uid")
            out.append(pd.DataFrame({"food_uid": h["food_uid"], "code": None, "check": check, "severity": sev, "detail": detail}))
    return pd.concat(out, ignore_index=True)[cols] if out else pd.DataFrame(columns=cols)


def basis(foods: pd.DataFrame, values: pd.DataFrame) -> pd.Series:
    """Per-food basis. Standard = per 100 g edible portion. A food whose values an adapter noted as published per 100 mL gets
    'per 100 mL' (values are NOT converted); a food whose source left the basis blank gets '... (assumed; not stated by the source)'.
    Foods with any other basis are excluded from the density ranking and from borrowing (both as target and as donor)."""
    note = values["note"].fillna("")
    ml = set(values.loc[note.str.contains("per 100 mL, not per 100 g", regex=False), "food_uid"])
    blank = set(values.loc[note.str.contains("Matrix unit blank in the source", regex=False), "food_uid"])
    out = pd.Series(BASIS_STD, index=foods["food_uid"])
    out[out.index.isin(blank)] = BASIS_STD + " (assumed; not stated by the source)"
    out[out.index.isin(ml)] = "per 100 mL"
    # names that state the basis (values are NOT converted; the food is simply not comparable with per-100 g edible portion)
    nm = foods.set_index("food_uid")["name_original"].astype(str)
    sid = foods.set_index("food_uid")["source_id"]
    purchased = (sid == "cofid") & nm.str.contains(r"weighed (?:with|whole|as served|as whole)", case=False, regex=True)
    dry = (sid == "usda_fdc_foundation") & nm.str.contains(r"\(0% moisture\)", regex=True)
    out[purchased[purchased].index] = BASIS_PURCHASED
    out[dry[dry].index] = BASIS_DRY
    return foods["food_uid"].map(out)
