"""Apply reviewed English names (config/translations.csv) to foods whose source has no English name.

config/translations.csv columns: food_uid, name_en, state, species_or_variety, notes, confidence, method
  method = haiku (confidence >= 0.8, used as is) | sonnet-review (reviewed by Sonnet; final).
A translation below 0.8 that has not been reviewed is NOT applied. Only foods with an empty name_en are touched;
name_original is never changed. `state` from the translation replaces the heuristic state of those foods.
"""
from __future__ import annotations

import pandas as pd

from .common import CONFIG, read_csv

STATE_MAP = {"boiled": "cooked_moist", "prepared_dish": "unknown"}
STATES = {"raw", "cooked_moist", "fried", "roasted_baked", "grilled", "sauteed", "canned", "dried", "frozen", "unknown"}


def apply(foods: pd.DataFrame) -> pd.DataFrame:
    path = CONFIG / "translations.csv"
    if not path.exists():
        return foods
    t = read_csv(path).fillna("")
    t["confidence"] = t["confidence"].astype(float)
    t = t[(t["method"] == "sonnet-review") | (t["confidence"] >= 0.8)].drop_duplicates("food_uid", keep="last").set_index("food_uid")
    foods = foods.copy()
    need = foods["name_en"].isna() | (foods["name_en"].astype(str).str.strip() == "")
    hit = need & foods["food_uid"].isin(t.index)
    foods.loc[hit, "name_en"] = foods.loc[hit, "food_uid"].map(t["name_en"])
    st = foods.loc[hit, "food_uid"].map(t["state"]).replace(STATE_MAP)
    foods.loc[hit, "state"] = st.where(st.isin(STATES), "unknown")
    return foods
