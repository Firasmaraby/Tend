"""Unit harmonisation and derived values. Never alters a reported number except by an explicit unit factor."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import VALUE_COLUMNS, load_nutrients

# which source units may legitimately end up in each canonical unit (after the map factor)
COMPATIBLE = {
    "g": {"g", "G", "%", "mg"},   # mg only via an explicit 0.001 factor (the adapter asserts it)
    "mg": {"mg", "MG"},
    "ug": {"ug", "UG", "mcg", "µg", "IU"},   # IU only via an explicit factor in the source map
    "kcal": {"kcal", "KCAL"},
    "kJ": {"kJ", "KJ"},
}


def harmonise(values: pd.DataFrame) -> pd.DataFrame:
    nut = load_nutrients().set_index("code")
    unknown = set(values["code"]) - set(nut.index)
    if unknown:
        raise ValueError(f"codes not in config/nutrients.csv: {sorted(unknown)}")
    values = values.copy()
    values["unit"] = values["code"].map(nut["unit"])
    bad = values[[ou not in COMPATIBLE[u] for ou, u in zip(values["original_unit"], values["unit"])]]
    if len(bad):
        raise ValueError(f"unit mismatch in source maps, e.g.:\n{bad[['code','original_unit','unit']].drop_duplicates().head()}")
    return values


def derive(values: pd.DataFrame) -> pd.DataFrame:
    """Add clearly-labelled derived values where a standard conversion exists."""
    have = values[values["value"].notna()].pivot_table(index="food_uid", columns="code", values="value", aggfunc="first")
    owner = values.drop_duplicates("food_uid").set_index("food_uid")["data_source"]
    new = []
    # Folate DFE from total folate when folic acid is reported (DFE = food folate + 1.7 x folic acid)
    if {"FOL", "FOLAC"} <= set(have.columns):
        m = have["FOLDFE"].isna() if "FOLDFE" in have.columns else pd.Series(True, index=have.index)
        sub = have[m & have["FOL"].notna() & have["FOLAC"].notna()]
        for uid, r in sub.iterrows():
            dfe = (r["FOL"] - r["FOLAC"]) + 1.7 * r["FOLAC"]
            new.append(dict(food_uid=uid, code="FOLDFE", value=dfe, unit="ug", value_type="derived",
                            data_source=owner[uid], donor_food_uid=None, original_label="FOL, FOLAC",
                            original_value=f"{r['FOL']}, {r['FOLAC']}", original_unit="ug",
                            derivation="DFE = (FOL - FOLAC) + 1.7 x FOLAC", note=None))
    # kJ from kcal when only kcal is given (and vice versa) - pure unit conversion, labelled derived
    if "ENERC_KCAL" in have.columns:
        kj = have["ENERC_KJ"] if "ENERC_KJ" in have.columns else pd.Series(np.nan, index=have.index)
        for uid, r in have[have["ENERC_KCAL"].notna() & kj.isna()].iterrows():
            new.append(dict(food_uid=uid, code="ENERC_KJ", value=r["ENERC_KCAL"] * 4.184, unit="kJ",
                            value_type="derived", data_source=owner[uid], donor_food_uid=None,
                            original_label="ENERC_KCAL", original_value=str(r["ENERC_KCAL"]), original_unit="kcal",
                            derivation="kJ = kcal x 4.184", note=None))
    # kcal from kJ when only kJ is given (AFCD publishes kJ only) - pure unit conversion, labelled derived
    if "ENERC_KJ" in have.columns:
        kc = have["ENERC_KCAL"] if "ENERC_KCAL" in have.columns else pd.Series(np.nan, index=have.index)
        for uid, r in have[have["ENERC_KJ"].notna() & kc.isna()].iterrows():
            new.append(dict(food_uid=uid, code="ENERC_KCAL", value=r["ENERC_KJ"] / 4.184, unit="kcal",
                            value_type="derived", data_source=owner[uid], donor_food_uid=None,
                            original_label="ENERC_KJ", original_value=str(r["ENERC_KJ"]), original_unit="kJ",
                            derivation="kcal = kJ / 4.184", note=None))
    if new:
        values = pd.concat([values, pd.DataFrame(new)[VALUE_COLUMNS]], ignore_index=True)
    return values
