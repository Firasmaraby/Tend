"""Duplicate handling (docs/DEDUP_SPEC.md; rules in config/dedup_rules.yaml).

1. within_source(): the same food listed twice in ONE source -> one active record, the others `superseded` (kept in
   food_nutrients, so history stays auditable). Not collapsed when the records differ by more than 20% on protein, fat
   or energy (and by more than an absolute floor, so 0.1 g vs 0.2 g is not a "100% difference"): those are flagged.
2. clusters(): the same food in DIFFERENT sources -> a canonical food layer, never a deletion. Members come only from
   matches that are exact/equivalent at confidence >= 0.85 (matches/*.csv) plus the deterministic CNF<->USDA NDB-code links.
   A food belongs to at most one cluster, a cluster holds at most one active food per source, and a link that would merge
   two clusters or put two foods of one source together is NOT applied; it goes to the review queue instead.
   The preferred record = region priority, then most density nutrients reported, then newest release.
Nothing is averaged. Superseded foods are not cluster members themselves; they point to the active record's cluster.
"""
from __future__ import annotations

import hashlib
import re

import numpy as np
import pandas as pd
import yaml

from .common import BASIS_DRY, BASIS_PURCHASED, BASIS_STD, CONFIG, INCOMING, load_nutrients, read_csv

ABS_FLOOR = {"PROCNT": 1.0, "FAT": 1.0, "ENERC_KCAL": 10.0}


def rules() -> dict:
    return yaml.safe_load((CONFIG / "dedup_rules.yaml").read_text())


def release_dates(foods: pd.DataFrame) -> pd.Series:
    """Publication / last-updated date per food where the source provides one (USDA food.csv, CNF Food_Name.csv)."""
    out = {}
    for sid in foods["source_id"].unique():
        if sid.startswith("usda_fdc_"):
            p = next((INCOMING / sid).rglob("food.csv"), None)
            if p is not None:
                d = pd.read_csv(p, usecols=["fdc_id", "publication_date"], dtype=str)
                out.update({f"{sid}:{r.fdc_id}": r.publication_date for r in d.itertuples() if isinstance(r.publication_date, str)})
        elif sid == "cnf":
            p = INCOMING / "cnf" / "Food_Name.csv"
            if p.exists():
                d = pd.read_csv(p, dtype=str, encoding="utf-8-sig")
                out.update({f"cnf:{r.Food_Code}": r.Food_Last_Updated_Date for r in d.itertuples() if isinstance(r.Food_Last_Updated_Date, str)})
    return foods["food_uid"].map(out)


def norm_name(s: str) -> str:
    s = re.sub(r"\s*\((includes|incl)[^)]*\)", "", str(s).lower())
    return re.sub(r"[^\w]+", " ", s).strip()


MACROS = ("ENERC_KCAL", "PROCNT", "FAT")


def has_macros(values: pd.DataFrame) -> set:
    """Foods with energy, protein AND fat from their own source (borrowed values do not count). Such records are preferred before any
    region or date rule (v1.0 fix m4): a record without energy/fat must not hide one that has them."""
    v = values[values["value"].notna() & (values["value_type"] != "borrowed") & values["code"].isin(MACROS)]
    n = v.groupby("food_uid")["code"].nunique()
    return set(n.index[n == len(MACROS)])


_STRIP_BASIS = re.compile(r",?\s*weighed (?:with|whole|as served|as whole).*$|\s*\(0% moisture\)", re.I)


def twin_key(name: str) -> str:
    """Name of a non-standard-basis record with the basis phrase removed ('Almonds, weighed with shells' -> 'almonds')."""
    return norm_name(_STRIP_BASIS.sub("", str(name)))


def _wide(values: pd.DataFrame) -> pd.DataFrame:
    v = values[values["value"].notna() & (values["value_type"] != "borrowed")]
    return v.pivot_table(index="food_uid", columns="code", values="value", aggfunc="first")


def within_source(foods: pd.DataFrame, values: pd.DataFrame, dates: pd.Series):
    """-> (status table [food_uid, status, superseded_by], review rows)."""
    w = _wide(values)
    n_nut = values[values["value"].notna() & (values["value_type"] != "borrowed")].groupby("food_uid")["code"].nunique()
    hm = has_macros(values)
    f = foods.assign(key=foods["name_original"].map(norm_name), date=dates.values, n=foods["food_uid"].map(n_nut).fillna(0),
                     hm=foods["food_uid"].isin(hm).astype(int))
    status = pd.DataFrame({"food_uid": foods["food_uid"], "status": "active", "superseded_by": ""}).set_index("food_uid")
    review = []
    for (src, key, st), g in f.groupby(["source_id", "key", "state"], sort=False):
        if len(g) < 2:
            continue
        g = g.assign(date=g["date"].fillna("")).sort_values(["hm", "date", "n", "food_uid"], ascending=[False, False, False, True])
        keep = g.iloc[0]["food_uid"]
        for uid in g["food_uid"].iloc[1:]:
            conflict = []
            for code, rel in rules()["within_source_collapse"]["do_not_collapse_if_diff_over"].items():
                a, b = w.get(code, pd.Series(dtype=float)).get(keep), w.get(code, pd.Series(dtype=float)).get(uid)
                if pd.notna(a) and pd.notna(b) and abs(a - b) > max(rel * max(a, b), ABS_FLOOR.get(code, 0)):
                    conflict.append(f"{code} {a:g} vs {b:g}")
            if conflict:
                review.append(dict(food_uid=uid, other_uid=keep, reason="same name, differs by more than 20%: " + "; ".join(conflict)))
            else:
                status.loc[uid, ["status", "superseded_by"]] = ["superseded", keep]
    return status.reset_index(), pd.DataFrame(review, columns=["food_uid", "other_uid", "reason"])


# ----------------------------------------------------------------------------------------------------------------------
def load_pairs(active: set[str], matches: pd.DataFrame | None = None) -> pd.DataFrame:
    """All exact/equivalent pairs >= min confidence among active foods: matches/*.csv (after the guard) + CNF<->USDA derivation links."""
    from .fill import load_matches
    r = rules()
    m = matches if matches is not None else load_matches(symmetric=False)
    m = m[m["match_type"].isin(r["cluster_match_types"]) & (m["confidence"] >= r["cluster_min_confidence"])]
    pairs = m.rename(columns={"target_uid": "a", "donor_uid": "b"})[["a", "b", "match_type", "confidence", "method"]]
    pairs = pairs[pairs["a"].isin(active) & pairs["b"].isin(active) & (pairs["a"] != pairs["b"])]
    # one row per unordered pair: keep the highest confidence
    pairs["k"] = [tuple(sorted(x)) for x in zip(pairs["a"], pairs["b"])]
    return pairs.sort_values("confidence", ascending=False).drop_duplicates("k").drop(columns="k").reset_index(drop=True)


def clusters(foods: pd.DataFrame, values: pd.DataFrame, status: pd.DataFrame, dates: pd.Series, matches: pd.DataFrame | None = None, checker=None):
    """-> (foods with canonical_id / is_preferred, canonical_foods, canonical_members, review rows)."""
    r = rules()
    prio = {s: i for i, s in enumerate(r["region_priority"])}
    nut = load_nutrients()
    dens = set(nut.loc[nut["density"] == 1, "code"])
    v = values[values["value"].notna() & (values["value_type"] != "borrowed")]
    n_dens = v[v["code"].isin(dens)].groupby("food_uid")["code"].nunique()

    f = foods.copy()
    if "food_group" not in f.columns:
        from .unified import assign_groups
        f["food_group"] = assign_groups(f)
    f["date"] = dates.values
    f["n_dens"] = f["food_uid"].map(n_dens).fillna(0).astype(int)
    hm = has_macros(values)
    f["hm"] = f["food_uid"].isin(hm).astype(int)
    f = f.set_index("food_uid", drop=False)
    active = set(f.index[(f["status"] == "active") & (f["basis"] == "per 100 g edible portion")])
    src = f["source_id"].to_dict()

    pairs = load_pairs(active, matches)
    cl_of: dict[str, int] = {}
    members: dict[int, list[str]] = {}
    link_of: dict[str, tuple] = {}
    review = []
    nxt = 0
    for p in pairs.itertuples():
        a, b = p.a, p.b
        ca, cb = cl_of.get(a), cl_of.get(b)
        if ca is None and cb is None:
            if src[a] == src[b]:
                review.append(dict(a=a, b=b, reason="both foods are from the same source", **_m(p))); continue
            cl_of[a] = cl_of[b] = nxt; members[nxt] = [a, b]; link_of[a] = link_of[b] = (p.match_type, p.confidence, p.method); nxt += 1
        elif ca is not None and cb is not None:
            if ca != cb:
                review.append(dict(a=a, b=b, reason="would join two clusters", **_m(p)))
        else:
            new, old, c = (b, a, ca) if ca is not None else (a, b, cb)
            if any(src[m] == src[new] for m in members[c]):
                review.append(dict(a=a, b=b, reason=f"cluster already has a food from {src[new]}", **_m(p))); continue
            if checker is not None and p.method != "ndb_code":   # v1.0: the newcomer must not contradict ANY member (hub foods chain variants)
                bad = next(((mm, w) for mm in members[c] for w in [checker(new, mm)] if w), None)
                if bad:
                    review.append(dict(a=a, b=b, reason=f"conflicts with member {bad[0]}: " + "; ".join(x[0] for x in bad[1]), **_m(p))); continue
            cl_of[new] = c; members[c].append(new); link_of[new] = (p.match_type, p.confidence, p.method)

    # singletons
    for uid in f.index:
        if uid not in cl_of and f.at[uid, "status"] == "active":
            cl_of[uid] = nxt; members[nxt] = [uid]; link_of[uid] = ("", np.nan, "singleton"); nxt += 1

    def pref_key(uid):
        d = f.at[uid, "date"]
        return (-int(f.at[uid, "hm"]), prio.get(src[uid], 99), -int(f.at[uid, "n_dens"]), -(int(re.sub(r"\D", "", d)) if isinstance(d, str) and re.sub(r"\D", "", d) else 0), uid)

    # non-standard-basis records (CoFID 'weighed with ...', Foundation '(0% moisture)') are never preferred when a standard-basis record
    # exists under the same name (v1.0 fix B1); they stay singleton clusters with no preferred record.
    std_names = {}
    for uid in f.index[(f["status"] == "active") & (f["basis"] == BASIS_STD)]:
        std_names.setdefault(norm_name(f.at[uid, "name_original"]), []).append(uid)
    std_tokens = {}   # tier 2 (same source): head word + token subset, e.g. 'Bananas, flesh only' for 'Bananas, raw, flesh only, weighed with skin'
    for uid in f.index[(f["status"] == "active") & (f["basis"] == BASIS_STD)]:
        nm_ = norm_name(f.at[uid, "name_original"]).split()
        if nm_:
            std_tokens.setdefault((src[uid], nm_[0]), []).append((frozenset(nm_), uid))
    no_pref = {}
    cf, cm = [], []
    uid2can, uid2pref = {}, {}
    for c, mem in members.items():
        mem_sorted = sorted(mem, key=pref_key)
        pref = mem_sorted[0]
        # canonical_id is derived from the preferred food_id, so it survives changes in the other members (v1.0 fix m3)
        cid = "cf_" + hashlib.md5(pref.encode()).hexdigest()[:10]
        twins = []
        if len(mem) == 1 and f.at[pref, "basis"] in (BASIS_PURCHASED, BASIS_DRY):
            k = twin_key(f.at[pref, "name_original"])
            twins = [t for t in std_names.get(k, []) if t != pref]
            if not twins and k:
                ktok = set(k.split())
                twins = [u for toks, u in std_tokens.get((src[pref], k.split()[0]), []) if len(toks) >= 2 and toks <= ktok | {"raw"} and u != pref]
        if twins:
            no_pref[cid] = ";".join(sorted(twins)[:3])
        cf.append(dict(canonical_id=cid, canonical_name_en=f.at[pref, "name_en"], food_group=f.at[pref, "food_group"], state=f.at[pref, "state"],
                       preferred_food_id=("" if twins else pref), n_members=len(mem), n_sources=len({src[m] for m in mem}),
                       preferred_note=(f"not preferred: {f.at[pref, 'basis']}; standard-basis record(s) under the same name: {no_pref[cid]}" if twins else "")))
        for m in mem_sorted:
            t, conf, meth = link_of[m]
            is_p = (m == pref) and not twins
            cm.append(dict(canonical_id=cid, food_id=m, source_id=src[m], match_type=t, confidence=conf, method=meth, is_preferred=is_p))
            uid2can[m] = cid; uid2pref[m] = is_p
    # superseded foods follow the active record they point to
    for uid in f.index[f["status"] == "superseded"]:
        tgt = f.at[uid, "superseded_by"]
        uid2can[uid] = uid2can.get(tgt, ""); uid2pref[uid] = False
    # foods not on a per-100 g basis (or otherwise unclustered but active): own cluster handled above only if active -> basis foods are active and singleton
    out = foods.copy()
    out["canonical_id"] = out["food_uid"].map(uid2can).fillna("")
    out["is_preferred"] = out["food_uid"].map(uid2pref).fillna(False).astype(bool)
    cfd = pd.DataFrame(cf)
    cfd.attrs["no_preferred"] = no_pref
    return out, cfd, pd.DataFrame(cm), pd.DataFrame(review)


def _m(p):
    return dict(match_type=p.match_type, confidence=p.confidence, method=p.method)


def checks(foods: pd.DataFrame, n_before: int, cf: pd.DataFrame, cm: pd.DataFrame) -> list[tuple[str, bool, str]]:
    res = []
    res.append(("every food_id appears exactly once", foods["food_uid"].is_unique, f"{len(foods)} rows"))
    act, sup = int((foods["status"] == "active").sum()), int((foods["status"] == "superseded").sum())
    res.append(("foods before = active + superseded", n_before == act + sup, f"{n_before} = {act} + {sup}"))
    exempt = set(cf.attrs.get("no_preferred", {}))
    pc = cm[cm["is_preferred"]].groupby("canonical_id").size()
    ok = (pc == 1).all() and set(cf["canonical_id"]) - set(pc.index) == exempt
    res.append(("every cluster has exactly one preferred record (except non-standard-basis singletons that have a standard twin)", ok,
                f"{len(cf)} clusters, {len(exempt)} exempt singletons"))
    res.append(("a non-standard-basis food is never preferred when a standard-basis record has the same name",
                not foods[(foods["basis"].isin([BASIS_PURCHASED, BASIS_DRY])) & foods["is_preferred"] & foods["canonical_id"].isin(exempt)].shape[0], "ok"))
    bad_basis = foods[foods["is_preferred"] & (foods["basis"] != BASIS_STD)]
    res.append(("non-standard-basis foods in multi-source clusters", int(cm[cm["food_id"].isin(foods.loc[foods["basis"] != BASIS_STD, "food_uid"])].groupby("canonical_id").size().max() or 0) <= 1, "singleton only"))
    res.append(("every active food is in exactly one cluster", cm["food_id"].is_unique and set(cm["food_id"]) == set(foods.loc[foods["status"] == "active", "food_uid"]), f"{cm['food_id'].nunique()} members"))
    multi = cm.groupby(["canonical_id", "source_id"]).size()
    res.append(("no cluster has two foods from one source", (multi == 1).all(), f"max {int(multi.max())}"))
    pref_count = foods[foods["is_preferred"]].groupby("canonical_id").size()
    res.append(("foods_wide is_preferred = one per cluster (exempt singletons excepted)", (pref_count == 1).all() and len(pref_count) == len(cf) - len(exempt), f"{int(foods['is_preferred'].sum())} preferred"))
    return res
