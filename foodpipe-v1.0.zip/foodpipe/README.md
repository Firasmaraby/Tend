# foodpipe

Builds one food composition table from openly licensed national databases. It keeps the provenance of every
value and fills gaps only by borrowing from matched foods. The output is per 100 g edible portion, in
canonical units, ready for a Supabase/Postgres import.

## Principles

1. **Licence first.** A source is ingested only if `config/sources.yaml` marks it `approved` (commercial use
   verified at the publisher). `pending` and `excluded` sources are refused by the code.
2. **Never alter or invent.** Each source cell is kept as text in `original_value`. Conversion uses only
   explicit factors from `config/source_maps/`. Special codes (trace, not applicable, under re-analysis) are
   encoded as `value_type`, never as fake numbers.
3. **Fill gaps by borrowing.** A missing nutrient is filled only from a reviewed match (`matches/*.csv`,
   `exact` or `equivalent`, confidence ≥ 0.85). Borrowing is moisture-adjusted and blocked for
   fortification-sensitive nutrients. Every filled value names its donor food and source.
4. **Flag, don't fix.** QA findings go to `qa_flags`. Nothing is auto-corrected.

## Quick start

```bash
pip install pandas pyyaml openpyxl xlrd pyarrow
python -m foodpipe status          # licence status + which files are present
python -m foodpipe build           # official files only
python -m foodpipe build --dev     # also allow the dev mirrors in raw_mirror/ (not for production)
python -m foodpipe translate-tasks # JSONL of non-English names for a Haiku batch (prompts/translate_foods.md)
```

## Adding data

Put each official download in `data/incoming/<source_id>/`. The expected files are listed per source in
`config/sources.yaml`. If an adapter exists, the next build picks the files up and stops using the dev mirror.

Adapters in v0.1: `usda_fdc` (Foundation, SR Legacy, FNDDS: same CSV layout) and `taco`.
Adapters still to write: CNF, CoFID, CIQUAL, AFCD, Swedish, Swiss, MEXT. I'll write each one against the real
files when they arrive, rather than guessing at layouts. A new adapter is about 60–120 lines plus a
`config/source_maps/<name>.csv`.

## Layout

```
config/sources.yaml          licence audit + registry (status, attribution, expected files)
config/nutrients.csv         canonical nutrients: code, unit, daily value, density flag, method notes
config/source_maps/*.csv     source nutrient -> canonical code, unit factor, priority
config/fill_rules.yaml       borrowing rules (threshold, fortification guard, moisture adjustment)
foodpipe/adapters/           one loader per source format
foodpipe/normalize.py        unit harmonisation + labelled derived values (kJ, folate DFE)
foodpipe/qa.py               energy reconciliation, closure, impossible values, outliers, duplicates
foodpipe/fill.py             borrowing
foodpipe/density.py          nutrient density per 100 kcal
foodpipe/export.py           SQLite + CSV + ATTRIBUTION.md
matches/                     reviewed cross-source matches (seed: 74 TACO -> USDA pairs reviewed by Claude)
prompts/                     Haiku/Sonnet batch prompts for translation and matching
raw_mirror/                  development copies retrieved from GitHub (see sources.yaml dev_mirror)
out/                         build outputs
```

## Unified tables (out/unified/) - use these in apps

The same tables as UTF-8 CSV (for apps and databases) and as one Excel workbook, `food_database.xlsx`, for people:
`foods_wide` (main: one row per food), `foods`, `nutrients` (dictionary), `food_nutrients` (long, with provenance),
`sources` (licence and attribution), `food_groups`, `qa_flags`, plus `metadata.json` (version, column lists).
Column names are snake_case with units (`protein_g`) and stay fixed between versions. Empty = unknown.
To change labels, daily values, column names or the group mapping, edit `config/nutrients.csv` or
`config/food_groups.csv` and rebuild.

## Citations (licence condition)

Every source's licence requires citing it. The citation travels with the data:
- `source_citation`, `licence` and `citation_required` on every row of foods_wide, foods and food_nutrients;
  `filled_from_sources_cite_also` names extra sources for borrowed values.
- The `CITATIONS_REQUIRED` sheet (second tab, after README) and `CITATIONS_REQUIRED.csv`.
- `NOTICE.txt`, `CITATIONS.md` and `datapackage.json` (the standard machine-readable licence/source descriptor).
- Workbook properties (title, subject, keywords, description), red header comments, and a footer on every sheet.
- The build refuses an approved source without citation fields in sources.yaml.

## Outputs (out/)

| File | Contents |
|---|---|
| `foodpipe.sqlite` (rebuilt by `python3 -m foodpipe build`; not shipped in the zip) | Tables: foods, food_values (long, full provenance), nutrients, qa_flags, fill_log, density, sources |
| `foods_wide.csv` | Build-internal (not shipped from v1.0, it carries no citation columns). The shipped table is `out/unified/foods_wide.csv` |
| `food_values_long.csv` | Build-internal (not shipped from v1.0). The shipped long table is `out/unified/food_nutrients.csv`, which also has `derivation` and `licence` |
| `density_rank.csv` | Score per 100 kcal (each nutrient capped at 100% DV), coverage, top nutrients |
| `qa_flags.csv` | All QA findings |
| `ATTRIBUTION.md` | Licence and attribution text required by the sources; ship it in the app's credits |

`value_type` values: `reported`, `trace` (stored as 0), `below_lod` (the source gave only an upper limit such as "< 0.5":
the value is left empty and the limit stays in `original_value`; it is never stored as a number and is never filled by
borrowing), `not_applicable`, `pending`, `present_not_quantified` (CoFID "N": the nutrient is present in significant amounts but the source has no reliable figure; empty value, never 0), `derived` (labelled pipeline calculation), `borrowed`.

## Method notes that matter

- **CHOCDF vs CHOAVL.** US, Canadian and Brazilian carbs are "by difference" and include fiber. UK, French
  and Australian carbs are "available" and exclude fiber. They are separate columns and must never be merged.
- **Fiber methods differ.** USDA's AOAC 2011.25 includes resistant starch, so raw potatoes show about 15 g
  "fiber" per 100 g. QA flags the energy mismatch this causes.
- **Vitamin A.** RAE and RE are not interchangeable; both are kept.
- **Sodium.** The code is `SODIUM`, not the INFOODS `NA`, because `NA` is read as missing by pandas, R and
  most CSV importers.
- **CNF.** Older Health Canada terms said values must not be modified. CNF values stay untouched; any added
  values are separate rows labelled `borrowed`.

## Model plan for the bulk work

| Step | Who |
|---|---|
| Parsing, unit conversion, QA, borrowing, density | Code (deterministic, no model) |
| Writing a new adapter for a source | Sonnet 5.5 (one-off per source, about 30 min each) |
| Translating names (pt, fr, ja, sv, de) | Haiku 5.5 in batch; confidence < 0.8 goes to Sonnet |
| Proposing cross-source matches | Candidates generated by code; Haiku 5.5 judges in batch |
| Reviewing borderline or fortification-sensitive matches | Sonnet 5.5; human spot-check of a sample |


## v1.0 changes (review fix pass)
Records on a different basis (CoFID "weighed with ... / whole / as served", Foundation "(0% moisture)") carry their own `basis` and stay out of matching,
borrowing, density and multi-source clusters. NDB-code links are used only for CNF foods derived from USDA; the others are matched like any other food.
A numeric/text guard (`foodpipe/guard.py`) can only downgrade model matches, and the same checks run again when a food joins a cluster. Fortification
(FOLAC, FOLDFE, FOL, FE, THIA, RIBF, NIA, CA, VITD) is not borrowed across countries from enriched/fortified donors. Records with energy, protein and fat
are preferred before region or date. See BUILD_REPORT.md for the before/after counts.
